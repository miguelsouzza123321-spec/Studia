(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const i of r.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&a(i)}).observe(document,{childList:!0,subtree:!0});function s(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(o){if(o.ep)return;o.ep=!0;const r=s(o);fetch(o.href,r)}})();const c=e=>document.querySelector(e);window.$=c;const le=(e=180,t=50)=>`
  <svg width="${e}" height="${t}" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
    <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
    
    <!-- Subtle glow on the outer swoosh -->
    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

    <!-- Book icon matching the user logo -->
    <g transform="translate(68, 2)">
      <!-- Left half -->
      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
      <!-- Right half -->
      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
    </g>

    <!-- Main Title: Studia -->
    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
    <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
  </svg>
`,U=e=>{const t=c("#app");t&&(t.innerHTML=e,typeof lucide<"u"&&lucide.createIcons())},p=(e,{confirm:t=!1,title:s="Studia"}={})=>new Promise(a=>{var i;const o=document.createElement("div");o.style.cssText="position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.55);backdrop-filter:blur(5px);font-family:system-ui,sans-serif;",o.innerHTML=`
    <div style="width:min(100%,440px);background:#fff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 24px 60px rgba(15,23,42,.25);padding:28px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;color:#2563eb;">
        <div style="width:40px;height:40px;border-radius:10px;background:#eff6ff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;">S</div>
        <h3 style="margin:0;color:#0f172a;font-size:18px;font-weight:800;">${s}</h3>
      </div>
      <p data-dialog-message style="margin:0;color:#475569;font-size:14px;line-height:1.6;white-space:pre-line;"></p>
      <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
        ${t?'<button data-dialog-cancel type="button" style="border:1px solid #e2e8f0;background:#fff;color:#475569;border-radius:10px;padding:11px 20px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;">Cancelar</button>':""}
        <button data-dialog-ok type="button" style="border:0;background:#2563eb;color:#fff;border-radius:10px;padding:11px 22px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;box-shadow:0 4px 12px rgba(37,99,235,0.25);">${t?"Confirmar":"Entendi"}</button>
      </div>
    </div>`,o.querySelector("[data-dialog-message]").textContent=e;const r=d=>{o.remove(),a(d)};o.querySelector("[data-dialog-ok]").addEventListener("click",()=>r(!0)),(i=o.querySelector("[data-dialog-cancel]"))==null||i.addEventListener("click",()=>r(!1)),o.addEventListener("click",d=>{d.target===o&&r(!1)}),document.body.appendChild(o),o.querySelector("[data-dialog-ok]").focus()});let l=null;try{const e=localStorage.getItem("user");e&&e!=="undefined"&&e!=="null"&&(l=JSON.parse(e))}catch(e){console.error("Error parsing user from localStorage:",e)}let $=[],z=[],B=[],G=new Set,oe=null,R=[],F=[],Y="",I=null,ce=[],ue=[],Q={},T={total:0,confirmed:0,absent:0,pending:0},v="horarios",M="closed",q=[],J=[],A="all",k="matutino",H="all",X="COLÉGIO ESTADUAL PROF. JÚLIO SZYMANSKI - MATUTINO",re="urania",O="prof_turma",w=localStorage.getItem("reportCardSize")||"medium",pe="grid",me=!1,ne=!1,D=(localStorage.getItem("api_base_url")||"").trim();(D==="undefined"||D==="null"||D==="/")&&(D="");const Te=["localhost","127.0.0.1","::1"].includes(window.location.hostname),Me=window.location.hostname.endsWith(".onrender.com");Te&&(D="http://localhost:3000",localStorage.removeItem("api_base_url"));Me&&(D="",localStorage.removeItem("api_base_url"));const Oe=!Te&&!Me;Oe&&(D="https://studia-8st9.onrender.com",localStorage.setItem("api_base_url",D));const Se=e=>{if(e.startsWith("http://")||e.startsWith("https://"))return e;const t=e.startsWith("/")?e:"/"+e;return D?`${D.endsWith("/")?D.slice(0,-1):D}${t}`:t},b={async request(e,t={}){let s=Se(e),a;try{const i={"Content-Type":"application/json",...t.headers};l!=null&&l.accessToken&&(i.Authorization=`Bearer ${l.accessToken}`),a=await fetch(s,{...t,headers:i})}catch(i){console.error("Fetch error on primary URL:",i);let d=null;if(s.includes("ais-pre-")?d=s.replace("ais-pre-","ais-dev-"):s.includes("ais-dev-")&&(d=s.replace("ais-dev-","ais-pre-")),d){console.log("Trying fallback API URL:",d);try{a=await fetch(d,{...t,headers:{"Content-Type":"application/json",...t.headers,...l!=null&&l.accessToken?{Authorization:`Bearer ${l.accessToken}`}:{}}});const n=new URL(d).origin;D=n,localStorage.setItem("api_base_url",n),s=d}catch(u){throw console.error("Fetch error on fallback URL:",u),new Error(`Erro de conexão com o servidor de API.

Tentamos:
1. ${s}
2. ${d}

Verifique se o seu servidor Cloud Run está ativo.`)}}else throw new Error(`Erro de conexão com o servidor de API (${s}).`)}if(a.status===401&&(l!=null&&l.refreshToken)&&!e.startsWith("/api/auth/"))try{const i=await fetch(Se("/api/auth/refresh"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({refreshToken:l.refreshToken})}),d=await i.json();if(i.ok){l={...l,accessToken:d.accessToken,refreshToken:d.refreshToken},localStorage.setItem("user",JSON.stringify(l));const u={"Content-Type":"application/json",...t.headers,Authorization:`Bearer ${l.accessToken}`};a=await fetch(s,{...t,headers:u})}}catch(i){console.error("Session refresh failed:",i)}if(a.status===401&&l&&!e.startsWith("/api/auth/"))throw localStorage.removeItem("user"),l=null,v="horarios",U(fe()),new Error("Sua sessão não é mais válida. Entre novamente com uma conta ativa para continuar.");const o=await a.text();let r;try{r=JSON.parse(o)}catch(i){throw console.error("Parse error:",i),new Error(`Resposta inválida do servidor de API (${s}).`)}if(!a.ok)throw new Error(r.error||`Erro ${a.status}`);return r},async post(e,t){return this.request(e,{method:"POST",body:JSON.stringify(t)})},async get(e){return this.request(e,{method:"GET"})},async patch(e,t){return this.request(e,{method:"PATCH",body:JSON.stringify(t)})},async delete(e){return this.request(e,{method:"DELETE"})}},ie=e=>{const t=e.split("-");return t.length===3?new Date(parseInt(t[0],10),parseInt(t[1],10)-1,parseInt(t[2],10)):new Date(e)},xe=e=>{const t=ie(e),s=t.getDay(),a=t.getDate()-s+(s===0?-6:1),o=new Date(t);o.setDate(a);const r=o.getFullYear(),i=String(o.getMonth()+1).padStart(2,"0"),d=String(o.getDate()).padStart(2,"0");return`${r}-${i}-${d}`},be=e=>{const t=ie(e),s=new Date(t);s.setDate(t.getDate()+4);const a=o=>{const r=String(o.getDate()).padStart(2,"0"),i=String(o.getMonth()+1).padStart(2,"0");return`${r}/${i}`};return`Semana de ${a(t)} a ${a(s)}`},Ue=()=>{const e=new Set;return $.forEach(t=>{if(t.date)try{e.add(xe(t.date))}catch(s){console.error("Error formatting week:",s)}}),Array.from(e).sort().reverse()},ge=()=>{const e=new Set;return $.forEach(t=>{t.startTime&&e.add(t.startTime)}),Array.from(e).sort()},qe=e=>{const t=new Set;return e.forEach(s=>{s.classGroup&&t.add(s.classGroup)}),Array.from(t).sort()},Ae=e=>{const t=e.getDay();return t===0?7:t},Fe=new Map([["programacao front-end","Prog. Front-End"],["programacao back-end","Prog. Back-End"],["programacao back-end i","Prog. Back-End I"],["programacao back-end ii","Prog. Back-End II"],["programacao mobile","Prog. Mobile"],["programacao de desenvolvimento de sistemas","Prog. de Desenv. de Sistemas"],["analise e projeto de sistemas","Análise e Proj. de Sistemas"],["educacao fisica","Ed. Física"],["educacao financeira","Ed. Financeira"],["lingua portuguesa","Língua Port."]]),ve=e=>{const t=String(e||"").trim();if(!t)return t;const s=t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/\s+/g," ");return Fe.get(s)||t.replace(/\bprogramação\b/gi,"Prog.").replace(/\bdesenvolvimento\b/gi,"Desenv.").replace(/\beducação\b/gi,"Ed.").replace(/\bportuguesa\b/gi,"Port.").replace(/\bprojeto\b/gi,"Proj.")},Ve=e=>e.split(" - ").map((t,s)=>s===0&&e.includes(" - ")?t:ve(t)).join(" - "),He=(e,t)=>t==="matutino"?e>="07:00"&&e<"12:00":t==="vespertino"?e>="12:00"&&e<"18:00":t==="noturno"?e>="18:00"&&e<"23:00":!0,we=(e,t,s,a="prof_turma")=>{const o=["Seg","Ter","Qua","Qui","Sex"],r={};s.forEach(h=>{r[h]={},o.forEach(C=>{r[h][C]="------"})}),t.forEach(h=>{var j,_,N;const C=ie(h.date),y=Ae(C),g=y>=1&&y<=5?o[y-1]:null,S=((j=h.startTime)==null?void 0:j.substring(0,5))||h.startTime;if(g&&r[S]){if(h.status!=="confirmed"&&h.status!=="pending"&&h.status!=="vaga"&&((_=h.subject)==null?void 0:_.toUpperCase())!=="HAF")return;const Z=((N=h.subject)==null?void 0:N.toUpperCase())==="HAF",W=h.status==="vaga";let L="------";if(W)L="VAGA";else if(Z)L="HAF";else if(a==="prof_turma")L=h.classGroup||"------";else if(a==="prof_subject")L=h.subject||"------";else{const K=h.subject&&e.subject&&h.subject.trim().toLowerCase()!==e.subject.trim().toLowerCase();L=h.classGroup&&K?`${h.classGroup} - ${h.subject}`:h.classGroup||h.subject||"------"}r[S][g]==="------"?r[S][g]=L:r[S][g].split("/").includes(L)||(r[S][g]+="/"+L)}});let i="font-size: 11px; padding: 0.75rem;",d="text-[12px]",u="text-[9.5px]",n="text-[9px]",m="text-[10px]",x="h-8";w==="small"?(i="font-size: 8.5px; padding: 0.5rem;",d="text-[9px]",u="text-[7.5px]",n="text-[7px]",m="text-[7.5px]",x="h-5"):w==="large"?(i="font-size: 13.5px; padding: 1rem;",d="text-[14px]",u="text-[11px]",n="text-[11px]",m="text-[12.5px]",x="h-11"):w==="esticado"?(i="font-size: 15px; padding: 1.25rem;",d="text-[16px]",u="text-[12px]",n="text-[12px]",m="text-[13.5px]",x="h-12"):w==="super_esticado"&&(i="font-size: 18px; padding: 1.75rem;",d="text-[20px]",u="text-[14px]",n="text-[14px]",m="text-[16.5px]",x="h-16");const f=[...new Set(t.map(h=>h.classGroup).filter(Boolean))],E=f.length?` (${f.join(", ")})`:"";return`
    <div class="bg-white border border-slate-300 rounded-lg text-slate-800 shadow-sm flex flex-col justify-between break-inside-avoid text-xs w-full" style="${i}">
      <div class="border-b border-slate-300 pb-1 mb-1.5 flex flex-wrap justify-between items-center gap-x-2 bg-slate-100 px-2 py-1 rounded">
        <span class="font-extrabold uppercase text-slate-900 whitespace-normal break-words ${d}">${e.displayName}${E}</span>
        <span title="${e.subject||"Professor"}" class="${u} text-[#5B99C2] font-extrabold uppercase tracking-tight whitespace-normal break-words">${ve(e.subject||"Professor")}</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="font-semibold text-slate-400 ${n} py-0.5 text-left w-[40px]">Hor</th>
            ${o.map(h=>`<th class="font-bold text-slate-700 ${n} py-0.5">${h}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(h=>`
            <tr class="${x}">
              <td class="font-extrabold text-[#2E5077] ${n} text-left py-0.5">${h}</td>
              ${o.map(C=>{const y=r[h][C];return`<td title="${y}" class="${m} py-0.5 whitespace-normal break-words ${y==="VAGA"?"text-rose-600 font-black":y==="HAF"?"text-[#5B99C2] font-black":y!=="------"?"text-slate-900 font-black":"text-slate-400"}">${y.split("/").map(Ve).join("/")}</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},De=(e,t,s)=>{console.log(`[DEBUG TurmaScheduleCard] turmaName="${e}", weekSchedules count=${t.length}, slots=${s.join(", ")}`);const a=["Seg","Ter","Qua","Qui","Sex"],o={};s.forEach(f=>{o[f]={},a.forEach(E=>{o[f][E]=null})}),t.forEach(f=>{var g,S;const E=ie(f.date),h=Ae(E),C=a[h-1],y=((g=f.startTime)==null?void 0:g.substring(0,5))||f.startTime;if(C&&o[y]){if(f.status!=="confirmed"&&f.status!=="pending"&&f.status!=="vaga"&&((S=f.subject)==null?void 0:S.toUpperCase())!=="HAF")return;const j=z.find(_=>_.uid===f.teacherId);o[y][C]={teacherName:(j==null?void 0:j.displayName)||f.teacherName||"------",subject:f.subject||"------",status:f.status}}});let r="font-size: 11px; padding: 0.75rem;",i="text-[12px]",d="text-[9.5px]",u="text-[9px]",n="text-[10px]",m="text-[8.5px]",x="h-11";return w==="small"?(r="font-size: 8.5px; padding: 0.5rem;",i="text-[9px]",d="text-[7.5px]",u="text-[7px]",n="text-[8.5px]",m="text-[7.5px]",x="h-8"):w==="large"?(r="font-size: 13.5px; padding: 1rem;",i="text-[14px]",d="text-[11px]",u="text-[11px]",n="text-[12.5px]",m="text-[11px]",x="h-16"):w==="esticado"?(r="font-size: 15px; padding: 1.25rem;",i="text-[16px]",d="text-[12px]",u="text-[12px]",n="text-[14px]",m="text-[12px]",x="h-14"):w==="super_esticado"&&(r="font-size: 18px; padding: 1.75rem;",i="text-[20px]",d="text-[14px]",u="text-[14px]",n="text-[17px]",m="text-[14px]",x="h-20"),`
    <div class="bg-white border border-slate-300 rounded-lg text-slate-800 shadow-sm flex flex-col justify-between break-inside-avoid text-xs w-full" style="${r}">
      <div class="border-b border-slate-300 pb-1 mb-1.5 flex flex-wrap justify-between items-center gap-x-2 bg-slate-100 px-2 py-1 rounded">
        <span class="font-extrabold uppercase text-slate-900 truncate ${i}">Turma: ${e}</span>
        <span class="${d} text-[#5B99C2] font-extrabold uppercase tracking-tight">GRADE HORÁRIA</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="font-semibold text-slate-400 ${u} py-0.5 text-left w-[40px]">Hor</th>
            ${a.map(f=>`<th class="font-bold text-slate-700 ${u} py-0.5">${f}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(f=>`
            <tr class="${x}">
              <td class="font-extrabold text-[#2E5077] ${u} text-left py-0.5 align-middle">${f}</td>
              ${a.map(E=>{var y;const h=o[f][E];return h?h.status==="vaga"?`
                    <td class="py-0.5 align-middle leading-tight whitespace-normal break-words">
                      <div class="font-black text-rose-600 ${n} font-black">VAGA</div>
                    </td>
                  `:((y=h.subject)==null?void 0:y.toUpperCase())==="HAF"?`
                    <td class="py-0.5 align-middle leading-tight whitespace-normal break-words">
                      <div class="font-black text-[#5B99C2] ${n}">HAF</div>
                    </td>
                  `:`
                  <td class="py-0.5 align-middle leading-tight whitespace-normal break-words">
                    <div class="font-black text-slate-900 whitespace-normal break-words ${n}">${h.teacherName}</div>
                    <div title="${h.subject}" class="text-slate-400 font-extrabold whitespace-normal break-words uppercase mt-0.5 ${m}">${ve(h.subject)}</div>
                  </td>
                `:`<td class="text-slate-300 ${n} py-0.5 align-middle">------</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},fe=()=>`
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1a1f3a 100%); min-height: 100vh; color: #fff; font-family: system-ui, -apple-system, sans-serif; overflow-x: hidden;">
    <style>
      @keyframes slideInDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes slideInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeInUp { from { opacity: 0; } to { opacity: 1; } }
      details summary:hover { color: #2563eb !important; }
      @media (max-width: 768px) {
        h1 { font-size: 1.75rem !important; }
        nav > div:nth-child(2) { display: none; }
      }
    </style>

    <!-- Navbar -->
    <nav style="position: fixed; top: 0; left: 0; right: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 1.5rem 2rem; z-index: 40; display: flex; align-items: center; justify-content: space-between;">
      <div style="display: flex; align-items: center; gap: 1rem;">
        ${le(140,40)}
      </div>
      <div style="display: flex; gap: 2rem; align-items: center;">
        <a onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Como Funciona</a>
        <a onclick="document.getElementById('resources').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Recursos</a>
        <a onclick="document.getElementById('faq').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">FAQ</a>
        <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 0.7rem 1.5rem; border-radius: 0.5rem; font-weight: 600; cursor: pointer; transition: all 0.3s;">Acessar Portal</button>
      </div>
    </nav>

    <!-- Hero Section -->
    <section style="padding-top: 8rem; padding-bottom: 4rem; text-align: center; animation: slideInDown 0.8s ease-out;">
      <div style="max-width: 900px; margin: 0 auto; padding: 0 1rem;">
        <div style="background: rgba(37, 99, 235, 0.1); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 2rem; padding: 0.5rem 1.5rem; display: inline-block; margin-bottom: 2rem;">
          <span style="color: #06b6d4; font-weight: 600; font-size: 0.85rem;">🚀 Gestão Escolar Inteligente com Zero Aulas Vagas • v2.4 Pro</span>
        </div>
        <h1 style="font-size: 3.5rem; font-weight: 900; line-height: 1.1; margin-bottom: 1.5rem; letter-spacing: -1px;">A grade escolar que<br><span style="background: linear-gradient(135deg, #2563eb, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">elimina aulas vagas</span><br>em segundos.</h1>
        <p style="font-size: 1.25rem; color: #cbd5e1; margin-bottom: 2.5rem; max-width: 600px; margin-left: auto; margin-right: auto; line-height: 1.6;">Substituição automática de professores ausentes, gestão de laboratórios em tempo real e controle absoluto para a coordenação pedagógica.</p>
        <div style="display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap;">
          <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 30px rgba(37, 99, 235, 0.3);">🎓 Entrar no Portal da Escola</button>
          <button onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="background: transparent; color: white; border: 2px solid rgba(255, 255, 255, 0.2); padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s;">Ver Demonstração Interativa</button>
        </div>
        <div style="display: flex; gap: 3rem; justify-content: center; margin-top: 3rem; flex-wrap: wrap; font-weight: 600; font-size: 0.9rem;">
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Pronto para uso imediato</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Armazenamento Seguro e Criptografado</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> 1 Toque no Celular do Professor</div>
        </div>
      </div>
    </section>

    <!-- Stats Section -->
    <section style="background: rgba(15, 23, 42, 0.5); border-top: 1px solid rgba(37, 99, 235, 0.1); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 4rem 2rem; animation: fadeInUp 1s ease-out 0.3s both;">
      <div style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem; text-align: center;">
        <div>
          <div style="font-size: 2.5rem; font-weight: 900; color: #2563eb;">+120 mil</div>
          <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; margin-top: 0.5rem;">Aulas Vagas Evitadas</div>
        </div>
        <div>
          <div style="font-size: 2.5rem; font-weight: 900; color: #06b6d4;">99.4%</div>
          <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; margin-top: 0.5rem;">Taxa de Presença Coberta</div>
        </div>
        <div>
          <div style="font-size: 2.5rem; font-weight: 900; color: #2563eb;">-85%</div>
          <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; margin-top: 0.5rem;">Tempo da Coordenação</div>
        </div>
        <div>
          <div style="font-size: 2.5rem; font-weight: 900; color: #06b6d4;">42 seg</div>
          <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; margin-top: 0.5rem;">Tempo Médio de Substituição</div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section id="features" style="padding: 6rem 2rem; max-width: 1200px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">FLUXO INTELIGENTE DE PONTA A PONTA</div>
        <h2 style="font-size: 2.5rem; font-weight: 900; margin-bottom: 1rem;">Como o Studia transforma a rotina da sua escola</h2>
        <p style="color: #cbd5e1; font-size: 1.1rem; max-width: 600px; margin: 0 auto;">Do cadastro da grade horária até a gestão de imprevistos e emissão de relatórios oficiais em tempo real.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
        <div style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.4s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #2563eb, #1e40af); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">⚡</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Zero Alunos Ociosos</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Quando ocorre uma falta, o algoritmo Studia cruza os horários livres no mesmo turno e sugere substitutos compatíveis. A coordenação designa com apenas 1 clique.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(37, 99, 235, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Substituição em 42 seg</div>
        </div>

        <div style="background: rgba(6, 182, 212, 0.05); border: 1px solid rgba(6, 182, 212, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.5s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #06b6d4, #0891b2); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">🛡️</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Espaços Otimizados</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Controle de agendamentos para salas de informática, laboratórios de ciências e quadras esportivas sem sobreposição de turmas.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(6, 182, 212, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Fim dos conflitos de espaço</div>
        </div>

        <div style="background: rgba(168, 85, 247, 0.05); border: 1px solid rgba(168, 85, 247, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.6s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #a855f7, #9333ea); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📊</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Visão 360° da Escola</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Um dashboard dinâmico com o mapa de todas as salas ativas simultaneamente, identificando quais professores estão em aula, quais salas estão vazias e as posições ativas.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(168, 85, 247, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Controle visual total</div>
        </div>

        <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.7s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📄</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Relatórios Executivos & Impressão A4 Paisagem</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Gere gráficos de assiduidade por docente, taxas de cobertura e exportação em formato padrão A4 Paisagem para quadro de avisos ou arquivo da secretaria.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(239, 68, 68, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ PDF pronto para impressão</div>
        </div>
      </div>
    </section>

    <!-- Testimonials -->
    <section style="padding: 6rem 2rem; max-width: 1200px; margin: 0 auto; border-top: 1px solid rgba(37, 99, 235, 0.1);">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">CASOS DE SUCESSO</div>
        <h2 style="font-size: 2.5rem; font-weight: 900;">O que dizem os diretores e coordenadores</h2>
      </div>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
        <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 1rem; padding: 2rem;">
          <div style="color: #fbbf24; margin-bottom: 1rem;">★★★★★</div>
          <p style="color: #cbd5e1; margin-bottom: 1.5rem; font-style: italic;">"O Studia acabou com o pesadelo das 07h da manhã quando um professor passava mal. Em 30 segundos achamos um substituto e a escola funciona sem tumulto."</p>
          <p style="color: #fff; font-weight: 600;">Profª Helena Vasconcelos</p>
          <p style="color: #94a3b8; font-size: 0.9rem;">Diretora Pedagógica • Colégio Santa Cruz</p>
        </div>

        <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 1rem; padding: 2rem;">
          <div style="color: #fbbf24; margin-bottom: 1rem;">★★★★★</div>
          <p style="color: #cbd5e1; margin-bottom: 1.5rem; font-style: italic;">"Os professores adoraram a facilidade de confirmar a presença no celular. A gestão de laboratórios também economizou incontáveis discussões."</p>
          <p style="color: #fff; font-weight: 600;">Marcos Drummond</p>
          <p style="color: #94a3b8; font-size: 0.9rem;">Coordenador Geral • Instituto Drummond</p>
        </div>

        <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 1rem; padding: 2rem;">
          <div style="color: #fbbf24; margin-bottom: 1rem;">★★★★★</div>
          <p style="color: #cbd5e1; margin-bottom: 1.5rem; font-style: italic;">"A exportação em formato A4 e os relatórios em PDF nos deram total conformidade nas reuniões com os pais e auditórios de ensino."</p>
          <p style="color: #fff; font-weight: 600;">Cláudia Fontes</p>
          <p style="color: #94a3b8; font-size: 0.9rem;">Gestora Escolar • Rede Prisma de Ensino</p>
        </div>
      </div>
    </section>

    <!-- FAQ -->
    <section id="faq" style="padding: 6rem 2rem; max-width: 900px; margin: 0 auto; border-top: 1px solid rgba(37, 99, 235, 0.1);">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">PERGUNTAS FREQUENTES</div>
        <h2 style="font-size: 2.5rem; font-weight: 900;">Tire suas dúvidas sobre o Studia</h2>
      </div>
      <div style="space-y: 2rem;">
        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como o Studia resolve as aulas vagas tão rápido?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">O algoritmo analisa em tempo real os horários livres dos professores no mesmo turno e apresenta as melhores opções de compatibilidade. A coordenação clica uma vez e pronto — a informação é enviada ao professor via push notification.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os dados da minha escola são seguros e privados?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Sim. Todos os dados são criptografados com segurança de nível institucional e sincronizados em tempo real. O Studia não compartilha informações com terceiros e opera sob rigoroso compliance de privacidade.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os professores precisam instalar algum aplicativo pesado?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Não. O Studia é acessível 100% via navegador web. Os professores recebem notificações push no celular, mas a plataforma roda perfeitamente em qualquer smartphone moderno sem necessidade de app nativo.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como funciona a ativação com PIX e Cartão de Crédito?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">O Studia oferece planos por escola com pagamento recorrente via PIX ou cartão. Depois da ativação, todo o sistema funciona normalmente com suporte integral da equipe Studia COP.</p>
        </details>
      </div>
    </section>

    <!-- Footer -->
    <footer style="background: rgba(15, 23, 42, 0.8); border-top: 1px solid rgba(37, 99, 235, 0.1); padding: 3rem 2rem; text-align: center; color: #94a3b8;">
      <p>© 2026 Studia SaaS — Todos os direitos reservados.</p>
      <p style="margin-top: 1rem; font-size: 0.9rem;">Criptografia de nível institucional com sincronização em tempo real.</p>
    </footer>

    <!-- Login/Register Modal -->
    <div id="login-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 ${M==="closed"?"hidden":""}">
      <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLoginModal()"></div>
      <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
        <div class="flex justify-center mb-6">
          ${le(160,44)}
        </div>
        <div class="flex gap-2 mb-8 bg-slate-100 p-1.5 rounded-xl">
            <button onclick="actions.toggleAuthMode('login')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${M==="login"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Entrar</button>
            <button onclick="actions.toggleAuthMode('register')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${M==="register"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Criar Conta</button>
        </div>

        <h3 class="text-2xl font-bold mb-2">${M==="login"?"Bem-vindo de volta":"Nova conta Studia"}</h3>
        <p class="text-slate-500 text-sm mb-6 font-medium">${M==="login"?"Acesse seu painel.":"Crie sua conta de professor."}</p>

        <div class="space-y-4">
          ${M==="register"?`
            <input type="text" id="auth-name" placeholder="Seu nome completo" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
            <input type="text" id="auth-subject" placeholder="Matérias (separe por vírgula)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
          `:""}
          <input type="email" id="auth-email" placeholder="nome@escola.pr.gov.br" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
          <input type="password" id="auth-password" placeholder="Sua senha" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">

          <button onclick="${M==="login"?"actions.login()":"actions.register()"}" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold shadow-md shadow-blue-500/15 mt-2 transition-all">
            ${M==="login"?"Entrar":"Cadastrar"}
          </button>
        </div>
      </div>
    </div>
  </div>
`,de=()=>{const e=ge();let t=[];k==="matutino"?t=["07:30","08:20","09:10","10:15","11:00","11:45"]:k==="vespertino"?t=["13:00","13:50","14:40","15:45","16:30","17:15"]:k==="noturno"?t=["18:45","19:30","20:30","21:15","22:00"]:t=e.length>0?e:["07:30","08:20","09:10","10:15","11:00","11:45"];const s=[{id:"horarios",icon:"calendar",label:"Meus Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"materias",icon:"book",label:"Minhas Matérias"},{id:"atestados",icon:"file-text",label:"Meus Atestados"}],a={initials:l.displayName?l.displayName.slice(0,2).toUpperCase():"PR",name:l.displayName,subtitle:l.subject||"Professor"};return`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${ke({theme:"light",sectionLabel:"Principal",navItems:s,profile:a})}
    ${$e({theme:"light",sectionLabel:"Principal",navItems:s,profile:a,drawerId:"mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-toggle-mobile-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <h2 class="font-bold text-base md:text-lg capitalize">${v==="horarios"?"Meus Horários":v==="labs"?"Laboratórios":v==="materias"?"Minhas Matérias":"Meus Atestados"}</h2>
        </div>
        <div class="flex gap-2">
          ${v==="atestados"?`
            <button onclick="actions.showCertModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm shadow-md transition-all" id="btn-new-cert">
                <i data-lucide="file-plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Novo <span class="hidden sm:inline">Atestado</span></span>
            </button>
          `:""}
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm shadow-md transition-all" id="btn-teacher-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
          <button onclick="actions.refreshSchedules()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm transition-all" id="btn-refresh-teacher-schedules">
            <i data-lucide="refresh-cw" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Atualizar</span>
          </button>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?`
          <!-- Switch between sub-tabs with counts -->
          <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-6 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
            <button onclick="actions.setTeacherSchedulesTab('grid')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${pe==="grid"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
              <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Horários Completa
            </button>
          </div>

          ${pe==="grid"?`
            <!-- Grid Control Box -->
            <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 print:hidden">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Turno / Períodos</label>
                  <select onchange="actions.setReportTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="matutino" ${k==="matutino"?"selected":""}>Manhã (07:30 - 11:45)</option>
                    <option value="vespertino" ${k==="vespertino"?"selected":""}>Tarde (13:00 - 17:15)</option>
                    <option value="noturno" ${k==="noturno"?"selected":""}>Noite (18:45 - 22:45)</option>
                    <option value="auto" ${k==="auto"?"selected":""}>Auto-detecção</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Tamanho da Grade</label>
                  <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
                    <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
                    <option value="large" ${w==="large"?"selected":""}>Grande</option>
                    <option value="esticado" ${w==="esticado"?"selected":""}>Descrição Larga</option>
                    <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Página Inteira</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Opções Rápidas</label>
                  <button id="btn-download-pdf-teacher" onclick="actions.downloadTeacherPDF()" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold text-sm shadow-md flex items-center justify-center gap-1.5 transition-all">
                    <i data-lucide="download" class="w-4 h-4"></i> Baixar PDF
                  </button>
                </div>
              </div>
            </div>

            <!-- Beautiful Grid Sheet Preview -->
            <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-8 md:p-12 shadow-xl relative overflow-hidden">
              <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
                <div class="flex items-center gap-4">
                  <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
                    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
                    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
                    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
                    <g transform="translate(68, 2)">
                      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                    </g>
                    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
                    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
                  </svg>
                </div>
                
                <div class="text-center md:text-right">
                  <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${X}</h4>
                  <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
                    Grade de Horários Individual do Professor
                  </p>
                </div>
              </div>

              <!-- Center wrapper -->
              <div class="flex justify-center">
                <div class="w-full max-w-2xl overflow-x-auto pb-4 scrollbar-none">
                  <div class="min-w-[550px]">
                    ${we(l,$.filter(o=>o.teacherId===l.uid),t)}
                  </div>
                </div>
              </div>

              <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
                <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
              </div>
            </div>
          `:`
            <!-- Sched List -->
            <div class="grid gap-6">
              ${$.map(o=>`
                <div class="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 md:gap-6 print:shadow-none print:border-slate-300">
                  <div class="flex items-center gap-4 md:gap-6 min-w-0 flex-1">
                    <div class="w-16 text-center border-r pr-4 md:pr-6 shrink-0">
                        <p class="text-lg font-black text-slate-800">${o.startTime}</p>
                    </div>
                    <div class="min-w-0 flex-1">
                      <h3 class="text-base md:text-xl font-black text-slate-900 truncate flex items-center gap-2">
                        ${o.subject}
                        ${o.classGroup?`<span class="bg-blue-100 text-[#2E5077] text-[10px] uppercase font-black px-2 py-0.5 rounded">${o.classGroup}</span>`:""}
                      </h3>
                      <div class="flex flex-wrap items-center gap-3 md:gap-4 mt-1">
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="map-pin" class="w-3.5 h-3.5"></i> ${o.room}</span>
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="calendar" class="w-3.5 h-3.5"></i> ${o.date}</span>
                      </div>
                    </div>
                  </div>
                  <div class="flex flex-col gap-3 w-full sm:w-auto sm:min-w-[200px] shrink-0 print:hidden">
                    <div class="text-center py-2 bg-slate-50 rounded-xl border text-[10px] font-black uppercase tracking-widest ${o.status==="confirmed"?"text-blue-600":o.status==="absent"?"text-rose-500":o.status==="vaga"?"text-rose-600 font-black":"text-amber-500"}">
                      ${o.status==="vaga"?"AULA VAGA":o.status==="confirmed"?"Confirmado":o.status==="absent"?"Ausente":"Pendente"}
                    </div>
                  </div>
                </div>
              `).join("")}
            </div>
          `}
        `:""}
        ${v==="atestados"?`
          <div class="space-y-8 animate-fade-in">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 class="text-xl md:text-2xl font-black text-slate-900">Seus Atestados Médicos</h3>
                <p class="text-xs text-slate-500 font-bold">Acompanhe seus atestados enviados e o status de homologação.</p>
              </div>
              <button onclick="actions.showCertModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
                <i data-lucide="plus" class="w-4 h-4"></i> Enviar Novo Atestado
              </button>
            </div>
            
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div class="overflow-x-auto pr-2">
                <table class="w-full text-left min-w-[700px]">
                  <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
                    <tr>
                      <th class="px-8 py-5">Data da Falta</th>
                      <th class="px-8 py-4">Motivo</th>
                      <th class="px-8 py-4">Imagem do Atestado</th>
                      <th class="px-8 py-4">Status de Aprovação</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-50">
                    ${(()=>{const o=J.filter(r=>r.teacherId===l.uid);return o.length===0?`
                          <tr>
                            <td colspan="4" class="px-8 py-16 text-center text-slate-400 font-bold text-sm">
                              Você ainda não enviou nenhum atestado médico.
                            </td>
                          </tr>
                        `:o.map(r=>`
                        <tr class="hover:bg-slate-50/50 transition-all">
                          <td class="px-8 py-5 font-bold text-slate-800">${r.date}</td>
                          <td class="px-8 py-5 text-sm text-slate-600 font-medium">${r.reason}</td>
                          <td class="px-8 py-5">
                            ${r.id?`
                              <button onclick="actions.viewImageById(${r.id})" class="bg-blue-50 text-blue-600 hover:bg-blue-100 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 border border-blue-100 transition-all cursor-pointer">
                                <i data-lucide="eye" class="w-4 h-4"></i> Visualizar Foto
                              </button>
                            `:`
                              <span class="text-slate-400 font-bold text-[10px] uppercase">Sem imagem</span>
                            `}
                          </td>
                          <td class="px-8 py-5">
                            <span class="text-[10px] font-black uppercase px-3 py-1.5 rounded-full ${r.status==="approved"?"bg-emerald-50 text-emerald-700 border border-emerald-100":"bg-amber-50 text-amber-700 border border-amber-100"}">
                              ${r.status==="approved"?"Aprovado":"Aguardando Aprovação"}
                            </span>
                          </td>
                        </tr>
                      `).join("")})()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        `:""}
        ${v==="materias"?dt():""}
        ${v==="labs"?Be():""}
      </div>
    </main>
    
    ${ye()}
  </div>
  `},We=e=>{const t=z.find(s=>s.uid===e);return t?F.filter(s=>s.school_id===t.school_id&&(s.teacherIds||[]).includes(e)).map(s=>s.subject):[]},Le=()=>`
  <!-- Same Create Modal logic but with current state -->
  <div id="create-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Novo Agendamento</h3>
      <form onsubmit="actions.createSchedule(event)" class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <input type="text" id="form-subject" list="form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <datalist id="form-subject-options"></datalist>
          <input type="text" id="form-class-group" placeholder="Turma (ex: 9A, 3BI)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <input type="date" id="form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <input type="text" id="form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <input type="time" id="form-start" oninput="actions.updateConsecutiveSchedulePreview()" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" value="18:45" required>
          <input type="time" id="form-end" oninput="actions.updateConsecutiveSchedulePreview()" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" value="22:45" required>
        </div>
        <div class="rounded-xl border border-slate-200 p-3">
          <label class="flex cursor-pointer items-center gap-2 text-sm font-bold text-slate-700">
            <input type="checkbox" id="form-double-lesson" onchange="actions.updateConsecutiveSchedulePreview()" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
            Duas aulas seguidas
          </label>
          <p class="mt-1 pl-6 text-xs font-medium text-slate-500">O segundo horário começa quando o primeiro termina e terá a mesma duração.</p>
          <p id="form-double-lesson-preview" class="mt-2 hidden pl-6 text-xs font-bold text-blue-700"></p>
        </div>
        <select id="form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <option value="">Selecione o Professor</option>
          ${z.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
        </select>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar Horário</button>
        </div>
      </form>
    </div>
  </div>
`,Pe=()=>`
  <div id="edit-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideEditModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl overflow-y-auto max-h-[90vh]">
      <h3 class="text-2xl font-bold mb-6 text-slate-800">Editar Horário</h3>
      <form onsubmit="actions.updateSchedule(event)" class="space-y-4">
        <input type="hidden" id="edit-form-id">
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Matéria</label>
            <input type="text" id="edit-form-subject" list="edit-form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <datalist id="edit-form-subject-options"></datalist>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Turma</label>
            <input type="text" id="edit-form-class-group" placeholder="Turma (ex: 9A, 3BI)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Data</label>
            <input type="date" id="edit-form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Sala / Local</label>
            <input type="text" id="edit-form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Início</label>
            <input type="time" id="edit-form-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Término</label>
            <input type="time" id="edit-form-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Professor</label>
          <select id="edit-form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value, '', 'edit-form')" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="">Selecione o Professor</option>
            ${z.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
          </select>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Status</label>
          <select id="edit-form-status" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="pending">Pendente</option>
            <option value="confirmed">Confirmado</option>
            <option value="absent">Falta / Ausente</option>
            <option value="vaga">Aula Vaga</option>
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideEditModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Salvar</button>
        </div>
      </form>
    </div>
  </div>
`,ze=()=>`
  <div id="delete-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideDeleteModal()"></div>
    <div class="bg-white w-full max-w-sm rounded-[2rem] p-6 relative z-10 shadow-2xl border border-slate-100">
      <div class="flex items-center gap-3 mb-4 text-rose-600">
        <div class="bg-rose-50 p-2.5 rounded-2xl">
          <i data-lucide="alert-triangle" class="w-6 h-6"></i>
        </div>
        <h3 class="text-lg font-black text-slate-800">Confirmar Exclusão</h3>
      </div>
      <p class="text-xs text-slate-500 mb-6 leading-relaxed">Você tem certeza de que deseja excluir este horário? Esta ação não poderá ser desfeita.</p>
      <input type="hidden" id="delete-schedule-id">
      <div class="flex gap-3">
        <button onclick="actions.hideDeleteModal()" class="flex-1 py-3 text-xs font-bold text-slate-600 border rounded-xl hover:bg-slate-50 transition-all">Cancelar</button>
        <button onclick="actions.confirmDeleteSchedule()" class="flex-1 py-3 text-xs font-bold text-white bg-rose-600 rounded-xl hover:bg-rose-700 shadow-lg shadow-rose-600/10 transition-all">Excluir</button>
      </div>
    </div>
  </div>
`,Qe=()=>`
  <div id="lab-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLabModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Reservar Laboratório</h3>
      <form onsubmit="actions.createLabBooking(event)" class="space-y-4">
        <select id="lab-type" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <option value="info">Informática</option>
          <option value="chem">Química</option>
        </select>
        <input type="date" id="lab-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        <div class="grid grid-cols-2 gap-4">
          <input type="time" id="lab-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <input type="time" id="lab-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideLabModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Reservar</button>
        </div>
      </form>
    </div>
  </div>
`,ye=()=>`
  <div id="cert-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCertModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Incluir Atestado Médico</h3>
      <form onsubmit="actions.submitCert(event)" class="space-y-4">
        <p class="text-xs text-slate-500 font-bold uppercase mb-2">Atenção: Ao aprovar este atestado, as aulas do dia serão marcadas automaticamente como "Aulas Vagas".</p>
        <input type="date" id="cert-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        <textarea id="cert-reason" placeholder="Motivo da ausência" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[100px] text-slate-900" required></textarea>

        <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase">Anexar Foto do Atestado</label>
            <div class="relative group">
                <input type="file" id="cert-image" accept="image/*" capture="environment" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20" onchange="actions.previewCertImage(event)">
                <div id="cert-upload-placeholder" class="w-full border-2 border-dashed border-slate-200 rounded-lg p-8 flex flex-col items-center justify-center gap-2 group-hover:border-blue-400 transition-all">
                    <i data-lucide="camera" class="text-slate-400 group-hover:text-blue-600 transition-all"></i>
                    <p class="text-sm font-bold text-slate-500">Toque para tirar foto ou selecionar</p>
                </div>
            </div>
            <div id="cert-preview-container" class="hidden relative mt-4 border border-slate-200 rounded-lg overflow-hidden bg-slate-50 p-2">
                <img id="cert-preview-img" class="w-full max-h-64 object-contain rounded-lg mx-auto" />
                <button type="button" onclick="actions.clearCertImage()" class="absolute top-4 right-4 bg-rose-600 hover:bg-rose-700 text-white p-2 rounded-lg shadow-lg transition-all flex items-center justify-center" title="Remover Imagem">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </div>
        </div>

        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCertModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Enviar</button>
        </div>
      </form>
    </div>
  </div>
`,Je=()=>`
  <div id="create-escola-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateEscolaModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Nova Escola</h3>
      <form onsubmit="actions.createSchool(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome da Escola</label>
          <input type="text" id="escola-name" placeholder="Ex: Colégio Estadual..." class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateEscolaModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,Re=({viewerRole:e="dev"}={})=>`
  <div id="create-user-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateUserModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Novo Usuário</h3>
      <form onsubmit="actions.createUser(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome</label>
          <input type="text" id="user-displayname" placeholder="Ex: João Silva" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">E-mail</label>
          <input type="email" id="user-email" placeholder="Ex: joao@example.com" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Senha</label>
          <input type="password" id="user-password" placeholder="Mínimo 8 caracteres" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required minlength="8">
        </div>
        ${e==="dev"?`
          <div>
            <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Escola</label>
            <select id="user-school" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
              <option value="">Selecione uma escola</option>
              ${R.map(t=>`<option value="${t.id}">${t.name}</option>`).join("")}
            </select>
          </div>
        `:""}
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Matérias</label>
          <input type="text" id="user-subject" placeholder="Ex: Matemática, Física, Química" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900">
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Cargo</label>
          <select id="user-role" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            ${e==="dev"?`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
                <option value="dev">Desenvolvedor</option>
              `:`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
              `}
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateUserModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,Ze=()=>{const e=!!(I!=null&&I.api.ok)&&!!(I!=null&&I.database.ok),t=$.length,s=B.length,a=q.length,o=J.length;return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Visão geral da plataforma</h3>
          <p class="text-sm text-slate-500 font-medium">Monitoramento da API, usuários e dados operacionais do site.</p>
        </div>
        <div class="inline-flex items-center gap-2 rounded-full ${e?"bg-emerald-50 text-emerald-700":"bg-amber-50 text-amber-700"} px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
          <i data-lucide="database" class="w-3.5 h-3.5"></i> ${e?"Supabase online":"Modo local"}
        </div>
      </div>

      <div class="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Status</p>
            <span class="w-2.5 h-2.5 rounded-full ${e?"bg-emerald-500":"bg-amber-400"}"></span>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${e?"OK":"Local"}</p>
          <p class="mt-2 text-sm text-slate-500">Conexão com a API express</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Usuários</p>
            <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${s}</p>
          <p class="mt-2 text-sm text-slate-500">Contas cadastradas</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Horários</p>
            <i data-lucide="calendar" class="w-4 h-4 text-violet-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${t}</p>
          <p class="mt-2 text-sm text-slate-500">Registros no banco</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Labs</p>
            <i data-lucide="beaker" class="w-4 h-4 text-emerald-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${a}</p>
          <p class="mt-2 text-sm text-slate-500">Reservas ativas</p>
        </div>
      </div>

      <div class="grid xl:grid-cols-[1.1fr_0.9fr] gap-6">
        <div class="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
          <h4 class="text-lg font-black text-slate-900">Infraestrutura do projeto</h4>
          <div class="mt-5 space-y-4">
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Banco de dados</span>
              <span class="text-sm font-black text-slate-900">Supabase Postgres</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Autenticação</span>
              <span class="text-sm font-black text-slate-900">Auth + RLS</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">API</span>
              <span class="text-sm font-black text-slate-900">Express + Vite</span>
            </div>
            <div class="flex justify-between items-center pb-1">
              <span class="text-sm font-semibold text-slate-500">Atestados</span>
              <span class="text-sm font-black text-slate-900">${o}</span>
            </div>
          </div>
        </div>

        <div class="bg-slate-900 rounded-3xl p-6 shadow-lg text-white">
          <div class="flex items-center justify-between">
            <h4 class="text-lg font-black">Environment</h4>
            <span class="inline-flex items-center gap-2 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-200">
              <i data-lucide="shield-check" class="w-3.5 h-3.5"></i> Seguro
            </span>
          </div>
          <div class="mt-5 space-y-4 text-sm text-slate-300">
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">API base</p>
              <p class="mt-1 font-semibold break-all">${D||"http://localhost:3000"}</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Proteção</p>
              <p class="mt-1 font-semibold">Service role no backend apenas</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Armazenamento</p>
              <p class="mt-1 font-semibold">Usuários, horários, laboratórios e certificados</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `},P=e=>String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),ee=()=>`
  <button onclick="actions.refreshDeveloperPanel()" class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800">
    <i data-lucide="refresh-cw" class="h-4 w-4"></i> Atualizar
  </button>
`,te=e=>Q[e]?`
  <div class="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">${P(Q[e])}</div>
`:"",Ke=()=>{const e=I,t=e==null?void 0:e.api.ok,s=e==null?void 0:e.database.ok;return`
    <div class="space-y-6">
      <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Saúde do sistema</h3>
          <p class="mt-1 text-sm font-medium text-slate-500">Estado atual da API e conexão com o banco de dados.</p>
        </div>
        ${ee()}
      </header>
      ${te("diagnostics")}
      <div class="grid gap-4 md:grid-cols-3">
        ${[{title:"API",ok:t,detail:t===void 0?"Aguardando verificação":t?"Respondendo normalmente":"Indisponível"},{title:"Banco de dados",ok:s,detail:s===void 0?"Aguardando verificação":s?`${e.database.latencyMs} ms de resposta`:"Falha ao consultar o banco"},{title:"Tempo ativo",ok:t,detail:e?`${Math.floor(e.uptimeSeconds/60)} min`:"Aguardando verificação"}].map(a=>`
          <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
              <h4 class="font-black text-slate-800">${a.title}</h4>
              <span class="rounded-full px-3 py-1 text-xs font-black ${a.ok===void 0?"bg-slate-100 text-slate-500":a.ok?"bg-emerald-100 text-emerald-700":"bg-rose-100 text-rose-700"}">${a.ok===void 0?"PENDENTE":a.ok?"OK":"FALHA"}</span>
            </div>
            <p class="mt-4 text-sm font-semibold text-slate-500">${a.detail}</p>
          </article>
        `).join("")}
      </div>
      ${e?`<p class="text-xs font-medium text-slate-400">Verificado em ${new Date(e.checkedAt).toLocaleString("pt-BR")}.</p>`:""}
    </div>
  `},Ye=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Diagnóstico</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Testes de leitura nas tabelas e verificações básicas de integridade.</p>
      </div>
      ${ee()}
    </header>
    ${te("diagnostics")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <h4 class="border-b border-slate-100 p-5 font-black text-slate-800">Conexão e latência por tabela</h4>
      ${I?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[560px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Tabela</th><th class="px-5 py-3">Status</th><th class="px-5 py-3">Registros</th><th class="px-5 py-3">Resposta</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${I.probes.map(e=>`
                <tr>
                  <td class="px-5 py-3 font-semibold text-slate-700">${P(e.table)}</td>
                  <td class="px-5 py-3 font-bold ${e.ok?"text-emerald-700":"text-rose-700"}">${e.ok?"OK":"Falha"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.records??"—"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.latencyMs} ms</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Atualize para executar os testes.</p>'}
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Integridade básica</h4>
      <div class="mt-4 grid gap-3 md:grid-cols-2">
        ${((I==null?void 0:I.integrity)||[]).map(e=>`
          <div class="flex items-center justify-between gap-4 rounded-xl bg-slate-50 p-4">
            <span class="text-sm font-semibold text-slate-600">${P(e.name)}</span>
            <span class="text-sm font-black ${e.ok&&e.count===0?"text-emerald-700":"text-amber-700"}">${e.ok?e.count:"Erro na consulta"}</span>
          </div>
        `).join("")}
        ${I?"":'<p class="text-sm text-slate-500">Os resultados aparecerão após a verificação.</p>'}
      </div>
    </section>
  </div>
`,Xe=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Logs de erros</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimos 100 erros HTTP 5xx registrados pela API. O conteúdo dos pedidos não é armazenado.</p>
      </div>
      ${ee()}
    </header>
    ${te("logs")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${ue.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[620px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Método</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Código</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${ue.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-bold text-slate-700">${P(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${P(e.route)}</td><td class="px-5 py-3 font-black text-rose-700">${P(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhum erro registrado ou ainda não há logs disponíveis.</p>'}
    </section>
  </div>
`,et=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Auditoria</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimas 100 alterações concluídas, com usuário, rota e horário.</p>
      </div>
      ${ee()}
    </header>
    ${te("audit")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${ce.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Usuário</th><th class="px-5 py-3">Ação</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Resultado</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${ce.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${P(e.actor_uid)} <span class="font-sans">(${P(e.actor_role)})</span></td><td class="px-5 py-3 font-bold text-slate-700">${P(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${P(e.route)}</td><td class="px-5 py-3 font-semibold text-emerald-700">${P(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhuma alteração registrada ou ainda não há eventos disponíveis.</p>'}
    </section>
  </div>
`,tt=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Dados e backups</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Consulte volumes e exporte dados selecionados da plataforma.</p>
      </div>
      ${ee()}
    </header>
    ${te("diagnostics")}
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Registros por tabela</h4>
      <div class="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        ${((I==null?void 0:I.probes)||[]).map(e=>`
          <div class="rounded-xl bg-slate-50 p-4">
            <p class="text-xs font-bold uppercase text-slate-400">${P(e.table)}</p>
            <p class="mt-2 text-2xl font-black text-slate-800">${e.ok?e.records:"Consulta falhou"}</p>
          </div>
        `).join("")}
        ${I?"":'<p class="text-sm text-slate-500">Atualize para consultar as tabelas.</p>'}
      </div>
    </section>
    <section class="rounded-2xl border border-amber-200 bg-amber-50 p-5">
      <h4 class="font-black text-amber-900">Exportação CSV</h4>
      <p class="mt-1 text-sm text-amber-800">Os arquivos podem conter dados pessoais. Escolha uma tabela e confirme antes de baixar; cada exportação tem limite de 5.000 registros.</p>
      <div class="mt-4 flex flex-col gap-3 sm:flex-row">
        <select id="dev-export-resource" class="rounded-xl border border-amber-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700">
          <option value="users">Usuários</option>
          <option value="schools">Escolas</option>
          <option value="schedules">Horários</option>
          <option value="lab_bookings">Reservas de laboratório</option>
          <option value="certificates">Atestados (sem imagens)</option>
          <option value="school_subjects">Matérias da escola</option>
          <option value="teacher_subjects">Vínculos de matérias</option>
        </select>
        <button onclick="actions.exportDeveloperData()" class="rounded-xl bg-amber-700 px-5 py-2.5 text-sm font-bold text-white hover:bg-amber-800">Exportar CSV</button>
      </div>
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Backup e restauração</h4>
      <p class="mt-2 text-sm leading-6 text-slate-600">Backups completos devem ser criados e restaurados pelo painel do Supabase, que controla a retenção e os snapshots do projeto. Antes de uma alteração estrutural, confira o backup mais recente e teste a restauração em um ambiente separado.</p>
      <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" class="mt-4 inline-flex items-center gap-2 font-bold text-blue-700 hover:text-blue-800">Abrir painel do Supabase <i data-lucide="external-link" class="h-4 w-4"></i></a>
    </section>
  </div>
`,st=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-white/10 text-white font-bold":"text-slate-400 hover:bg-white/5 hover:text-white"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,at=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-blue-50 text-blue-700 font-bold border-l-2 border-blue-600":"text-slate-500 hover:bg-slate-50 hover:text-slate-800"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,ke=({theme:e="light",sectionLabel:t,navItems:s,profile:a})=>{const o=e==="dark",r=o?st:at;return`
    <aside class="w-64 border-r ${o?"bg-slate-900 border-slate-800 text-slate-300":"bg-white border-slate-200 text-slate-500"} hidden md:flex flex-col p-6 print:hidden shrink-0">
      <div class="flex items-center mb-10 px-2 shrink-0">${le(170,46)}</div>
      <p class="text-[10px] font-bold ${o?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-4">${t}</p>
      <nav class="space-y-1 flex-1">
        ${s.map(i=>r(i.id,i.icon,i.label)).join("")}
      </nav>
      ${a?`
      <div class="mt-auto pt-6 border-t ${o?"border-slate-800":"border-slate-200"} mb-6 px-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-full ${o?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
            ${a.initials}
          </div>
          <div class="overflow-hidden">
            <p class="${o?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
            <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
          </div>
        </div>
      </div>
      `:""}
      <button onclick="actions.logout()" class="flex items-center gap-3 px-4 py-3 rounded-xl ${o?"hover:bg-slate-800 text-slate-300":"hover:bg-slate-50 text-slate-500 hover:text-slate-900"} transition-all font-semibold">
        <i data-lucide="log-out"></i> Sair
      </button>
    </aside>
  `},$e=({theme:e="light",sectionLabel:t,navItems:s,profile:a,drawerId:o})=>{if(!me)return"";const r=e==="dark";return`
    <div class="fixed inset-0 z-50 flex md:hidden" id="${o}">
      <div class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm shadow-sm" onclick="actions.toggleMobileMenu(false)"></div>
      <div class="relative flex flex-col w-72 max-w-[80vw] h-full ${r?"bg-slate-900 text-slate-300":"bg-white"} p-6 shadow-2xl transition-all duration-300 ease-in-out">
        <div class="flex items-center justify-between mb-8 px-2">
          <div class="flex items-center">${le(140,38)}</div>
          <button onclick="actions.toggleMobileMenu(false)" class="p-2 -mr-2 rounded-lg ${r?"text-slate-400 hover:text-white hover:bg-white/5":"text-slate-400 hover:text-slate-600 hover:bg-slate-50"}">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <p class="text-[10px] font-black ${r?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-2">${t}</p>
        <nav class="space-y-1.5 flex-1">
          ${s.map(i=>`
            <button onclick="actions.switchTabMobile('${i.id}')" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===i.id?r?"bg-white/10 text-white font-bold":"bg-blue-50 text-blue-700 font-bold":r?"text-slate-400 hover:bg-white/5 hover:text-white":"text-slate-500 hover:bg-slate-50"}">
              <i data-lucide="${i.icon}"></i> ${i.label}
            </button>
          `).join("")}
        </nav>

        <div class="mt-auto pt-6 border-t ${r?"border-slate-800":"border-slate-200"} px-2 flex flex-col gap-4">
          ${a?`
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full ${r?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
              ${a.initials}
            </div>
            <div class="overflow-hidden">
              <p class="${r?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
              <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
            </div>
          </div>
          `:""}
          <button onclick="actions.logout()" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-rose-50 text-rose-600 transition-all font-semibold justify-center border border-rose-100 bg-rose-50/30">
            <i data-lucide="log-out"></i> Sair
          </button>
        </div>
      </div>
    </div>
  `},Ce=[{id:"overview",icon:"activity",label:"Visão geral"},{id:"dev_health",icon:"activity",label:"Saúde do sistema"},{id:"dev_diagnostics",icon:"search",label:"Diagnóstico"},{id:"dev_logs",icon:"file-text",label:"Logs de erros"},{id:"dev_audit",icon:"clipboard",label:"Auditoria"},{id:"dev_data",icon:"database",label:"Dados e backups"},{id:"escolas",icon:"building",label:"Escolas"},{id:"usuarios",icon:"users",label:"Usuários"}],je=[{id:"horarios",icon:"calendar",label:"Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"atestados",icon:"file-text",label:"Atestados"},{id:"usuarios",icon:"users",label:"Usuários"},{id:"relatorios",icon:"bar-chart",label:"Relatórios"}],ot=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${ke({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ce})}
    ${$e({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ce,drawerId:"dev-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-dev-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Área do desenvolvedor</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <span class="hidden md:inline-flex items-center gap-2 rounded-full bg-slate-900 text-white px-3 py-1.5 text-xs font-black uppercase tracking-[0.14em]"><i data-lucide="code-2" class="w-3.5 h-3.5"></i> Desenvolvedor</span>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="overview"?Ze():""}
        ${v==="dev_health"?Ke():""}
        ${v==="dev_diagnostics"?Ye():""}
        ${v==="dev_logs"?Xe():""}
        ${v==="dev_audit"?et():""}
        ${v==="dev_data"?tt():""}
        ${v==="escolas"?it():""}
        ${v==="usuarios"?Ne({viewerRole:"dev"}):""}
      </div>
    </main>

    ${Le()}
    ${ye()}
    ${Pe()}
    ${ze()}
    ${Je()}
    ${Re({viewerRole:"dev"})}
  </div>
`,rt=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${ke({theme:"light",sectionLabel:"Direção Pedagógica",navItems:je})}
    ${$e({theme:"light",sectionLabel:"Direção Pedagógica",navItems:je,drawerId:"diretor-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-diretor-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Direção Pedagógica</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex gap-2">
          ${v==="horarios"?`
            <button onclick="actions.showCreateModal()" class="bg-blue-600 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-blue-700 transition-all" id="btn-diretor-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Novo Horário</span>
            </button>
          `:""}
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-slate-900 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-slate-800 transition-all" id="btn-diretor-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?nt():""}
        ${v==="labs"?Be():""}
        ${v==="atestados"?ct():""}
        ${v==="usuarios"?Ne({viewerRole:"diretor"}):""}
        ${v==="relatorios"?ut():""}
      </div>
    </main>

    ${Le()}
    ${ye()}
    ${Pe()}
    ${ze()}
    ${Re({viewerRole:"diretor"})}
  </div>
`,V={dev:{badge:"bg-emerald-100 text-emerald-700",label:"Desenvolvedor"},diretor:{badge:"bg-amber-100 text-amber-700",label:"Diretor / Direção Pedagógica"},teacher:{badge:"bg-blue-100 text-blue-700",label:"Professor"}},lt=({viewerRole:e})=>{var o,r;const t=e==="dev",s=e==="diretor"?l==null?void 0:l.school_id:Y||(l==null?void 0:l.school_id)||((o=R[0])==null?void 0:o.id)||"",a=F.filter(i=>i.school_id===s);return`
    <section class="space-y-5 rounded-3xl border border-slate-200 bg-white p-5 md:p-7 shadow-sm">
      <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h4 class="text-xl font-black text-slate-900">Matérias da escola</h4>
          <p class="mt-1 text-sm font-medium text-slate-500">Gerencie o catálogo de matérias desta escola.</p>
        </div>
        ${t?`
          <select onchange="actions.selectSubjectSchool(this.value)" class="w-full md:w-72 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-semibold text-slate-700" aria-label="Escola do catálogo de matérias">
            <option value="">Selecione uma escola</option>
            ${R.map(i=>`<option value="${i.id}" ${i.id===s?"selected":""}>${i.name}</option>`).join("")}
          </select>
        `:`<span class="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-black uppercase text-blue-700">${((r=R.find(i=>i.id===s))==null?void 0:r.name)||"Minha escola"}</span>`}
      </div>

      <form onsubmit="actions.createSchoolSubject(event)" class="flex flex-col gap-3 sm:flex-row">
        <input id="school-subject-name" type="text" maxlength="255" placeholder="Adicionar matéria ao checklist" class="min-w-0 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-800" required ${s?"":"disabled"}>
        <button type="submit" class="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50" ${s?"":"disabled"}>Adicionar matéria</button>
      </form>

      ${s?a.length===0?`
        <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-500">O checklist está vazio. Adicione as matérias usadas nesta escola.</p>
      `:`
        <div class="space-y-3">
          ${a.map(i=>`
            <div class="rounded-2xl border border-slate-200 p-4">
              <div class="flex items-center justify-between gap-3">
                <h5 class="font-black text-slate-800">${i.subject}</h5>
                <button type="button" onclick="actions.deleteSchoolSubject('${i.id}', '${i.subject.replace(/'/g,"\\'")}')" class="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="Excluir matéria ${i.subject}" title="Excluir matéria">
                  <i data-lucide="trash-2" class="h-4 w-4"></i>
                </button>
              </div>
            </div>
          `).join("")}
        </div>
      `:`
        <p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Cadastre uma escola para gerenciar o catálogo de matérias.</p>
      `}
    </section>
  `},Ne=({viewerRole:e="diretor"}={})=>{const t=e==="dev",s=[...B].filter(n=>t||n.role!=="dev").sort((n,m)=>(n.displayName||"").localeCompare(m.displayName||"")),a=s.find(n=>n.uid===oe&&n.role==="teacher"),o=a?F.filter(n=>n.school_id===a.school_id):[],r=s.filter(n=>n.uid!==(l==null?void 0:l.uid)).map(n=>n.uid),i=r.filter(n=>G.has(n)).length,d=r.length>0&&i===r.length,u=t?["teacher","diretor","dev"]:["teacher","diretor"];return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Gestão de usuários</h3>
          <p class="text-sm text-slate-500 font-medium">${t?"Todas as contas cadastradas no sistema.":"Direção pedagógica e professores cadastrados na sua escola."}</p>
        </div>
        <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          ${t||e==="diretor"?`
            <button onclick="actions.showCreateUserModal('${e}')" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
              <i data-lucide="plus" class="w-4 h-4"></i> Criar Usuário
            </button>
          `:""}
          <div class="inline-flex items-center gap-2 rounded-full bg-blue-50 text-blue-700 px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
            <i data-lucide="users" class="w-3.5 h-3.5"></i> ${s.length} usuários
          </div>
        </div>
      </div>

      ${i>0?`
        <div class="flex flex-col gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p class="text-sm font-bold text-rose-800">${i} conta${i===1?"":"s"} selecionada${i===1?"":"s"} para exclusão.</p>
          <button type="button" onclick="actions.deleteSelectedUsers()" class="inline-flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-xs font-black text-white hover:bg-rose-700">
            <i data-lucide="trash-2" class="h-4 w-4"></i> Excluir selecionados
          </button>
        </div>
      `:""}

      ${["dev","diretor"].includes(e)?lt({viewerRole:e}):""}

      <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full min-w-[820px] text-left">
            <thead class="bg-slate-50 text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 border-b border-slate-200">
              <tr>
                <th class="w-12 px-4 py-4">
                  <input type="checkbox" aria-label="Selecionar todos os usuários" ${d?"checked":""} ${r.length?"":"disabled"} onchange="actions.toggleAllUsers(this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                </th>
                <th class="px-6 py-4">Nome</th>
                <th class="px-6 py-4">E-mail</th>
                <th class="px-6 py-4">Perfil</th>
                <th class="px-6 py-4">Matéria</th>
                <th class="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${s.length===0?`
                <tr>
                  <td colspan="6" class="px-6 py-10 text-center text-sm text-slate-500 font-medium">Nenhum usuário encontrado.</td>
                </tr>
              `:s.map(n=>`
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="px-4 py-6">
                    <input type="checkbox" aria-label="Selecionar ${n.email||n.displayName||"usuário"}" ${G.has(n.uid)?"checked":""} ${n.uid===(l==null?void 0:l.uid)?"disabled":""} onchange="actions.toggleUserSelection('${n.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500 disabled:opacity-40">
                  </td>
                  <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 rounded-full bg-slate-100 text-slate-700 font-black flex items-center justify-center uppercase">
                        ${(n.displayName||"U").slice(0,2)}
                      </div>
                      <div>
                        <div class="font-bold text-slate-900">${n.displayName||"Usuário sem nome"}</div>
                        <div class="text-[10px] uppercase tracking-[0.18em] text-slate-400">${n.uid===(l==null?void 0:l.uid)?"Você":"Conta ativa"}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">${n.email||"—"}</td>
                  <td class="px-6 py-4">
                    ${n.uid===(l==null?void 0:l.uid)?`
                      <span class="inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(V[n.role]||V.teacher).badge}">
                        ${(V[n.role]||V.teacher).label}
                      </span>
                    `:`
                      <select
                        onchange="actions.changeUserRole('${n.uid}', this.value)"
                        class="rounded-full border border-slate-200 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(V[n.role]||V.teacher).badge} cursor-pointer"
                      >
                        ${u.map(m=>`<option value="${m}" ${n.role===m?"selected":""}>${V[m].label}</option>`).join("")}
                      </select>
                    `}
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">
                    ${n.role==="teacher"?`
                      <div class="flex min-w-40 flex-col items-start gap-2">
                        <span>${F.filter(m=>m.school_id===n.school_id&&(m.teacherIds||[]).includes(n.uid)).map(m=>m.subject).join(", ")||"—"}</span>
                        <button type="button" onclick="actions.toggleTeacherSubjectsEditor('${n.uid}')" class="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-2.5 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-50">
                          <i data-lucide="pencil" class="h-3.5 w-3.5"></i> Editar matérias
                        </button>
                      </div>
                    `:"—"}
                  </td>
                  <td class="px-6 py-4 text-right">
                    <button
                      onclick="actions.deleteUser('${n.uid}', '${(n.displayName||"Usuário").replace(/'/g,"\\'")}', '${n.email||"usuário"}')"
                      class="inline-flex items-center gap-2 rounded-xl border ${n.uid===(l==null?void 0:l.uid)?"border-slate-200 text-slate-400 cursor-not-allowed":"border-rose-200 text-rose-600 hover:bg-rose-50"} px-3 py-2 text-xs font-bold disabled:opacity-60"
                      ${n.uid===(l==null?void 0:l.uid)?"disabled":""}
                    >
                      <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                      ${n.uid===(l==null?void 0:l.uid)?"Você":"Excluir"}
                    </button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
      ${a?`
        <div class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 p-4" role="presentation">
          <section class="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl" role="dialog" aria-modal="true" aria-labelledby="teacher-subjects-title">
            <header class="flex items-start justify-between gap-4 border-b border-slate-200 p-5">
              <div>
                <h4 id="teacher-subjects-title" class="text-lg font-black text-slate-900">Matérias de ${a.displayName||a.email}</h4>
                <p class="mt-1 text-sm font-medium text-slate-500">Marque ou desmarque as matérias deste professor.</p>
              </div>
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Fechar edição de matérias">
                <i data-lucide="x" class="h-5 w-5"></i>
              </button>
            </header>
            <div class="max-h-[60vh] space-y-2 overflow-y-auto p-5">
              ${a.school_id?o.length?o.map(n=>`
                  <label class="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    <input type="checkbox" ${(n.teacherIds||[]).includes(a.uid)?"checked":""} onchange="actions.setTeacherSubject('${n.id}', '${a.uid}', this.checked)" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${n.subject}
                  </label>
                `).join(""):`
                <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-600">Não há matérias cadastradas para a escola deste professor.</p>
              `:`
                ${t?`
                  <div class="space-y-3 rounded-xl bg-amber-50 p-4">
                    <p class="text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Selecione a escola para continuar.</p>
                    <select id="teacher-school-${a.uid}" class="w-full rounded-lg border border-amber-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700">
                      <option value="">Selecione uma escola</option>
                      ${R.map(n=>`<option value="${n.id}">${n.name}</option>`).join("")}
                    </select>
                    <button type="button" onclick="actions.assignTeacherSchool('${a.uid}')" class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700">Associar escola</button>
                  </div>
                `:'<p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Peça à direção pedagógica para vinculá-lo.</p>'}
              `}
            </div>
            <footer class="flex justify-end border-t border-slate-200 p-4">
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-bold text-white hover:bg-slate-800">Concluir</button>
            </footer>
          </section>
        </div>
      `:""}
    </div>
  `},it=()=>`
  <div class="space-y-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Gerenciar Escolas</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Crie escolas e associe diretores</p>
      </div>
      <button onclick="actions.showCreateEscolaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Nova Escola
      </button>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="overflow-x-auto pr-2">
        <table class="w-full text-left min-w-[500px]">
          <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
            <tr>
              <th class="px-8 py-5">Nome da Escola</th>
              <th class="px-8 py-5">Criado por</th>
              <th class="px-8 py-5">Data</th>
              <th class="px-8 py-5">Ações</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-50">
            ${R&&R.length>0?R.map(e=>{var t;return`
              <tr class="hover:bg-slate-50 transition-all">
                <td class="px-8 py-5 font-bold">${e.name}</td>
                <td class="px-8 py-5 text-sm">
                  ${((t=B.find(s=>s.uid===e.createdBy))==null?void 0:t.displayName)||"—"}
                </td>
                <td class="px-8 py-5 text-sm text-slate-500">
                  ${new Date(e.createdAt).toLocaleDateString("pt-BR")}
                </td>
                <td class="px-8 py-5 text-right">
                  <button onclick="actions.deleteSchool('${e.id}')" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer" title="Deletar">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                  </button>
                </td>
              </tr>
            `}).join(""):'<tr><td colspan="4" class="px-8 py-8 text-center text-slate-400 text-sm">Nenhuma escola criada ainda</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </div>
`,nt=()=>`
  <h3 class="text-2xl font-black text-slate-900 print:mb-4">Grade de Horários</h3>
  <div class="bg-white rounded-3xl border overflow-hidden shadow-sm print:border-none print:shadow-none">
    <div class="overflow-x-auto pr-2">
      <table class="w-full text-left min-w-[700px]">
      <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
        <tr>
          <th class="px-8 py-5">Matéria</th>
          <th class="px-8 py-5">Horário / Data</th>
          <th class="px-8 py-5">Professor</th>
          <th class="px-8 py-5 text-center">Status</th>
          <th class="px-8 py-5 print:hidden"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-50">
        ${$.map(e=>`
          <tr class="${e.status==="vaga"?"bg-rose-50":"hover:bg-slate-50"} transition-all">
            <td class="px-8 py-5 font-bold">${e.subject}</td>
            <td class="px-8 py-5">
              <div class="text-sm font-bold">${e.startTime}</div>
              <div class="text-[10px] text-slate-400 uppercase font-bold">${e.date}</div>
            </td>
            <td class="px-8 py-5 text-sm">
              <span class="font-bold text-slate-800">${e.teacherName}</span>
              ${e.classGroup?`<span class="block text-xs font-semibold text-blue-600 mt-0.5">${e.classGroup}</span>`:""}
            </td>
            <td class="px-8 py-5">
              <div class="flex justify-center">
                <span class="text-[10px] font-black uppercase px-3 py-1 rounded-full ${e.status==="confirmed"?"bg-blue-100 text-blue-700":e.status==="vaga"?"bg-rose-600 text-white":e.status==="absent"?"bg-rose-100 text-rose-700":"bg-slate-100 text-slate-500"}">${e.status==="vaga"?"AULA VAGA":e.status}</span>
              </div>
            </td>
            <td class="px-8 py-5 text-right print:hidden">
              <div class="flex items-center justify-end gap-3">
                <button onclick="actions.showEditModalById(${e.id})" class="text-slate-300 hover:text-blue-600 transition-all cursor-pointer" title="Editar">
                  <i data-lucide="pencil" class="w-4 h-4"></i>
                </button>
                <button onclick="actions.showDeleteModal(${e.id})" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer" title="Excluir">
                  <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
              </div>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
   </div>
  </div>
`,dt=()=>`
  <div class="space-y-8 animate-fade-in">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Minhas Matérias</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Gerencie as matérias que você leciona.</p>
      </div>
      <button onclick="actions.showAddMatériaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Adicionar Matéria
      </button>
    </div>

    <div class="space-y-5">
      <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h4 class="text-sm font-black uppercase tracking-[0.18em] text-slate-400 mb-4">Editar minhas matérias</h4>
        ${(()=>{const e=(F||[]).filter(s=>s.school_id===(l==null?void 0:l.school_id)),t=new Set((window.teacherSubjects||[]).map(s=>s.subject));return e.length?`
            <div class="flex flex-wrap gap-2">
              ${e.map(s=>{const a=t.has(s.subject);return`
                  <label class="inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-bold ${a?"border-blue-200 bg-blue-50 text-blue-800":"border-slate-200 bg-slate-50 text-slate-600"}">
                    <input type="checkbox" ${a?"checked":""} onchange="actions.setTeacherSubject('${s.id}', '${l.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${s.subject}
                  </label>
                `}).join("")}
            </div>
          `:'<p class="text-sm font-medium text-slate-500">Ainda não há matérias cadastradas para a sua escola.</p>'})()}
      </div>

      <div class="grid gap-4">
        ${(()=>{const e=window.teacherSubjects||[];return e.length===0?`
              <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
                <i data-lucide="book" class="w-12 h-12 text-slate-300 mx-auto mb-4"></i>
                <p class="text-slate-400 font-bold">Você ainda não adicionou nenhuma matéria.</p>
              </div>
            `:e.map(t=>`
            <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center justify-between hover:shadow-md transition-all">
              <div class="flex items-center gap-4">
                <div class="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center">
                  <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
                </div>
                <div>
                  <h4 class="font-bold text-slate-900">${t.subject}</h4>
                  <p class="text-xs text-slate-400">Matéria</p>
                </div>
              </div>
              <button onclick="actions.deleteMatéria('${t.subject}')" class="text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition-all">
                <i data-lucide="trash-2" class="w-5 h-5"></i>
              </button>
            </div>
          `).join("")})()}
      </div>
    </div>
  </div>
`,Be=()=>`
  <div class="space-y-8">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Agendamento de Laboratórios</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold font-sans">Consulte a disponibilidade e reserve os laboratórios do colégio para as suas aulas.</p>
      </div>
      <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Reservar Laboratório
      </button>
    </div>

    <!-- Quick view of active labs -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
      ${["info","chem"].map(e=>{const t=q.filter(s=>s.labId===e);return`
          <div class="bg-white p-6 md:p-8 rounded-[2rem] border shadow-sm">
            <h4 class="text-lg font-black mb-6 flex items-center gap-2 text-blue-600 uppercase tracking-tighter">
              <i data-lucide="${e==="info"?"monitor":"beaker"}"></i>
              ${e==="info"?"Informática":"Química"}
            </h4>
            <div class="space-y-4">
              ${t.slice(0,3).map(s=>`
                <div class="p-4 bg-slate-50 rounded-2xl border flex items-center justify-between">
                  <div>
                    <p class="font-bold text-sm text-slate-800">${s.teacherName}</p>
                    <p class="text-[10px] text-slate-400 font-bold uppercase">${s.date} • ${s.startTime}${s.endTime?` - ${s.endTime}`:""}</p>
                  </div>
                </div>
              `).join("")||'<p class="text-center text-slate-400 font-bold py-8 text-xs">Nenhuma reserva recente</p>'}
            </div>
          </div>
        `}).join("")}
    </div>

    <!-- Detailed reservation schema table -->
    <div class="space-y-4">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h4 class="text-lg font-black text-slate-800">Tabela Geral do Cronograma das Reservas</h4>
          <p class="text-xs text-slate-500 font-bold">Acompanhe todos os agendamentos cadastrados no sistema.</p>
        </div>
        ${q.length>0&&l.role==="dev"?`
          <button onclick="actions.clearAllLabBookings()" class="text-rose-600 hover:text-rose-700 font-bold text-xs flex items-center gap-1.5 border border-rose-200 bg-rose-50 hover:bg-rose-100 px-4 py-2 rounded-xl transition-all shadow-sm">
            <i data-lucide="trash-2" class="w-4 h-4"></i> Limpar Tabela
          </button>
        `:""}
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto pr-2">
          <table class="w-full text-left min-w-[700px]">
            <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
              <tr>
                <th class="px-8 py-5">Laboratório</th>
                <th class="px-8 py-5">Professor Responsável</th>
                <th class="px-8 py-5">Data da Reserva</th>
                <th class="px-8 py-5">Horário (Início - Fim)</th>
                <th class="px-8 py-5 text-center">Ações</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
              ${q.map(e=>`
                <tr class="hover:bg-slate-50/50 transition-all">
                  <td class="px-8 py-5">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-bold text-xs ${e.labId==="info"?"bg-indigo-50 text-indigo-700":"bg-teal-50 text-teal-700"}">
                      <i data-lucide="${e.labId==="info"?"monitor":"beaker"}" class="w-3 h-3"></i>
                      ${e.labId==="info"?"Informática":"Química"}
                    </span>
                  </td>
                  <td class="px-8 py-5 font-bold text-slate-800">${e.teacherName}</td>
                  <td class="px-8 py-5 font-medium text-slate-600">${e.date}</td>
                  <td class="px-8 py-5">
                    <span class="bg-slate-100 font-mono text-xs font-bold text-slate-700 px-2.5 py-1 rounded-lg">
                      ${e.startTime} - ${e.endTime||"---"}
                    </span>
                  </td>
                  <td class="px-8 py-5 text-center">
                    ${l.role==="dev"||l.role==="diretor"||e.teacherId===l.uid?`
                      <button onclick="actions.deleteLabBooking(${e.id})" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer inline-flex items-center" title="Cancelar Reserva">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                      </button>
                    `:'<span class="text-slate-300 text-xs">-</span>'}
                  </td>
                </tr>
              `).join("")}
              ${q.length===0?`
                <tr>
                  <td colspan="5" class="px-8 py-10 text-center text-slate-400 font-bold text-sm">Nenhum agendamento de laboratório cadastrado até o momento</td>
                </tr>
              `:""}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
`,ct=()=>`
  <div class="space-y-8">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <h3 class="text-xl md:text-2xl font-black text-slate-900">Atestados Médicos</h3>
      <button onclick="actions.showCertModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Incluir Atestado Médico
      </button>
    </div>
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="overflow-x-auto pr-2">
        <table class="w-full text-left min-w-[700px]">
          <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
            <tr>
              <th class="px-8 py-5">Professor</th>
              <th class="px-8 py-4">Data da Falta</th>
              <th class="px-8 py-4">Motivo</th>
              <th class="px-8 py-4">Imagem</th>
              <th class="px-8 py-4">Status</th>
              <th class="px-8 py-4"></th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-50">
            ${J.map(e=>`
              <tr class="hover:bg-slate-50/50 transition-all">
                <td class="px-8 py-5 font-bold">${e.teacherName}</td>
                <td class="px-8 py-5 font-bold">${e.date}</td>
                <td class="px-8 py-5 text-sm">${e.reason}</td>
                <td class="px-8 py-5">
                  ${e.id?`<button onclick="actions.viewImageById(${e.id})" class="bg-blue-50 text-blue-600 p-2 rounded-lg"><i data-lucide="eye" size="16"></i></button>`:'<span class="text-slate-300 text-[10px]">SEM IMAGEM</span>'}
                </td>
                <td class="px-8 py-5">
                  <span class="text-[10px] font-black uppercase px-3 py-1 rounded-full ${e.status==="approved"?"bg-emerald-100 text-emerald-700":"bg-amber-100 text-amber-700"}">${e.status==="approved"?"Aprovado":"Pendente"}</span>
                </td>
                <td class="px-8 py-5 text-right">
                  ${e.status==="pending"?`<button onclick="actions.approveCert(${e.id})" class="text-blue-600 font-black text-[10px] uppercase tracking-widest hover:underline">Aprovar e Gerar Aula Vaga</button>`:""}
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  </div>
`,ut=()=>{console.log("[DEBUG RELATÓRIO]",{reportTurno:k,reportWeek:A,schedulesCount:$.length,teachersCount:z.length});const e=Ue(),t=ge();let s=[];k==="matutino"?s=["07:30","08:20","09:10","10:15","11:00","11:45"]:k==="vespertino"?s=["13:00","13:50","14:40","15:45","16:30","17:15"]:k==="noturno"?s=["18:45","19:30","20:30","21:15","22:00"]:s=t.length>0?t:["07:30","08:20","09:10","10:15","11:00","11:45"];let a=$;A!=="all"&&(a=$.filter(d=>{try{return xe(d.date)===A}catch{return!1}}));let o=z;if(H!=="all"&&(o=z.filter(d=>d.uid===H)),o.length===0&&a.length>0){const d=new Set,u=[];a.forEach(n=>{n.teacherId&&!d.has(n.teacherId)&&(d.add(n.teacherId),u.push({uid:n.teacherId,displayName:n.teacherName,subject:n.subject}))}),o=u}let r="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5 print:grid-cols-4 print:gap-2 justify-center";w==="small"?r="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 print:grid-cols-5 print:gap-1 justify-center":w==="medium"?r="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-3.5 print:grid-cols-4 print:gap-2 justify-center":w==="large"?r="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-5 print:grid-cols-3 print:gap-3 justify-center":w==="esticado"?r="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4 justify-center":w==="super_esticado"&&(r="grid grid-cols-1 gap-8 print:grid-cols-1 print:gap-6 justify-center");const i=`
    <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-8 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
      <button onclick="actions.setRelatorioSubTab('urania')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${re==="urania"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Professores (Individual)
      </button>
      <button onclick="actions.setRelatorioSubTab('frequent')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${re==="frequent"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="bar-chart-3" class="w-4 h-4 text-slate-500"></i> Gráfico de Frequência
      </button>
    </div>
  `;return re==="frequent"?`
      <div class="space-y-4">
        <h3 class="text-2xl font-black text-slate-900 print:hidden">Relatório de Frequência</h3>
        ${i}
        <div class="bg-white p-10 rounded-[2.5rem] border shadow-sm flex flex-col items-center">
          <div class="flex items-end gap-6 h-64 mb-10">
            <div class="w-20 bg-blue-500 rounded-t-2xl" style="height: ${T.total>0?T.confirmed/T.total*100:0}%"></div>
            <div class="w-20 bg-rose-500 rounded-t-2xl" style="height: ${T.total>0?T.absent/T.total*100:0}%"></div>
            <div class="w-20 bg-amber-400 rounded-t-2xl" style="height: ${T.total>0?T.pending/T.total*100:0}%"></div>
          </div>
          <div class="grid grid-cols-3 gap-10 text-center uppercase font-black text-xs">
            <div class="text-blue-600">Presentes: ${T.confirmed}</div>
            <div class="text-rose-500">Ausentes: ${T.absent}</div>
            <div class="text-amber-500">Pendentes: ${T.pending}</div>
          </div>
        </div>
      </div>
    `:`
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 print:hidden">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Grades Escolares</h3>
          <p class="text-xs text-slate-400 mt-1">Baixe a grade escolar em PDF ou visualize instantaneamente para impressão.</p>
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <!-- Button 1: Download Direct PDF with html2pdf -->
          <button id="btn-download-pdf" onclick="actions.downloadPDF()" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-bold shadow-md flex items-center gap-2 transition-all">
            <i data-lucide="download"></i> Baixar Arquivo PDF
          </button>
        </div>
      </div>

      ${i}

      <!-- Modelo Selector Tab -->
      <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-2 print:hidden overflow-x-auto scrollbar-none select-none shrink-0" id="report-model-tabs">
        <button onclick="actions.setReportModel('prof_turma')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${O==="prof_turma"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="user" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Turma)
        </button>
        <button onclick="actions.setReportModel('prof_subject')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${O==="prof_subject"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="book" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Matéria)
        </button>
        <button onclick="actions.setReportModel('turma_grid')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${O==="turma_grid"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="users" class="w-3.5 h-3.5 text-slate-500"></i> Todas as Turmas
        </button>
      </div>

      <!-- Control Box -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 print:hidden">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Nome do Colégio</label>
            <input type="text" value="${X}" oninput="actions.setSchoolName(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Selecione a Semana</label>
            <select onchange="actions.setReportWeek(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${A==="all"?"selected":""}>Todas as semanas (Geral Acumulada)</option>
              ${e.map(d=>`<option value="${d}" ${A===d?"selected":""}>${be(d)}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Turno / Períodos</label>
            <select onchange="actions.setReportTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="matutino" ${k==="matutino"?"selected":""}>Manhã (07:30 - 11:45)</option>
              <option value="vespertino" ${k==="vespertino"?"selected":""}>Tarde (13:00 - 17:15)</option>
              <option value="noturno" ${k==="noturno"?"selected":""}>Noite (18:45 - 22:45)</option>
              <option value="auto" ${k==="auto"?"selected":""}>Auto-detecção de horários</option>
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Filtro de Professor</label>
            <select onchange="actions.setReportTeacher(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${H==="all"?"selected":""}>Todos os professores (${o.length})</option>
              ${z.map(d=>`<option value="${d.uid}" ${H===d.uid?"selected":""}>${d.displayName}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Tamanho dos Cards</label>
            <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
              <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
              <option value="large" ${w==="large"?"selected":""}>Grande (Mais Legível)</option>
              <option value="esticado" ${w==="esticado"?"selected":""}>Esticado (Largo - 2 por linha)</option>
              <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Super Esticado (Página Inteira - 1 por linha)</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Live Printable Preview (Mimicking A4 Sheet) -->
      <div class="w-full overflow-x-auto pb-4 scrollbar-none">
        <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-6 md:p-12 shadow-xl relative overflow-hidden min-w-[750px] md:min-w-0">
        <!-- Sheet Header -->
        <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
          <div class="flex items-center gap-4">
            <!-- Studia Logo matching user image with book and orbital swoosh -->
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              
              <!-- Subtle glow on the outer swoosh -->
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

              <!-- Open Book icon centered above "Stu" -->
              <g transform="translate(68, 2)">
                <!-- Left half -->
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <!-- Right half -->
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>

              <!-- Main Title: Studia -->
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          
          <div class="text-center md:text-right">
            <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${X}</h4>
            <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
              ${O==="turma_grid"?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${A==="all"?"Grade Geral Acumulada":be(A)}
            </p>
          </div>
        </div>

        ${O==="turma_grid"?`
          <!-- Turmas Cards Grid -->
          ${(()=>{const d=[...new Set(a.filter(n=>n.classGroup&&n.classGroup.trim()!=="").map(n=>n.classGroup))].sort();console.log("=== DEBUG RELATÓRIO TURMAS ==="),console.log("schedules total:",$.length),console.log("filteredSchedules:",a.length),console.log("reportWeek:",A),console.log("reportTurno:",k),a.length>0&&(console.log("Sample schedule:",a[0]),console.log("classGroup values:",a.map(n=>n.classGroup).filter(Boolean))),console.log("[DEBUG TURMAS GRID]",{filteredSchedulesCount:a.length,allTurmasCount:d.length,allTurmas:d,reportTurno:k,sampleSchedules:a.slice(0,2).map(n=>({classGroup:n.classGroup,startTime:n.startTime,status:n.status}))});const u=k!=="auto"?d.filter(n=>{const m=a.filter(f=>f.classGroup===n),x=m.some(f=>He(f.startTime,k));return console.log(`[DEBUG] Turma "${n}": ${m.length} schedules, matches=${x}`),x}):d;return u.length===0?`
                <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
                  <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300 col-span-full"></i>
                  <p>Nenhuma turma cadastrada ou detectada nos horários selecionados para o turno "${k==="matutino"?"Manhã":k==="vespertino"?"Tarde":"Noite"}". Certifique-se de preencher o campo 'Turma' ao criar novos horários.</p>
                </div>
              `:`
              <div class="${r}">
                ${u.map(n=>{const m=a.filter(x=>x.classGroup===n);return De(n,m,s)}).join("")}
              </div>
            `})()}
        `:`
          <!-- Teachers Cards Grid -->
          ${o.length===0?`
            <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
              <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300"></i>
              <p>Nenhum horário cadastrado para exibição na grade individual</p>
            </div>
          `:`
            <div class="${r}">
              ${o.map(d=>{const u=a.filter(n=>n.teacherId===d.uid);return we(d,u,s,O)}).join("")}
            </div>
          `}
        `}

        <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
        </div>
      </div>
    </div>
  `};let se=0;const pt=[{title:"Studia",subtitle:"Gestão Escolar Inteligente",content:"Uma plataforma completa para controle de horários, laboratórios e frequência docente.",icon:"book-open"},{title:"O Problema",subtitle:"Desafios na Gestão de Horários",content:"Aulas vagas imprevistas, dificuldade no controle de laboratórios e burocracia no envio de atestados médicos.",icon:"alert-circle"},{title:"Nossa Solução",subtitle:"Automatização e Transparência",content:"Sistema centralizado onde professores confirmam presença e diretores gerenciam a grade em tempo real.",icon:"check-circle"},{title:"Funcionalidades",subtitle:"O que o Studia faz?",content:`• Grade de horários dinâmica
• Reserva de laboratórios
• Envio digital de atestados
• Relatórios automáticos de frequência`,icon:"layers"},{title:"Tecnologia",subtitle:"Stack Robusta",content:"Backend robusto para persistência sólida e Frontend moderno com Tailwind CSS.",icon:"cpu"}],ae={dev:["overview","dev_health","dev_diagnostics","dev_logs","dev_audit","dev_data","escolas","usuarios"],diretor:["horarios","labs","atestados","usuarios","relatorios"],teacher:["horarios","labs","materias","atestados"]},_e={toggleMobileMenu(e){me=e;const t=c("#mobile-drawer");t&&t.classList.toggle("hidden",!e)},switchTabMobile(e){var t;(t=ae[l==null?void 0:l.role])!=null&&t.includes(e)&&(v=e,me=!1,this.init())},renderCurrentView(){try{l&&!l.accessToken&&(localStorage.removeItem("user"),l=null),l?l.role==="dev"?U(ot()):l.role==="diretor"?U(rt()):U(de()):U(fe()),typeof lucide<"u"&&lucide.createIcons()}catch(e){console.error("Render error:",e)}},async init(){var e,t;try{l?((e=ae[l.role])!=null&&e.includes(v)||(v=((t=ae[l.role])==null?void 0:t[0])||"horarios"),await this.refreshData(),l.role==="dev"&&await this.loadDeveloperPanel(v),this.renderCurrentView()):U(fe()),typeof lucide<"u"&&lucide.createIcons()}catch(s){console.error("Init error:",s)}},showLoginModal(e="login"){M=e,this.init()},hideLoginModal(){M="closed",this.init()},toggleAuthMode(e){M=e,this.init()},submitContact(e){var o,r,i;e.preventDefault();const t=(o=document.getElementById("landing-name"))==null?void 0:o.value,s=(r=document.getElementById("landing-contact"))==null?void 0:r.value,a=(i=document.getElementById("landing-message"))==null?void 0:i.value;t&&s&&a&&(p(`Obrigado ${t}! Recebemos sua mensagem. Entraremos em contato em breve!`),e.target.reset())},showCreateModal(){var t;const e=c("#create-modal");e&&(e.classList.remove("hidden"),this.updateScheduleSubjectOptions(((t=c("#form-teacher"))==null?void 0:t.value)||""),typeof lucide<"u"&&lucide.createIcons())},hideCreateModal(){const e=c("#create-modal");e&&e.classList.add("hidden")},showEditModalById(e){const t=$.find(a=>a.id===e);if(!t)return;const s=c("#edit-modal");s&&(c("#edit-form-id").value=t.id||"",c("#edit-form-subject").value=t.subject||"",c("#edit-form-class-group").value=t.classGroup||"",c("#edit-form-date").value=t.date||"",c("#edit-form-room").value=t.room||"",c("#edit-form-start").value=t.startTime||"18:45",c("#edit-form-end").value=t.endTime||"22:45",c("#edit-form-teacher").value=t.teacherId||"",c("#edit-form-status").value=t.status||"pending",this.updateScheduleSubjectOptions(t.teacherId||"",t.subject||"","edit-form"),s.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideEditModal(){const e=c("#edit-modal");e&&e.classList.add("hidden")},showDeleteModal(e){const t=c("#delete-modal");t&&(c("#delete-schedule-id").value=e,t.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideDeleteModal(){const e=c("#delete-modal");e&&e.classList.add("hidden")},updateScheduleSubjectOptions(e,t="",s="form"){const a=c(`#${s}-subject`),o=c(`#${s}-subject-options`);if(!a||!o)return;const r=We(e);o.innerHTML=r.map(i=>`<option value="${i}"></option>`).join(""),a.value=t||""},async confirmDeleteSchedule(){const e=c("#delete-schedule-id").value;try{await b.delete(`/api/schedules/${e}`),this.hideDeleteModal(),this.init()}catch{p("Erro ao excluir.")}},showLabModal(){document.body.insertAdjacentHTML("beforeend",Qe());const e=c("#lab-modal");e&&(e.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideLabModal(){const e=c("#lab-modal");e&&e.remove()},showCertModal(){const e=c("#cert-modal");e&&e.classList.remove("hidden")},hideCertModal(){const e=c("#cert-modal");if(e){e.classList.add("hidden"),this.clearCertImage();const t=c("#cert-date");t&&(t.value="");const s=c("#cert-reason");s&&(s.value="")}},previewCertImage(e){const t=e.target.files[0];if(t){const s=new FileReader;s.onload=a=>{const o=c("#cert-preview-img"),r=c("#cert-preview-container"),i=c("#cert-upload-placeholder");o&&r&&i&&(o.src=a.target.result,r.classList.remove("hidden"),i.classList.add("hidden"))},s.readAsDataURL(t)}},clearCertImage(){const e=c("#cert-image");e&&(e.value="");const t=c("#cert-preview-img"),s=c("#cert-preview-container"),a=c("#cert-upload-placeholder");t&&s&&a&&(t.src="",s.classList.add("hidden"),a.classList.remove("hidden"))},switchTab(e){var t;(t=ae[l==null?void 0:l.role])!=null&&t.includes(e)&&(v=e,this.init())},async loadDeveloperPanel(e=v){try{["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?(I=await b.get("/api/dev/diagnostics"),delete Q.diagnostics):e==="dev_logs"?(ue=await b.get("/api/dev/logs"),delete Q.logs):e==="dev_audit"&&(ce=await b.get("/api/dev/audit"),delete Q.audit)}catch(t){const s=["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?"diagnostics":e==="dev_logs"?"logs":"audit";Q[s]=t.message||"Não foi possível carregar os dados desta aba."}},async refreshDeveloperPanel(){(l==null?void 0:l.role)==="dev"&&(await this.loadDeveloperPanel(v),this.renderCurrentView())},async exportDeveloperData(){var s;if((l==null?void 0:l.role)!=="dev")return;const e=(s=document.getElementById("dev-export-resource"))==null?void 0:s.value;if(!e)return p("Selecione uma tabela para exportar.");if(await p("O CSV pode conter informações pessoais. Guarde o arquivo em local seguro e compartilhe apenas com pessoas autorizadas. Deseja continuar?",{confirm:!0,title:"Confirmar exportação"}))try{const a=await b.get(`/api/dev/export/${encodeURIComponent(e)}`),r={users:["uid","email","displayName","role","school_id","subject"],schools:["id","name","createdAt"],schedules:["id","date","startTime","endTime","subject","room","teacherId","teacherName","classGroup","status","school_id"],lab_bookings:["id","labId","teacherId","teacherName","date","startTime","endTime"],certificates:["id","teacherId","teacherName","date","reason","status","createdAt"],school_subjects:["id","school_id","subject"],teacher_subjects:["id","teacher_id","subject_id"]}[e],i=x=>{const f=x==null?"":typeof x=="object"?JSON.stringify(x):String(x);return`"${(/^[\s]*[=+\-@]/.test(f)?`'${f}`:f).replace(/"/g,'""')}"`},d=[r.map(i).join(","),...a.rows.map(x=>r.map(f=>i(x[f])).join(","))].join(`\r
`),u=new Blob(["\uFEFF",d],{type:"text/csv;charset=utf-8"}),n=URL.createObjectURL(u),m=document.createElement("a");m.href=n,m.download=`studia-${e}-${new Date().toISOString().slice(0,10)}.csv`,document.body.appendChild(m),m.click(),m.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3),p(`Exportação concluída: ${a.count} registros.`)}catch(a){p(a.message||"Não foi possível exportar os dados.")}},async login(){const e=c("#auth-email"),t=c("#auth-password");if(!e||!t)return;const s=e.value,a=t.value;if(!s||!a)return p("Por favor, preencha todos os campos.");try{l=await b.post("/api/auth/login",{email:s,password:a}),localStorage.setItem("user",JSON.stringify(l)),M="closed",this.init()}catch(o){p(o.message)}},async register(){const e=c("#auth-email"),t=c("#auth-password"),s=c("#auth-name"),a=c("#auth-subject");if(!e||!t||!s)return;const o=e.value,r=t.value,i=s.value,d=a?a.value:null;if(!o||!r||!i)return p("Por favor, preencha todos os campos.");if(!d)return p("Por favor, informe sua matéria.");try{l=await b.post("/api/auth/register",{email:o,password:r,displayName:i,subject:d}),localStorage.setItem("user",JSON.stringify(l)),M="closed",this.init()}catch(u){p(u.message)}},logout(){localStorage.removeItem("user"),l=null,v="horarios",M="closed",this.init()},showAddMatériaModal(){const e=prompt("Informe a matéria que você leciona:");e&&this.addMatéria(e)},async addMatéria(e){if(!(!l||!l.uid))try{const t=await b.post(`/api/teachers/${l.uid}/subjects`,{subject:e});window.teacherSubjects||(window.teacherSubjects=[]),window.teacherSubjects.push(t),U(de()),lucide.createIcons()}catch(t){p(t.message)}},async deleteMatéria(e){if(!(!l||!l.uid)&&confirm(`Deseja remover a matéria "${e}"?`))try{await b.delete(`/api/teachers/${l.uid}/subjects/${encodeURIComponent(e)}`),window.teacherSubjects=(window.teacherSubjects||[]).filter(t=>t.subject!==e),U(de()),lucide.createIcons()}catch(t){p(t.message)}},normalizeSchedules(e){return e.map(t=>{const s=t.classgroup||t.classGroup||"SEM_TURMA";return(!s||s.trim()==="")&&console.warn("[WARN] Schedule sem classGroup:",t),{id:t.id,date:t.date,startTime:t.starttime||t.startTime,endTime:t.endtime||t.endTime,subject:t.subject,room:t.room,teacherId:t.teacherid||t.teacherId,teacherName:t.teachername||t.teacherName,classGroup:s,status:t.status,school_id:t.school_id,createdAt:t.createdat||t.createdAt}})},async refreshData(){var e;if(!(!l||ne)){ne=!0;try{if(l.role==="dev"){const t=await Promise.allSettled([b.get(l.school_id?`/api/schedules?schoolId=${l.school_id}`:"/api/schedules"),b.get("/api/teachers"),b.get("/api/users"),b.get("/api/labs/bookings"),b.get("/api/certificates"),b.get("/api/schools"),b.get("/api/school-subjects")]),[s,a,o,r,i,d,u]=t.map((n,m)=>n.status==="fulfilled"?n.value:(console.error(`Data fetch #${m} failed:`,n.reason),[]));$=this.normalizeSchedules(s||[]),z=a||[],B=o||[],R=d||[],F=u||[],R.some(n=>n.id===Y)||(Y=l.school_id||((e=R[0])==null?void 0:e.id)||""),T={total:$.length,confirmed:$.filter(n=>n.status==="confirmed").length,absent:$.filter(n=>n.status==="absent").length,pending:$.filter(n=>n.status==="pending").length},q=r||[],J=i||[]}else if(l.role==="diretor"){const t=await Promise.allSettled([b.get(`/api/schedules?schoolId=${l.school_id}`),b.get("/api/teachers"),b.get(`/api/users?schoolId=${l.school_id}`),b.get("/api/labs/bookings"),b.get("/api/certificates"),b.get("/api/school-subjects")]),[s,a,o,r,i,d]=t.map((u,n)=>u.status==="fulfilled"?u.value:(console.error(`Data fetch #${n} failed:`,u.reason),[]));$=this.normalizeSchedules(s||[]),z=a||[],B=o||[],F=d||[],T={total:$.length,confirmed:$.filter(u=>u.status==="confirmed").length,absent:$.filter(u=>u.status==="absent").length,pending:$.filter(u=>u.status==="pending").length},q=r||[],J=i||[]}else{const t=await Promise.allSettled([b.get(`/api/schedules?teacherId=${l.uid}`),b.get("/api/labs/bookings"),b.get("/api/certificates"),b.get(`/api/teachers/${l.uid}/subjects`),b.get("/api/school-subjects")]),[s,a,o,r,i]=t.map((d,u)=>d.status==="fulfilled"?d.value:(console.error(`Data fetch #${u} failed:`,d.reason),[]));$=this.normalizeSchedules(s||[]),B=[],F=i||[],q=a||[],J=o||[],window.teacherSubjects=r||[]}}catch(t){console.error("Data refresh error:",t)}finally{ne=!1}}},async refreshSchedules(){await this.refreshData(),this.init()},toggleUserSelection(e,t){!e||e===(l==null?void 0:l.uid)||!B.some(s=>s.uid===e)||(t?G.add(e):G.delete(e),this.renderCurrentView())},toggleAllUsers(e){const t=B.filter(s=>s.uid!==(l==null?void 0:l.uid));e?t.forEach(s=>G.add(s.uid)):t.forEach(s=>G.delete(s.uid)),this.renderCurrentView()},toggleTeacherSubjectsEditor(e){oe=oe===e?null:e,this.renderCurrentView()},async assignTeacherSchool(e){var s;const t=(s=document.getElementById(`teacher-school-${e}`))==null?void 0:s.value;if(!t)return p("Selecione uma escola para continuar.");try{await b.patch(`/api/users/${e}/school`,{schoolId:t}),await this.refreshData(),this.renderCurrentView()}catch(a){p(a.message||"Não foi possível associar o professor à escola.")}},closeTeacherSubjectsEditor(){oe=null,this.renderCurrentView()},async deleteUser(e,t,s){if(!(!e||!await p(`Deseja excluir ${t} (${s}) do sistema? Essa ação remove o acesso do usuário e sua conta de autenticação.`,{confirm:!0,title:"Excluir usuário"})))try{await b.delete(`/api/users/${e}`),G.delete(e),await this.refreshData(),this.init(),p("Usuário excluído com sucesso.")}catch(o){p(o.message||"Erro ao excluir usuário.")}},async deleteSelectedUsers(){const e=B.filter(o=>G.has(o.uid)&&o.uid!==(l==null?void 0:l.uid));if(e.length===0)return;const t=e.map(o=>o.email||o.displayName||o.uid).join(`
`);if(!await p(`Confirma excluir ${e.length} conta${e.length===1?"":"s"}? Esta ação não pode ser desfeita.

${t}`,{confirm:!0,title:"Excluir contas selecionadas"}))return;const a=[];for(const o of e)try{await b.delete(`/api/users/${o.uid}`),G.delete(o.uid)}catch(r){a.push(`${o.email||o.displayName||o.uid}: ${r.message||"falha ao excluir"}`)}await this.refreshData(),this.renderCurrentView(),a.length>0?p(`Não foi possível excluir todas as contas. As contas com erro continuam selecionadas para você tentar novamente:

${a.join(`
`)}`,{title:"Exclusão parcial"}):p(`${e.length} conta${e.length===1?"":"s"} excluída${e.length===1?"":"s"} com sucesso.`)},selectSubjectSchool(e){Y=e,this.renderCurrentView()},async createSchoolSubject(e){var o;e.preventDefault();const t=c("#school-subject-name"),s=(l==null?void 0:l.role)==="diretor"?l.school_id:Y||(l==null?void 0:l.school_id),a=(o=t==null?void 0:t.value)==null?void 0:o.trim();if(!s||!a)return p("Selecione uma escola e informe a matéria.");try{await b.post("/api/school-subjects",{schoolId:s,subject:a}),await this.refreshData(),this.renderCurrentView()}catch(r){p(r.message||"Erro ao adicionar matéria.")}},async deleteSchoolSubject(e,t){if(await p(`Excluir "${t}" do catálogo? Os horários antigos serão mantidos, mas os vínculos com professores serão removidos.`,{confirm:!0,title:"Excluir matéria"}))try{await b.delete(`/api/school-subjects/${e}`),await this.refreshData(),this.renderCurrentView()}catch(a){p(a.message||"Erro ao excluir matéria.")}},async setTeacherSubject(e,t,s){try{s?await b.post(`/api/school-subjects/${e}/teachers`,{teacherId:t}):await b.delete(`/api/school-subjects/${e}/teachers/${t}`),await this.refreshData(),this.renderCurrentView()}catch(a){await this.refreshData(),this.renderCurrentView(),p(a.message||"Erro ao atualizar vínculo da matéria.")}},async changeUserRole(e,t){if(!(!e||e===(l==null?void 0:l.uid)))try{await b.patch(`/api/users/${e}/role`,{role:t}),B=B.map(s=>s.uid===e?{...s,role:t}:s),this.init()}catch(s){p(s.message||"Erro ao atualizar perfil do usuário."),this.init()}},async updateStatus(e,t){try{await b.patch(`/api/schedules/${e}`,{status:t}),this.init()}catch{p("Erro ao atualizar status.")}},async createSchedule(e){var o;e.preventDefault();const t=c("#form-teacher"),s={subject:c("#form-subject").value,classGroup:c("#form-class-group").value,date:c("#form-date").value,room:c("#form-room").value,startTime:c("#form-start").value,endTime:c("#form-end").value,teacherId:t.value,teacherName:t.options[t.selectedIndex].text,school_id:l.school_id},a=[s];if((o=c("#form-double-lesson"))!=null&&o.checked){const r=this.timeToMinutes(s.startTime),i=this.timeToMinutes(s.endTime),d=i-r,u=i+d;if(d<=0||u>=1440)return p("Confira o horário da primeira aula. A segunda aula deve terminar antes da meia-noite.");a.push({...s,startTime:s.endTime,endTime:this.minutesToTime(u)})}try{for(let r=0;r<a.length;r+=1)try{await b.post("/api/schedules",a[r])}catch(i){if(r>0)return await this.init(),p(`A primeira aula foi criada, mas a segunda não pôde ser criada: ${i.message||"erro desconhecido"}`);throw i}this.hideCreateModal(),this.init()}catch(r){p(r.message||"Erro ao criar horário.")}},timeToMinutes(e){const[t,s]=(e||"").split(":").map(Number);return Number.isFinite(t)&&Number.isFinite(s)?t*60+s:NaN},minutesToTime(e){const t=String(Math.floor(e/60)).padStart(2,"0"),s=String(e%60).padStart(2,"0");return`${t}:${s}`},updateConsecutiveSchedulePreview(){var d,u;const e=c("#form-double-lesson"),t=c("#form-double-lesson-preview");if(!e||!t||(t.classList.toggle("hidden",!e.checked),!e.checked))return;const s=(d=c("#form-start"))==null?void 0:d.value,a=(u=c("#form-end"))==null?void 0:u.value,o=this.timeToMinutes(s),r=this.timeToMinutes(a),i=r-o;if(i<=0||r+i>=1440){t.textContent="Ajuste o primeiro horário para calcular a segunda aula.";return}t.textContent=`1ª: ${s}–${a} | 2ª: ${a}–${this.minutesToTime(r+i)}`},async updateSchedule(e){e.preventDefault();const t=c("#edit-form-id").value,s=c("#edit-form-teacher"),a={subject:c("#edit-form-subject").value,classGroup:c("#edit-form-class-group").value,date:c("#edit-form-date").value,room:c("#edit-form-room").value,startTime:c("#edit-form-start").value,endTime:c("#edit-form-end").value,teacherId:s.value,teacherName:s.options[s.selectedIndex].text,status:c("#edit-form-status").value};try{await b.patch(`/api/schedules/${t}`,a),this.hideEditModal(),this.init()}catch{p("Erro ao editar horário.")}},async deleteSchedule(e){if(await p("Deseja excluir este horário?",{confirm:!0,title:"Excluir horário"}))try{await b.delete(`/api/schedules/${e}`),this.init()}catch{p("Erro ao excluir.")}},async createLabBooking(e){e.preventDefault();const t={labId:c("#lab-type").value,teacherId:l.uid,teacherName:l.displayName,date:c("#lab-date").value,startTime:c("#lab-start").value,endTime:c("#lab-end").value};try{await b.post("/api/labs/bookings",t),this.hideLabModal(),this.init()}catch{p("Erro ao reservar.")}},async deleteLabBooking(e){if(await p("Deseja realmente cancelar esta reserva de laboratório?",{confirm:!0,title:"Cancelar reserva"}))try{await b.delete(`/api/labs/bookings/${e}`),await this.refreshData(),this.init()}catch{p("Erro ao excluir reserva.")}},async clearAllLabBookings(){if(await p("Deseja realmente apagar todos os agendamentos de laboratórios? Esta ação limpará a tabela por completo.",{confirm:!0,title:"Limpar reservas"}))try{await b.delete("/api/labs/bookings-clear-all"),await this.refreshData(),this.init()}catch{p("Erro ao apagar agendamentos da tabela.")}},async submitCert(e){e.preventDefault();const t=c("#cert-image");let s=null;if(t&&t.files[0])try{s=await new Promise((o,r)=>{const i=new FileReader;i.onloadend=()=>o(i.result),i.onerror=r,i.readAsDataURL(t.files[0])})}catch(o){console.error("File upload error:",o)}const a={teacherId:l.uid,teacherName:l.displayName,date:c("#cert-date").value,reason:c("#cert-reason").value,imageUrl:s};try{await b.post("/api/certificates",a),this.hideCertModal(),p("Atestado enviado com sucesso."),this.init()}catch{p("Erro ao enviar atestado.")}},viewImage(e){const t="image-viewer-modal";let s=c(`#${t}`);s||(document.body.insertAdjacentHTML("beforeend",`
            <div id="${t}" class="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md" onclick="this.classList.add('hidden')">
                <div class="relative bg-white p-2 rounded-2xl shadow-2xl max-w-4xl max-h-[90vh] overflow-auto" onclick="event.stopPropagation()">
                    <img id="viewer-img" src="" class="w-full h-auto rounded-xl">
                    <button class="absolute top-4 right-4 bg-white/10 hover:bg-white/20 p-2 rounded-full text-white backdrop-blur-md" onclick="document.getElementById('${t}').classList.add('hidden')">
                        <i data-lucide="x"></i>
                    </button>
                </div>
            </div>
        `),s=c(`#${t}`),typeof lucide<"u"&&lucide.createIcons());const a=s.querySelector("#viewer-img");a.src=e,s.classList.remove("hidden")},async viewImageById(e){try{const t=await b.get(`/api/certificates/${e}/image`);this.viewImage(t.imageUrl)}catch{p("Este certificado não possui uma imagem disponível.")}},nextSlide(){se<pt.length-1&&(se++,this.init())},prevSlide(){se>0&&(se--,this.init())},async approveCert(e){if(await p("Deseja aprovar este atestado? Isso converterá automaticamente os horários deste dia em AULA VAGA.",{confirm:!0,title:"Aprovar atestado"}))try{await b.patch(`/api/certificates/${e}/approve`,{}),this.init()}catch{p("Erro ao aprovar atestado.")}},setReportWeek(e){A=e,this.renderCurrentView()},setReportTurno(e){k=e,this.renderCurrentView()},setReportTeacher(e){H=e,this.renderCurrentView()},setReportCardSize(e){w=e,localStorage.setItem("reportCardSize",e),this.renderCurrentView()},setSchoolName(e){X=e;const t=c(".printable-sheet h4");t&&(t.textContent=e)},setRelatorioSubTab(e){re=e,this.renderCurrentView()},setReportModel(e){O=e,this.renderCurrentView()},setTeacherSchedulesTab(e){e==="grid"&&(pe="grid",this.renderCurrentView())},async downloadTeacherPDF(){const e=document.querySelector(".printable-sheet");if(!e)return;const t=document.querySelector("#btn-download-pdf-teacher"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);const a=e.cloneNode(!0);a.id="temp-pdf-teacher-container",a.className="printable-sheet bg-white",a.style.width="1020px",a.style.boxSizing="border-box",a.style.backgroundColor="#ffffff",a.style.padding="30px",document.body.appendChild(a),typeof lucide<"u"&&lucide.createIcons({node:a});const o={margin:[.3,.3,.3,.3],filename:`Grade_Professor_${l?l.displayName.replace(/\s+/g,"_"):"Individual"}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"}},r=Ie(a);let i=()=>{};try{i=await Ee()}catch(d){console.warn("Could not clean stylesheets:",d)}html2pdf().set(o).from(a).save().then(()=>{r(),i(),document.body.removeChild(a),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(d=>{r(),i(),document.getElementById("temp-pdf-teacher-container")&&document.body.removeChild(a),console.error("Error generating PDF:",d),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),p("Houve um erro ao gerar o PDF.")})},async downloadPDF(){if(!document.querySelector(".printable-sheet"))return;const t=document.querySelector("#btn-download-pdf"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);let a=$;A!=="all"&&(a=$.filter(g=>{try{return xe(g.date)===A}catch{return!1}}));let o=z;if(H!=="all"&&(o=z.filter(g=>g.uid===H)),o.length===0&&a.length>0){const g=new Set,S=[];a.forEach(j=>{j.teacherId&&!g.has(j.teacherId)&&(g.add(j.teacherId),S.push({uid:j.teacherId,displayName:j.teacherName,subject:j.subject}))}),o=S}let r=[];if(k==="matutino")r=["07:30","08:20","09:10","10:15","11:00","11:45"];else if(k==="vespertino")r=["13:00","13:50","14:40","15:45","16:30","17:15"];else if(k==="noturno")r=["18:45","19:30","20:30","21:15","22:00"];else{const g=ge();r=g.length>0?g:["07:30","08:20","09:10","10:15","11:00","11:45"]}let i=[];const d=O==="turma_grid";d?i=qe(a):i=o;const n={small:8,medium:4,large:3,esticado:2,super_esticado:1}[w]||4,m=[];for(let g=0;g<i.length;g+=n)m.push(i.slice(g,g+n));const x=document.createElement("div");x.id="temp-pdf-container",x.className="printable-sheet bg-white",x.style.width="1020px",x.style.padding="10px",x.style.boxSizing="border-box",x.style.backgroundColor="#ffffff";let f="grid grid-cols-2 gap-4 justify-center w-full";w==="small"?f="grid grid-cols-4 gap-2 justify-center w-full":w==="medium"?f="grid grid-cols-2 gap-4 justify-center w-full":w==="large"?f="grid grid-cols-3 gap-4 justify-center w-full":w==="esticado"?f="grid grid-cols-2 gap-4 justify-center w-full":w==="super_esticado"&&(f="grid grid-cols-1 gap-6 justify-center w-full");let E="";m.forEach((g,S)=>{const j=`
        <div class="flex justify-between items-center border-b border-blue-100 pb-4 mb-6 gap-4">
          <div class="flex items-center gap-4">
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
              <g transform="translate(68, 2)">
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          <div class="text-right">
            <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">${X}</h4>
            <p class="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest mt-0.5">
              ${d?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${A==="all"?"Grade Geral Acumulada":be(A)}
            </p>
          </div>
        </div>
      `,_=g.map(W=>{if(d){const L=a.filter(K=>K.classGroup===W);return De(W,L,r)}else{const L=a.filter(K=>K.teacherId===W.uid);return we(W,L,r,O)}}).join(""),N=`
        <div class="border-t border-slate-100 mt-6 pt-3 flex justify-between text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Página ${S+1} de ${m.length}</span>
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
      `,Z=S===m.length-1?"":"page-break-after: always;";E+=`
        <div class="pdf-page bg-white" style="${Z} width: 100%; box-sizing: border-box; padding-bottom: 20px;">
          ${j}
          <div class="${f}">
            ${_}
          </div>
          ${N}
        </div>
      `}),x.innerHTML=E,document.body.appendChild(x),typeof lucide<"u"&&lucide.createIcons({node:x});const h={margin:[.2,.2,.2,.2],filename:`Grade_Escolar_${A}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"},pagebreak:{mode:["avoid-all","css","legacy"]}},C=Ie(x);let y=()=>{};try{y=await Ee()}catch(g){console.warn("Could not clean stylesheets:",g)}html2pdf().set(h).from(x).save().then(()=>{C(),y(),document.body.removeChild(x),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(g=>{C(),y(),document.getElementById("temp-pdf-container")&&document.body.removeChild(x),console.error("Error generating PDF:",g),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),p("Houve um erro ao gerar o PDF.")})},showCreateEscolaModal(){const e=document.getElementById("create-escola-modal");e&&e.classList.remove("hidden")},hideCreateEscolaModal(){var t;const e=document.getElementById("create-escola-modal");e&&e.classList.add("hidden"),(t=document.getElementById("escola-name"))!=null&&t.value&&(document.getElementById("escola-name").value="")},async createSchool(e){var s;e&&e.preventDefault();const t=(s=document.getElementById("escola-name"))==null?void 0:s.value;if(!t)return p("Nome da escola é obrigatório.");try{await b.post("/api/schools",{name:t,createdBy:l.uid}),this.hideCreateEscolaModal(),await this.refreshData(),this.init(),p("Escola criada com sucesso!")}catch(a){p(a.message||"Erro ao criar escola.")}},async deleteSchool(e){if(!e)return;const t=R.find(a=>a.id===e);if(await p(`Deseja excluir a escola "${t==null?void 0:t.name}"? Esta ação não pode ser desfeita.`,{confirm:!0,title:"Excluir escola"}))try{await b.delete(`/api/schools/${e}`),await this.refreshData(),this.init(),p("Escola excluída com sucesso.")}catch(a){p(a.message||"Erro ao excluir escola.")}},showCreateUserModal(e="dev"){const t=document.getElementById("create-user-modal");t&&t.classList.remove("hidden")},hideCreateUserModal(){var t,s,a,o,r,i;const e=document.getElementById("create-user-modal");e&&e.classList.add("hidden"),(t=document.getElementById("user-displayname"))!=null&&t.value&&(document.getElementById("user-displayname").value=""),(s=document.getElementById("user-email"))!=null&&s.value&&(document.getElementById("user-email").value=""),(a=document.getElementById("user-password"))!=null&&a.value&&(document.getElementById("user-password").value=""),(o=document.getElementById("user-subject"))!=null&&o.value&&(document.getElementById("user-subject").value=""),(r=document.getElementById("user-school"))!=null&&r.value&&(document.getElementById("user-school").value=""),(i=document.getElementById("user-role"))!=null&&i.value&&(document.getElementById("user-role").value="")},async createUser(e){var u,n,m,x,f,E,h,C,y;e&&e.preventDefault();const t=(n=(u=document.getElementById("user-displayname"))==null?void 0:u.value)==null?void 0:n.trim(),s=(x=(m=document.getElementById("user-email"))==null?void 0:m.value)==null?void 0:x.trim(),a=(f=document.getElementById("user-password"))==null?void 0:f.value,o=(h=(E=document.getElementById("user-subject"))==null?void 0:E.value)==null?void 0:h.trim(),r=(C=document.getElementById("user-role"))==null?void 0:C.value,i=(y=document.getElementById("user-school"))==null?void 0:y.value;if(!t)return p("Nome é obrigatório.");if(!s)return p("E-mail é obrigatório.");if(!a)return p("Senha é obrigatória.");if(a.length<8)return p("Senha deve ter no mínimo 8 caracteres.");if(!r)return p("Cargo é obrigatório.");if((l==null?void 0:l.role)==="dev"&&!i)return p("Selecione a escola do usuário.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))return p("E-mail inválido.");try{const g={displayName:t,email:s,password:a,role:r,schoolId:i,userRole:l==null?void 0:l.role,userSchoolId:l==null?void 0:l.school_id};o&&(g.subject=o),await b.post("/api/users/create",g),this.hideCreateUserModal(),await this.refreshData(),this.init(),p("Usuário criado com sucesso!")}catch(g){const S=g.message||"Erro ao criar usuário.";p(S)}}};function Ge(e){try{const t=e.match(/oklch\(([^)]+)\)/i);if(!t)return"rgb(0, 0, 0)";const s=t[1].trim().split(/[\s,+/]+/);if(s.length<3)return"rgb(0, 0, 0)";let a=s[0].endsWith("%")?parseFloat(s[0])/100:parseFloat(s[0]),o=s[1].endsWith("%")?parseFloat(s[1])/100*.4:parseFloat(s[1]),r=0;s[2]!=="none"&&(s[2].endsWith("deg")?r=parseFloat(s[2]):s[2].endsWith("rad")?r=parseFloat(s[2])*180/Math.PI:s[2].endsWith("turn")?r=parseFloat(s[2])*360:r=parseFloat(s[2]));let i=1;s[3]!==void 0&&(i=s[3].endsWith("%")?parseFloat(s[3])/100:parseFloat(s[3]));const d=o*Math.cos(r*Math.PI/180),u=o*Math.sin(r*Math.PI/180),n=a+.3963377774*d+.2158037573*u,m=a-.1055613458*d-.0638541728*u,x=a-.0894841775*d-1.291485548*u,f=Math.pow(Math.max(0,n),3),E=Math.pow(Math.max(0,m),3),h=Math.pow(Math.max(0,x),3);let C=4.0767416621*f-3.3077115913*E+.2309699292*h,y=-1.2684380046*f+2.6097574011*E-.3413193965*h,g=-.0041960863*f-.7034186147*E+1.707614701*h;const S=C<=.0031308?12.92*C:1.055*Math.pow(C,1/2.4)-.055,j=y<=.0031308?12.92*y:1.055*Math.pow(y,1/2.4)-.055,_=g<=.0031308?12.92*g:1.055*Math.pow(g,1/2.4)-.055,N=Z=>Math.min(255,Math.max(0,Math.round(Z*255)));return i===1?`rgb(${N(S)}, ${N(j)}, ${N(_)})`:`rgba(${N(S)}, ${N(j)}, ${N(_)}, ${i})`}catch{return"rgb(0, 0, 0)"}}function he(e){return!e||typeof e!="string"||!e.includes("oklch")?e:e.replace(/oklch\([^)]+\)/gi,t=>{let s=document.getElementById("temp-color-resolver");s||(s=document.createElement("div"),s.id="temp-color-resolver",s.style.position="absolute",s.style.visibility="hidden",s.style.width="0",s.style.height="0",document.body.appendChild(s));try{s.style.color=t;const a=window.getComputedStyle(s,null).getPropertyValue("color");if(a&&!a.includes("oklch"))return a}catch{}return Ge(t)})}async function Ee(){const e=[],t=Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'));let s="";for(const r of t)try{if(r.tagName==="STYLE")s+=`
`+r.innerHTML,e.push({node:r,originalDisabled:r.disabled,type:"style"});else if(r.tagName==="LINK"){let i="";try{if(r.sheet){const d=r.sheet.cssRules||r.sheet.rules;for(let u=0;u<d.length;u++)i+=d[u].cssText+`
`}}catch{}if(!i){const d=r.getAttribute("href");d&&(d.startsWith("/")||d.startsWith("./")||d.startsWith("src/")||d.startsWith(window.location.origin))&&(i=await(await fetch(d)).text())}i&&(s+=`
`+i,e.push({node:r,originalDisabled:r.disabled,type:"link"}))}}catch(i){console.warn("Could not backup or read stylesheet:",r,i)}const a=s.replace(/oklch\([^)]+\)/gi,r=>Ge(r)),o=document.createElement("style");o.id="temp-cleaned-stylesheets",o.innerHTML=a,document.head.appendChild(o);for(const r of e)r.node.disabled=!0;return function(){for(const i of e)i.node.disabled=i.originalDisabled;o.parentNode&&o.parentNode.removeChild(o)}}function Ie(e){const t=mt(),s=[e,...e.querySelectorAll("*")],a=[];for(const o of s){if(!o||!o.style)continue;const r=o.getAttribute("style")||"";a.push({el:o,originalInlineStyle:r});try{const i=window.getComputedStyle(o),d=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"];for(const u of d){let n="";try{n=i.getPropertyValue(u.replace(/([A-Z])/g,"-$1").toLowerCase())}catch{n=i[u]}if(n&&typeof n=="string"&&n.includes("oklch")){const m=he(n);o.style[u]=m}}}catch{}}return function(){t();for(const r of a)r.originalInlineStyle?r.el.setAttribute("style",r.originalInlineStyle):r.el.removeAttribute("style")}}function mt(){const e=CSSStyleDeclaration.prototype.getPropertyValue;CSSStyleDeclaration.prototype.getPropertyValue=function(a){const o=e.call(this,a);return o&&typeof o=="string"&&o.includes("oklch")?he(o):o};const t=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"],s={};for(const a of t){const o=Object.getOwnPropertyDescriptor(CSSStyleDeclaration.prototype,a);o&&o.get&&(s[a]=o,Object.defineProperty(CSSStyleDeclaration.prototype,a,{configurable:!0,enumerable:!0,get(){const r=o.get.call(this);return r&&typeof r=="string"&&r.includes("oklch")?he(r):r},set(r){o.set.call(this,r)}}))}return function(){CSSStyleDeclaration.prototype.getPropertyValue=e;for(const o in s)Object.defineProperty(CSSStyleDeclaration.prototype,o,s[o])}}window.actions=_e;_e.init();
