(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const l of r.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&a(l)}).observe(document,{childList:!0,subtree:!0});function s(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(o){if(o.ep)return;o.ep=!0;const r=s(o);fetch(o.href,r)}})();const u=e=>document.querySelector(e);window.$=u;const le=(e=180,t=50)=>`
  <svg width="${e}" height="${t}" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
    <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
    
    <!-- Subtle glow on the outer swoosh -->
    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

    <!-- Book icon matching the user logo -->
    <g transform="translate(68, 2)">
      <!-- Left half -->
      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
      <!-- Right half -->
      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
    </g>

    <!-- Main Title: Studia -->
    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
    <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
  </svg>
`,F=e=>{const t=u("#app");t&&(t.innerHTML=e,typeof lucide<"u"&&lucide.createIcons())},p=(e,{confirm:t=!1,title:s="Studia"}={})=>new Promise(a=>{var l;const o=document.createElement("div");o.style.cssText="position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.55);backdrop-filter:blur(5px);font-family:system-ui,sans-serif;",o.innerHTML=`
    <div style="width:min(100%,440px);background:#fff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 24px 60px rgba(15,23,42,.25);padding:28px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;color:#2563eb;">
        <div style="width:40px;height:40px;border-radius:10px;background:#eff6ff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;">S</div>
        <h3 style="margin:0;color:#0f172a;font-size:18px;font-weight:800;">${s}</h3>
      </div>
      <p data-dialog-message style="margin:0;color:#475569;font-size:14px;line-height:1.6;white-space:pre-line;"></p>
      <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
        ${t?'<button data-dialog-cancel type="button" style="border:1px solid #e2e8f0;background:#fff;color:#475569;border-radius:10px;padding:11px 20px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;">Cancelar</button>':""}
        <button data-dialog-ok type="button" style="border:0;background:#2563eb;color:#fff;border-radius:10px;padding:11px 22px;font-weight:700;cursor:pointer;transition:all 0.2s;font-size:14px;box-shadow:0 4px 12px rgba(37,99,235,0.25);">${t?"Confirmar":"Entendi"}</button>
      </div>
    </div>`,o.querySelector("[data-dialog-message]").textContent=e;const r=d=>{o.remove(),a(d)};o.querySelector("[data-dialog-ok]").addEventListener("click",()=>r(!0)),(l=o.querySelector("[data-dialog-cancel]"))==null||l.addEventListener("click",()=>r(!1)),o.addEventListener("click",d=>{d.target===o&&r(!1)}),document.body.appendChild(o),o.querySelector("[data-dialog-ok]").focus()});let i=null;try{const e=localStorage.getItem("user");e&&e!=="undefined"&&e!=="null"&&(i=JSON.parse(e))}catch(e){console.error("Error parsing user from localStorage:",e)}let k=[],R=[],N=[],G=new Set,oe=null,B=[],H=[],K="",T=null,ue=[],pe=[],J={},M={total:0,confirmed:0,absent:0,pending:0},v="horarios",I="closed",q=[],P={date:"",labId:"all",teacher:""},D="all",$="matutino",W="all",X="COLÉGIO ESTADUAL PROF. JÚLIO SZYMANSKI - MATUTINO",re="urania",U="prof_turma",w=localStorage.getItem("reportCardSize")||"medium",me="grid",be=!1,de=!1,L=(localStorage.getItem("api_base_url")||"").trim();(L==="undefined"||L==="null"||L==="/")&&(L="");const Ie=["localhost","127.0.0.1","::1"].includes(window.location.hostname),Me=window.location.hostname.endsWith(".onrender.com");Ie&&(L="http://localhost:3000",localStorage.removeItem("api_base_url"));Me&&(L="",localStorage.removeItem("api_base_url"));const Ge=!Ie&&!Me;Ge&&(L="https://studia-8st9.onrender.com",localStorage.setItem("api_base_url",L));const Se=e=>{if(e.startsWith("http://")||e.startsWith("https://"))return e;const t=e.startsWith("/")?e:"/"+e;return L?`${L.endsWith("/")?L.slice(0,-1):L}${t}`:t},x={async request(e,t={}){let s=Se(e),a;try{const l={"Content-Type":"application/json",...t.headers};i!=null&&i.accessToken&&(l.Authorization=`Bearer ${i.accessToken}`),a=await fetch(s,{...t,headers:l})}catch(l){console.error("Fetch error on primary URL:",l);let d=null;if(s.includes("ais-pre-")?d=s.replace("ais-pre-","ais-dev-"):s.includes("ais-dev-")&&(d=s.replace("ais-dev-","ais-pre-")),d){console.log("Trying fallback API URL:",d);try{a=await fetch(d,{...t,headers:{"Content-Type":"application/json",...t.headers,...i!=null&&i.accessToken?{Authorization:`Bearer ${i.accessToken}`}:{}}});const n=new URL(d).origin;L=n,localStorage.setItem("api_base_url",n),s=d}catch(c){throw console.error("Fetch error on fallback URL:",c),new Error(`Erro de conexão com o servidor de API.

Tentamos:
1. ${s}
2. ${d}

Verifique se o seu servidor Cloud Run está ativo.`)}}else throw new Error(`Erro de conexão com o servidor de API (${s}).`)}if(a.status===401&&(i!=null&&i.refreshToken)&&!e.startsWith("/api/auth/"))try{const l=await fetch(Se("/api/auth/refresh"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({refreshToken:i.refreshToken})}),d=await l.json();if(l.ok){i={...i,accessToken:d.accessToken,refreshToken:d.refreshToken},localStorage.setItem("user",JSON.stringify(i));const c={"Content-Type":"application/json",...t.headers,Authorization:`Bearer ${i.accessToken}`};a=await fetch(s,{...t,headers:c})}}catch(l){console.error("Session refresh failed:",l)}if(a.status===401&&i&&!e.startsWith("/api/auth/"))throw localStorage.removeItem("user"),i=null,v="horarios",F(he()),new Error("Sua sessão não é mais válida. Entre novamente com uma conta ativa para continuar.");const o=await a.text();let r;try{r=JSON.parse(o)}catch(l){throw console.error("Parse error:",l),new Error(`Resposta inválida do servidor de API (${s}).`)}if(!a.ok)throw new Error(r.error||`Erro ${a.status}`);return r},async post(e,t){return this.request(e,{method:"POST",body:JSON.stringify(t)})},async get(e){return this.request(e,{method:"GET"})},async patch(e,t){return this.request(e,{method:"PATCH",body:JSON.stringify(t)})},async delete(e){return this.request(e,{method:"DELETE"})}},ie=e=>{const t=e.split("-");return t.length===3?new Date(parseInt(t[0],10),parseInt(t[1],10)-1,parseInt(t[2],10)):new Date(e)},ge=e=>{const t=ie(e),s=t.getDay(),a=t.getDate()-s+(s===0?-6:1),o=new Date(t);o.setDate(a);const r=o.getFullYear(),l=String(o.getMonth()+1).padStart(2,"0"),d=String(o.getDate()).padStart(2,"0");return`${r}-${l}-${d}`},fe=e=>{const t=ie(e),s=new Date(t);s.setDate(t.getDate()+4);const a=o=>{const r=String(o.getDate()).padStart(2,"0"),l=String(o.getMonth()+1).padStart(2,"0");return`${r}/${l}`};return`Semana de ${a(t)} a ${a(s)}`},Ue=()=>{const e=new Set;return k.forEach(t=>{if(t.date)try{e.add(ge(t.date))}catch(s){console.error("Error formatting week:",s)}}),Array.from(e).sort().reverse()},ve=()=>{const e=new Set;return k.forEach(t=>{t.startTime&&e.add(t.startTime)}),Array.from(e).sort()},Fe=e=>{const t=new Set;return e.forEach(s=>{s.classGroup&&t.add(s.classGroup)}),Array.from(t).sort()},De=e=>{const t=e.getDay();return t===0?7:t},qe=new Map([["programacao front-end","Prog. Front-End"],["programacao back-end","Prog. Back-End"],["programacao back-end i","Prog. Back-End I"],["programacao back-end ii","Prog. Back-End II"],["programacao mobile","Prog. Mobile"],["programacao de desenvolvimento de sistemas","Prog. de Desenv. de Sistemas"],["analise e projeto de sistemas","Análise e Proj. de Sistemas"],["educacao fisica","Ed. Física"],["educacao financeira","Ed. Financeira"],["lingua portuguesa","Língua Port."]]),we=e=>{const t=String(e||"").trim();if(!t)return t;const s=t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/\s+/g," ");return qe.get(s)||t.replace(/\bprogramação\b/gi,"Prog.").replace(/\bdesenvolvimento\b/gi,"Desenv.").replace(/\beducação\b/gi,"Ed.").replace(/\bportuguesa\b/gi,"Port.").replace(/\bprojeto\b/gi,"Proj.")},Y=e=>{if(!e)return e;const t=String(e).trim();return!t||t==="------"?t:t.includes("/")?t.split("/").map(s=>Y(s)).join(" / "):t.replace(/\s+/g," ").replace(/^(\d+)([A-Za-zÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÇ]+)/u,"$1 $2")},He=e=>{const t=Y(e);return t.split(" - ").map((s,a)=>a===0&&t.includes(" - ")?s:we(s)).join(" - ")},Ve=(e,t)=>t==="matutino"?e>="07:00"&&e<"12:00":t==="vespertino"?e>="12:00"&&e<"18:00":t==="noturno"?e>="18:00"&&e<"23:00":!0,ye=(e,t,s,a="prof_turma")=>{const o=["Seg","Ter","Qua","Qui","Sex"],r={};s.forEach(h=>{r[h]={},o.forEach(C=>{r[h][C]="------"})}),t.forEach(h=>{var j,O,_;const C=ie(h.date),y=De(C),g=y>=1&&y<=5?o[y-1]:null,S=((j=h.startTime)==null?void 0:j.substring(0,5))||h.startTime;if(g&&r[S]){if(h.status!=="confirmed"&&h.status!=="pending"&&((O=h.subject)==null?void 0:O.toUpperCase())!=="HAF")return;const Q=((_=h.subject)==null?void 0:_.toUpperCase())==="HAF";let A="------";if(Q)A="HAF";else if(a==="prof_turma")A=Y(h.classGroup||"------");else if(a==="prof_subject")A=h.subject||"------";else{const Z=h.subject&&e.subject&&h.subject.trim().toLowerCase()!==e.subject.trim().toLowerCase();A=h.classGroup&&Z?`${Y(h.classGroup)} - ${h.subject}`:Y(h.classGroup||h.subject||"------")}r[S][g]==="------"?r[S][g]=A:r[S][g].split("/").includes(A)||(r[S][g]+="/"+A)}});let l="font-size: 11px; padding: 0.75rem;",d="text-[12px]",c="text-[9.5px]",n="text-[9px]",m="text-[10px]",f="h-9";w==="small"?(l="font-size: 8.5px; padding: 0.5rem;",d="text-[9px]",c="text-[7.5px]",n="text-[7px]",m="text-[7.5px]",f="h-5"):w==="large"?(l="font-size: 13.5px; padding: 1rem;",d="text-[14px]",c="text-[11px]",n="text-[11px]",m="text-[12.5px]",f="h-11"):w==="esticado"?(l="font-size: 15px; padding: 1.25rem;",d="text-[16px]",c="text-[12px]",n="text-[12px]",m="text-[13.5px]",f="h-12"):w==="super_esticado"&&(l="font-size: 18px; padding: 1.75rem;",d="text-[20px]",c="text-[14px]",n="text-[14px]",m="text-[16.5px]",f="h-16");const b=[...new Set(t.map(h=>h.classGroup).filter(Boolean))],E=b.length?` (${b.join(", ")})`:"";return`
    <div class="bg-white border border-[#cbd5e1] rounded-md text-slate-800 shadow-none flex flex-col justify-between break-inside-avoid text-xs w-full min-h-[285px]" style="${l}">
      <div class="mb-1.5 flex flex-wrap justify-between items-center gap-x-2 gap-y-0.5 bg-slate-100 px-2 py-1.5 rounded-sm">
        <span class="min-w-0 flex-1 font-extrabold uppercase text-slate-900 whitespace-normal break-words ${d}">${e.displayName}${E}</span>
        <span title="${e.subject||"Professor"}" class="shrink-0 ${c} text-[#5B99C2] font-extrabold uppercase tracking-tight whitespace-normal break-words">${we(e.subject||"Professor")}</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="border border-slate-300 font-semibold text-[#5B99C2] ${n} py-0.5 px-1 text-left w-[48px]">Hor</th>
            ${o.map(h=>`<th class="border border-slate-300 font-bold text-slate-700 ${n} py-0.5 px-1">${h}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(h=>`
            <tr class="${f}">
              <td class="border border-slate-300 font-extrabold text-[#2E5077] ${n} text-left py-0.5 px-1">${h}</td>
              ${o.map(C=>{const y=r[h][C];return`<td title="${y}" class="border border-slate-300 ${m} py-0.5 px-1 whitespace-normal break-words ${y==="HAF"?"text-[#5B99C2] font-black":y!=="------"?"text-slate-900 font-black":"text-slate-400"}">${y.split("/").map(He).join(" / ")}</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},Le=(e,t,s)=>{console.log(`[DEBUG TurmaScheduleCard] turmaName="${e}", weekSchedules count=${t.length}, slots=${s.join(", ")}`);const a=["Seg","Ter","Qua","Qui","Sex"],o={};s.forEach(b=>{o[b]={},a.forEach(E=>{o[b][E]=null})}),t.forEach(b=>{var g,S;const E=ie(b.date),h=De(E),C=a[h-1],y=((g=b.startTime)==null?void 0:g.substring(0,5))||b.startTime;if(C&&o[y]){if(b.status!=="confirmed"&&b.status!=="pending"&&((S=b.subject)==null?void 0:S.toUpperCase())!=="HAF")return;const j=R.find(O=>O.uid===b.teacherId);o[y][C]={teacherName:(j==null?void 0:j.displayName)||b.teacherName||"------",subject:b.subject||"------",status:b.status}}});let r="font-size: 11px; padding: 0.75rem;",l="text-[12px]",d="text-[9.5px]",c="text-[9px]",n="text-[10px]",m="text-[8.5px]",f="h-11";return w==="small"?(r="font-size: 8.5px; padding: 0.5rem;",l="text-[9px]",d="text-[7.5px]",c="text-[7px]",n="text-[8.5px]",m="text-[7.5px]",f="h-8"):w==="large"?(r="font-size: 13.5px; padding: 1rem;",l="text-[14px]",d="text-[11px]",c="text-[11px]",n="text-[12.5px]",m="text-[11px]",f="h-16"):w==="esticado"?(r="font-size: 15px; padding: 1.25rem;",l="text-[16px]",d="text-[12px]",c="text-[12px]",n="text-[14px]",m="text-[12px]",f="h-14"):w==="super_esticado"&&(r="font-size: 18px; padding: 1.75rem;",l="text-[20px]",d="text-[14px]",c="text-[14px]",n="text-[17px]",m="text-[14px]",f="h-20"),`
    <div class="bg-white border border-[#cbd5e1] rounded-md text-slate-800 shadow-none flex flex-col justify-between break-inside-avoid text-xs w-full min-h-[285px]" style="${r}">
      <div class="mb-1.5 flex flex-wrap justify-between items-center gap-x-2 bg-slate-100 px-2 py-1.5 rounded-sm">
        <span class="font-extrabold uppercase text-slate-900 truncate ${l}">Turma: ${e}</span>
        <span class="${d} text-[#5B99C2] font-extrabold uppercase tracking-tight">GRADE HORÁRIA</span>
      </div>
      <table class="w-full text-center border-collapse table-fixed">
        <thead>
          <tr class="border-b border-slate-200">
            <th class="border border-slate-300 font-semibold text-[#5B99C2] ${c} py-0.5 px-1 text-left w-[48px]">Hor</th>
            ${a.map(b=>`<th class="border border-slate-300 font-bold text-slate-700 ${c} py-0.5 px-1">${b}</th>`).join("")}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${s.map(b=>`
            <tr class="${f}">
              <td class="border border-slate-300 font-extrabold text-[#2E5077] ${c} text-left py-0.5 px-1 align-middle">${b}</td>
              ${a.map(E=>{var y;const h=o[b][E];return h?((y=h.subject)==null?void 0:y.toUpperCase())==="HAF"?`
                    <td class="border border-slate-300 py-0.5 px-1 align-middle leading-tight whitespace-normal break-words">
                      <div class="font-black text-[#5B99C2] ${n}">HAF</div>
                    </td>
                  `:`
                  <td class="border border-slate-300 py-0.5 px-1 align-middle leading-tight whitespace-normal break-words">
                    <div class="font-black text-slate-900 whitespace-normal break-words ${n}">${h.teacherName}</div>
                    <div title="${h.subject}" class="text-slate-400 font-extrabold whitespace-normal break-words uppercase mt-0.5 ${m}">${we(h.subject)}</div>
                  </td>
                `:`<td class="border border-slate-300 text-slate-300 ${n} py-0.5 px-1 align-middle">------</td>`}).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `},he=()=>`
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1a1f3a 100%); min-height: 100vh; color: #fff; font-family: system-ui, -apple-system, sans-serif; overflow-x: hidden;">
    <style>
      @keyframes slideInDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes slideInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeInUp { from { opacity: 0; } to { opacity: 1; } }
      details summary:hover { color: #2563eb !important; }
      @media (max-width: 768px) {
        h1 { font-size: 1.75rem !important; }
        nav > div:nth-child(2) { display: none; }
      }
    </style>

    <!-- Navbar -->
    <nav style="position: fixed; top: 0; left: 0; right: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 1.5rem 2rem; z-index: 40; display: flex; align-items: center; justify-content: space-between;">
      <div style="display: flex; align-items: center; gap: 1rem;">
        ${le(140,40)}
      </div>
      <div style="display: flex; gap: 2rem; align-items: center;">
        <a onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Como Funciona</a>
        <a onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Recursos</a>
        <a onclick="document.getElementById('faq').scrollIntoView({behavior:'smooth'})" style="color: #94a3b8; text-decoration: none; font-weight: 500; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">FAQ</a>
        <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 0.7rem 1.5rem; border-radius: 0.5rem; font-weight: 600; cursor: pointer; transition: all 0.3s;">Acessar Portal</button>
      </div>
    </nav>

    <!-- Hero Section -->
    <section style="padding-top: 8rem; padding-bottom: 4rem; text-align: center; animation: slideInDown 0.8s ease-out;">
      <div style="max-width: 900px; margin: 0 auto; padding: 0 1rem;">
        <div style="background: rgba(37, 99, 235, 0.1); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 2rem; padding: 0.5rem 1.5rem; display: inline-block; margin-bottom: 2rem;">
          <span style="color: #06b6d4; font-weight: 600; font-size: 0.85rem;">Organização escolar em um só lugar</span>
        </div>
        <h1 style="font-size: 3.5rem; font-weight: 900; line-height: 1.1; margin-bottom: 1.5rem; letter-spacing: -1px;">A rotina da escola<br><span style="background: linear-gradient(135deg, #2563eb, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">mais organizada</span><br>e fácil de acompanhar.</h1>
        <p style="font-size: 1.25rem; color: #cbd5e1; margin-bottom: 2.5rem; max-width: 600px; margin-left: auto; margin-right: auto; line-height: 1.6;">Consulte horários, acompanhe as turmas e organize o uso dos laboratórios em uma plataforma simples para professores e direção.</p>
        <div style="display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap;">
          <button onclick="actions.showLoginModal('login')" style="background: #2563eb; color: white; border: none; padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 30px rgba(37, 99, 235, 0.3);">🎓 Entrar no Portal da Escola</button>
          <button onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})" style="background: transparent; color: white; border: 2px solid rgba(255, 255, 255, 0.2); padding: 1.2rem 2.5rem; border-radius: 0.7rem; font-weight: 700; font-size: 1rem; cursor: pointer; transition: all 0.3s;">Conhecer recursos</button>
        </div>
        <div style="display: flex; gap: 3rem; justify-content: center; margin-top: 3rem; flex-wrap: wrap; font-weight: 600; font-size: 0.9rem;">
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Grade de horários por professor e turma</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Reservas de laboratório consultáveis</div>
          <div style="color: #cbd5e1;"><span style="color: #06b6d4; font-size: 1.5rem; font-weight: 900;">✓</span> Acesso pelo navegador</div>
        </div>
      </div>
    </section>

    <!-- Main resources -->
    <section style="background: rgba(15, 23, 42, 0.5); border-top: 1px solid rgba(37, 99, 235, 0.1); border-bottom: 1px solid rgba(37, 99, 235, 0.1); padding: 4rem 2rem; animation: fadeInUp 1s ease-out 0.3s both;">
      <div style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 2rem; text-align: center;">
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #2563eb;">Horários</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Organizados por professor, turma e período</div></div>
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #06b6d4;">Laboratórios</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Reservas em uma agenda compartilhada da escola</div></div>
        <div><div style="font-size: 1.25rem; font-weight: 900; color: #2563eb;">Relatórios</div><div style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Grades para consulta e impressão</div></div>
      </div>
    </section>

    <!-- Features Section -->
    <section id="features" style="padding: 6rem 2rem; max-width: 1200px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">RECURSOS PARA A ROTINA ESCOLAR</div>
        <h2 style="font-size: 2.5rem; font-weight: 900; margin-bottom: 1rem;">Informações claras para cada pessoa da escola</h2>
        <p style="color: #cbd5e1; font-size: 1.1rem; max-width: 600px; margin: 0 auto;">A direção organiza os dados da escola e cada professor acompanha seus horários e reservas.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
        <div style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.4s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #2563eb, #1e40af); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">⚡</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Grade de horários</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Consulte e organize os horários de aula com professor, matéria, turma, sala e período.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(37, 99, 235, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Visões por professor e turma</div>
        </div>

        <div style="background: rgba(6, 182, 212, 0.05); border: 1px solid rgba(6, 182, 212, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.5s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #06b6d4, #0891b2); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">🛡️</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Espaços Otimizados</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Consulte reservas por data e laboratório e confira os horários já agendados antes de reservar.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(6, 182, 212, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Consulta de disponibilidade</div>
        </div>

        <div style="background: rgba(168, 85, 247, 0.05); border: 1px solid rgba(168, 85, 247, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.6s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #a855f7, #9333ea); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📊</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Acesso por perfil</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Direção e professores encontram ferramentas adequadas às suas atividades e permissões.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(168, 85, 247, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Cada perfil vê suas ferramentas</div>
        </div>

        <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 1.5rem; padding: 2rem; transition: all 0.3s; animation: slideInUp 0.8s ease-out 0.7s both;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 0.75rem; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem;">📄</div>
          <h3 style="font-size: 1.25rem; font-weight: 900; margin-bottom: 0.75rem;">Relatórios e impressão</h3>
          <p style="color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;">Gere grades de horários para consultar ou imprimir, com opções de visualização por professor e turma.</p>
          <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(239, 68, 68, 0.2); color: #06b6d4; font-size: 0.85rem; font-weight: 600;">✓ Exportação de grades em PDF</div>
        </div>
      </div>
    </section>

    <!-- FAQ -->
    <section id="faq" style="padding: 6rem 2rem; max-width: 900px; margin: 0 auto; border-top: 1px solid rgba(37, 99, 235, 0.1);">
      <div style="text-align: center; margin-bottom: 4rem;">
        <div style="color: #06b6d4; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">PERGUNTAS FREQUENTES</div>
        <h2 style="font-size: 2.5rem; font-weight: 900;">Tire suas dúvidas sobre o Studia</h2>
      </div>
      <div style="space-y: 2rem;">
        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como consultar os horários da escola?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Depois de entrar no portal, professores consultam seus horários e a direção pode organizar e visualizar a grade da escola.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os dados da minha escola são seguros e privados?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">As telas e os dados disponíveis dependem do perfil da conta: professor ou direção pedagógica.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Os professores precisam instalar algum aplicativo pesado?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Não. O portal pode ser acessado pelo navegador do computador ou celular.</p>
        </details>

        <details style="background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2); border-radius: 1rem; padding: 1.5rem; margin-bottom: 1rem; cursor: pointer;">
          <summary style="font-weight: 700; cursor: pointer; color: #fff;">Como reservar um laboratório?</summary>
          <p style="color: #cbd5e1; margin-top: 1rem; line-height: 1.6;">Na aba Laboratórios, consulte as reservas da escola por data e espaço. Ao reservar, o sistema verifica se o horário já está ocupado.</p>
        </details>
      </div>
    </section>

    <!-- Footer -->
    <footer style="background: rgba(15, 23, 42, 0.8); border-top: 1px solid rgba(37, 99, 235, 0.1); padding: 3rem 2rem; text-align: center; color: #94a3b8;">
      <p>© 2026 Studia SaaS — Todos os direitos reservados.</p>
      <p style="margin-top: 1rem; font-size: 0.9rem;">Horários, reservas de laboratório e relatórios para a rotina escolar.</p>
    </footer>

    <!-- Login/Register Modal -->
    <div id="login-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 ${I==="closed"?"hidden":""}">
      <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLoginModal()"></div>
      <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
        <div class="flex justify-center mb-6">
          ${le(160,44)}
        </div>
        <div class="flex gap-2 mb-8 bg-slate-100 p-1.5 rounded-xl">
            <button onclick="actions.toggleAuthMode('login')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${I==="login"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Entrar</button>
            <button onclick="actions.toggleAuthMode('register')" class="flex-1 py-2 rounded-lg font-bold text-sm transition-all ${I==="register"?"bg-white text-blue-600 shadow-sm":"text-slate-500"}">Criar Conta</button>
        </div>

        <h3 class="text-2xl font-bold mb-2">${I==="login"?"Bem-vindo de volta":"Nova conta Studia"}</h3>
        <p class="text-slate-500 text-sm mb-6 font-medium">${I==="login"?"Acesse seu painel.":"Crie sua conta de professor."}</p>

        <div class="space-y-4">
          ${I==="register"?`
            <input type="text" id="auth-name" placeholder="Seu nome completo" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
            <input type="text" id="auth-subject" placeholder="Matérias (separe por vírgula)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
            <select id="auth-school" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
              <option value="">Selecione a escola</option>
              ${(window.publicSchools||[]).map(e=>`<option value="${e.id}">${e.name}</option>`).join("")}
            </select>
          `:""}
          <input type="email" id="auth-email" placeholder="nome@escola.pr.gov.br" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">
          <input type="password" id="auth-password" placeholder="Sua senha" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-medium text-sm text-slate-900">

          <button onclick="${I==="login"?"actions.login()":"actions.register()"}" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold shadow-md shadow-blue-500/15 mt-2 transition-all">
            ${I==="login"?"Entrar":"Cadastrar"}
          </button>
        </div>
      </div>
    </div>
  </div>
`,ce=()=>{const e=ve();let t=[];$==="matutino"?t=["07:30","08:20","09:10","10:15","11:00","11:45"]:$==="vespertino"?t=["13:00","13:50","14:40","15:45","16:30","17:15"]:$==="noturno"?t=["18:45","19:30","20:30","21:15","22:00"]:t=e.length>0?e:["07:30","08:20","09:10","10:15","11:00","11:45"];const s=[{id:"horarios",icon:"calendar",label:"Meus Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"materias",icon:"book",label:"Minhas Matérias"}],a={initials:i.displayName?i.displayName.slice(0,2).toUpperCase():"PR",name:i.displayName,subtitle:i.subject||"Professor"};return`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${$e({theme:"light",sectionLabel:"Principal",navItems:s,profile:a})}
    ${ke({theme:"light",sectionLabel:"Principal",navItems:s,profile:a,drawerId:"mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-toggle-mobile-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <h2 class="font-bold text-base md:text-lg capitalize">${v==="horarios"?"Meus Horários":v==="labs"?"Laboratórios":"Minhas Matérias"}</h2>
        </div>
        <div class="flex gap-2">
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm shadow-md transition-all" id="btn-teacher-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
          <button onclick="actions.refreshSchedules()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 md:px-5 py-2 md:py-2.5 rounded-lg font-bold flex items-center gap-1.5 md:gap-2 text-xs md:text-sm transition-all" id="btn-refresh-teacher-schedules">
            <i data-lucide="refresh-cw" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Atualizar</span>
          </button>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?`
          <!-- Switch between sub-tabs with counts -->
          <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-6 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
            <button onclick="actions.setTeacherSchedulesTab('grid')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${me==="grid"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
              <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Horários Completa
            </button>
          </div>

          ${me==="grid"?`
            <!-- Grid Control Box -->
            <div class="bg-white p-6 rounded-3xl border shadow-sm space-y-4 print:hidden">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Turno / Períodos</label>
                  <select onchange="actions.setReportTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="matutino" ${$==="matutino"?"selected":""}>Manhã (07:30 - 11:45)</option>
                    <option value="vespertino" ${$==="vespertino"?"selected":""}>Tarde (13:00 - 17:15)</option>
                    <option value="noturno" ${$==="noturno"?"selected":""}>Noite (18:45 - 22:45)</option>
                    <option value="auto" ${$==="auto"?"selected":""}>Auto-detecção</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Tamanho da Grade</label>
                  <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
                    <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
                    <option value="large" ${w==="large"?"selected":""}>Grande</option>
                    <option value="esticado" ${w==="esticado"?"selected":""}>Descrição Larga</option>
                    <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Página Inteira</option>
                  </select>
                </div>

                <div class="space-y-1">
                  <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Opções Rápidas</label>
                  <button id="btn-download-pdf-teacher" onclick="actions.downloadTeacherPDF()" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold text-sm shadow-md flex items-center justify-center gap-1.5 transition-all">
                    <i data-lucide="download" class="w-4 h-4"></i> Baixar PDF
                  </button>
                </div>
              </div>
            </div>

            <!-- Beautiful Grid Sheet Preview -->
            <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-8 md:p-12 shadow-xl relative overflow-hidden">
              <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
                <div class="flex items-center gap-4">
                  <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
                    <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
                    <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
                    <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
                    <g transform="translate(68, 2)">
                      <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                      <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                      <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                      <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                    </g>
                    <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
                    <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
                  </svg>
                </div>
                
                <div class="text-center md:text-right">
                  <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${X}</h4>
                  <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
                    Grade de Horários Individual do Professor
                  </p>
                </div>
              </div>

              <!-- Center wrapper -->
              <div class="flex justify-center">
                <div class="w-full max-w-2xl overflow-x-auto pb-4 scrollbar-none">
                  <div class="min-w-[550px]">
                    ${ye(i,k.filter(o=>o.teacherId===i.uid),t)}
                  </div>
                </div>
              </div>

              <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
                <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
              </div>
            </div>
          `:`
            <!-- Sched List -->
            <div class="grid gap-6">
              ${k.map(o=>`
                <div class="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 md:gap-6 print:shadow-none print:border-slate-300">
                  <div class="flex items-center gap-4 md:gap-6 min-w-0 flex-1">
                    <div class="w-16 text-center border-r pr-4 md:pr-6 shrink-0">
                        <p class="text-lg font-black text-slate-800">${o.startTime}</p>
                    </div>
                    <div class="min-w-0 flex-1">
                      <h3 class="text-base md:text-xl font-black text-slate-900 truncate flex items-center gap-2">
                        ${o.subject}
                        ${o.classGroup?`<span class="bg-blue-100 text-[#2E5077] text-[10px] uppercase font-black px-2 py-0.5 rounded">${o.classGroup}</span>`:""}
                      </h3>
                      <div class="flex flex-wrap items-center gap-3 md:gap-4 mt-1">
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="map-pin" class="w-3.5 h-3.5"></i> ${o.room}</span>
                        <span class="text-xs font-bold text-slate-400 flex items-center gap-1 shrink-0"><i data-lucide="calendar" class="w-3.5 h-3.5"></i> ${o.date}</span>
                      </div>
                    </div>
                  </div>
                  <div class="flex flex-col gap-3 w-full sm:w-auto sm:min-w-[200px] shrink-0 print:hidden">
                    <div class="text-center py-2 bg-slate-50 rounded-xl border text-[10px] font-black uppercase tracking-widest ${o.status==="confirmed"?"text-blue-600":o.status==="absent"?"text-rose-500":"text-amber-500"}">
                      ${o.status==="confirmed"?"Confirmado":o.status==="absent"?"Ausente":"Pendente"}
                    </div>
                  </div>
                </div>
              `).join("")}
            </div>
          `}
        `:""}
        ${v==="materias"?dt():""}
        ${v==="labs"?_e():""}
      </div>
    </main>
    
  </div>
  `},We=e=>{const t=R.find(s=>s.uid===e);return t?H.filter(s=>s.school_id===t.school_id&&(s.teacherIds||[]).includes(e)).map(s=>s.subject):[]},Ae=()=>`
  <!-- Same Create Modal logic but with current state -->
  <div id="create-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Novo Agendamento</h3>
      <form onsubmit="actions.createSchedule(event)" class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <input type="text" id="form-subject" list="form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <datalist id="form-subject-options"></datalist>
          <input type="text" id="form-class-group" placeholder="Turma (ex: 9A, 3BI)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <input type="date" id="form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <input type="text" id="form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <input type="time" id="form-start" oninput="actions.updateConsecutiveSchedulePreview()" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" value="18:45" required>
          <input type="time" id="form-end" oninput="actions.updateConsecutiveSchedulePreview()" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" value="22:45" required>
        </div>
        <div class="rounded-xl border border-slate-200 p-3">
          <label class="flex cursor-pointer items-center gap-2 text-sm font-bold text-slate-700">
            <input type="checkbox" id="form-double-lesson" onchange="actions.updateConsecutiveSchedulePreview()" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
            Duas aulas seguidas
          </label>
          <p class="mt-1 pl-6 text-xs font-medium text-slate-500">O segundo horário começa quando o primeiro termina e terá a mesma duração.</p>
          <p id="form-double-lesson-preview" class="mt-2 hidden pl-6 text-xs font-bold text-blue-700"></p>
        </div>
        <select id="form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          <option value="">Selecione o Professor</option>
          ${R.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
        </select>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar Horário</button>
        </div>
      </form>
    </div>
  </div>
`,Pe=()=>`
  <div id="edit-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideEditModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl overflow-y-auto max-h-[90vh]">
      <h3 class="text-2xl font-bold mb-6 text-slate-800">Editar Horário</h3>
      <form onsubmit="actions.updateSchedule(event)" class="space-y-4">
        <input type="hidden" id="edit-form-id">
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Matéria</label>
            <input type="text" id="edit-form-subject" list="edit-form-subject-options" placeholder="Selecione ou digite a matéria" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <datalist id="edit-form-subject-options"></datalist>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Turma</label>
            <input type="text" id="edit-form-class-group" placeholder="Turma (ex: 9A, 3BI)" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Data</label>
            <input type="date" id="edit-form-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Sala / Local</label>
            <input type="text" id="edit-form-room" placeholder="Sala" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Início</label>
            <input type="time" id="edit-form-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
          <div>
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Hora Término</label>
            <input type="time" id="edit-form-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </div>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Professor</label>
          <select id="edit-form-teacher" onchange="actions.updateScheduleSubjectOptions(this.value, '', 'edit-form')" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="">Selecione o Professor</option>
            ${R.map(e=>`<option value="${e.uid}">${e.displayName}</option>`).join("")}
          </select>
        </div>
        <div>
          <label class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Status</label>
          <select id="edit-form-status" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="pending">Pendente</option>
            <option value="confirmed">Confirmado</option>
            <option value="absent">Falta / Ausente</option>
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideEditModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Salvar</button>
        </div>
      </form>
    </div>
  </div>
`,ze=()=>`
  <div id="delete-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideDeleteModal()"></div>
    <div class="bg-white w-full max-w-sm rounded-[2rem] p-6 relative z-10 shadow-2xl border border-slate-100">
      <div class="flex items-center gap-3 mb-4 text-rose-600">
        <div class="bg-rose-50 p-2.5 rounded-2xl">
          <i data-lucide="alert-triangle" class="w-6 h-6"></i>
        </div>
        <h3 class="text-lg font-black text-slate-800">Confirmar Exclusão</h3>
      </div>
      <p class="text-xs text-slate-500 mb-6 leading-relaxed">Você tem certeza de que deseja excluir este horário? Esta ação não poderá ser desfeita.</p>
      <input type="hidden" id="delete-schedule-id">
      <div class="flex gap-3">
        <button onclick="actions.hideDeleteModal()" class="flex-1 py-3 text-xs font-bold text-slate-600 border rounded-xl hover:bg-slate-50 transition-all">Cancelar</button>
        <button onclick="actions.confirmDeleteSchedule()" class="flex-1 py-3 text-xs font-bold text-white bg-rose-600 rounded-xl hover:bg-rose-700 shadow-lg shadow-rose-600/10 transition-all">Excluir</button>
      </div>
    </div>
  </div>
`,Je=()=>`
  <div id="lab-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideLabModal()"></div>
    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative z-10 shadow-2xl">
      <h3 class="text-2xl font-bold mb-8">Reservar Laboratório</h3>
      <form onsubmit="actions.createLabBooking(event)" class="space-y-4">
        <p class="text-sm text-slate-500">Confira as reservas da escola na agenda para escolher um horário disponível.</p>
        <label class="block">
          <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Laboratório</span>
          <select id="lab-type" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            <option value="info">Informática</option>
            <option value="chem">Química</option>
          </select>
        </label>
        <label class="block">
          <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Data</span>
          <input type="date" id="lab-date" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </label>
        <div class="grid grid-cols-2 gap-4">
          <label class="block">
            <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Início</span>
            <input type="time" id="lab-start" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
          <label class="block">
            <span class="mb-1.5 block text-xs font-bold uppercase text-slate-500">Término</span>
            <input type="time" id="lab-end" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
          </label>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideLabModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Reservar</button>
        </div>
      </form>
    </div>
  </div>
`,Qe=()=>`
  <div id="create-escola-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateEscolaModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Nova Escola</h3>
      <form onsubmit="actions.createSchool(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome da Escola</label>
          <input type="text" id="escola-name" placeholder="Ex: Colégio Estadual..." class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateEscolaModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,Re=({viewerRole:e="dev"}={})=>`
  <div id="create-user-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="actions.hideCreateUserModal()"></div>
    <div class="bg-white w-full max-w-md rounded-2xl p-8 relative z-10 shadow-2xl border border-slate-200">
      <h3 class="text-2xl font-bold mb-6">Criar Novo Usuário</h3>
      <form onsubmit="actions.createUser(event)" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Nome</label>
          <input type="text" id="user-displayname" placeholder="Ex: João Silva" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">E-mail</label>
          <input type="email" id="user-email" placeholder="Ex: joao@example.com" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Senha</label>
          <input type="password" id="user-password" placeholder="Mínimo 8 caracteres" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required minlength="8">
        </div>
        ${e==="dev"?`
          <div>
            <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Escola</label>
            <select id="user-school" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
              <option value="">Selecione uma escola</option>
              ${B.map(t=>`<option value="${t.id}">${t.name}</option>`).join("")}
            </select>
          </div>
        `:""}
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Matérias</label>
          <input type="text" id="user-subject" placeholder="Ex: Matemática, Física, Química" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900">
        </div>
        <div>
          <label class="text-xs font-bold text-slate-500 uppercase block mb-2">Cargo</label>
          <select id="user-role" class="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900" required>
            ${e==="dev"?`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
                <option value="dev">Desenvolvedor</option>
              `:`
                <option value="">Selecione um cargo</option>
                <option value="teacher">Professor</option>
                <option value="diretor">Diretor / Direção Pedagógica</option>
              `}
          </select>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" onclick="actions.hideCreateUserModal()" class="flex-1 py-2.5 border border-slate-200 rounded-lg font-bold hover:bg-slate-50 transition-all text-slate-700">Cancelar</button>
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all">Criar</button>
        </div>
      </form>
    </div>
  </div>
`,Ze=()=>{const e=!!(T!=null&&T.api.ok)&&!!(T!=null&&T.database.ok),t=k.length,s=N.length,a=q.length;return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Visão geral da plataforma</h3>
          <p class="text-sm text-slate-500 font-medium">Monitoramento da API, usuários e dados operacionais do site.</p>
        </div>
        <div class="inline-flex items-center gap-2 rounded-full ${e?"bg-emerald-50 text-emerald-700":"bg-amber-50 text-amber-700"} px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
          <i data-lucide="database" class="w-3.5 h-3.5"></i> ${e?"Supabase online":"Modo local"}
        </div>
      </div>

      <div class="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Status</p>
            <span class="w-2.5 h-2.5 rounded-full ${e?"bg-emerald-500":"bg-amber-400"}"></span>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${e?"OK":"Local"}</p>
          <p class="mt-2 text-sm text-slate-500">Conexão com a API express</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Usuários</p>
            <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${s}</p>
          <p class="mt-2 text-sm text-slate-500">Contas cadastradas</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Horários</p>
            <i data-lucide="calendar" class="w-4 h-4 text-violet-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${t}</p>
          <p class="mt-2 text-sm text-slate-500">Registros no banco</p>
        </div>
        <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
          <div class="flex items-center justify-between">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">Labs</p>
            <i data-lucide="beaker" class="w-4 h-4 text-emerald-600"></i>
          </div>
          <p class="mt-5 text-3xl font-black text-slate-900">${a}</p>
          <p class="mt-2 text-sm text-slate-500">Reservas registradas</p>
        </div>
      </div>

      <div class="grid xl:grid-cols-[1.1fr_0.9fr] gap-6">
        <div class="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
          <h4 class="text-lg font-black text-slate-900">Infraestrutura do projeto</h4>
          <div class="mt-5 space-y-4">
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Banco de dados</span>
              <span class="text-sm font-black text-slate-900">Supabase Postgres</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">Autenticação</span>
              <span class="text-sm font-black text-slate-900">Auth + RLS</span>
            </div>
            <div class="flex justify-between items-center border-b border-slate-100 pb-3">
              <span class="text-sm font-semibold text-slate-500">API</span>
              <span class="text-sm font-black text-slate-900">Express + Vite</span>
            </div>
          </div>
        </div>

        <div class="bg-slate-900 rounded-3xl p-6 shadow-lg text-white">
          <div class="flex items-center justify-between">
            <h4 class="text-lg font-black">Environment</h4>
            <span class="inline-flex items-center gap-2 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-200">
              <i data-lucide="shield-check" class="w-3.5 h-3.5"></i> Seguro
            </span>
          </div>
          <div class="mt-5 space-y-4 text-sm text-slate-300">
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">API base</p>
              <p class="mt-1 font-semibold break-all">${L||"http://localhost:3000"}</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Proteção</p>
              <p class="mt-1 font-semibold">Service role no backend apenas</p>
            </div>
            <div class="rounded-2xl bg-white/5 p-3">
              <p class="text-[10px] uppercase tracking-[0.18em] text-slate-400">Armazenamento</p>
              <p class="mt-1 font-semibold">Usuários, horários, laboratórios e certificados</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `},z=e=>String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),ee=()=>`
  <button onclick="actions.refreshDeveloperPanel()" class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800">
    <i data-lucide="refresh-cw" class="h-4 w-4"></i> Atualizar
  </button>
`,te=e=>J[e]?`
  <div class="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">${z(J[e])}</div>
`:"",Ke=()=>{const e=T,t=e==null?void 0:e.api.ok,s=e==null?void 0:e.database.ok;return`
    <div class="space-y-6">
      <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Saúde do sistema</h3>
          <p class="mt-1 text-sm font-medium text-slate-500">Estado atual da API e conexão com o banco de dados.</p>
        </div>
        ${ee()}
      </header>
      ${te("diagnostics")}
      <div class="grid gap-4 md:grid-cols-3">
        ${[{title:"API",ok:t,detail:t===void 0?"Aguardando verificação":t?"Respondendo normalmente":"Indisponível"},{title:"Banco de dados",ok:s,detail:s===void 0?"Aguardando verificação":s?`${e.database.latencyMs} ms de resposta`:"Falha ao consultar o banco"},{title:"Tempo ativo",ok:t,detail:e?`${Math.floor(e.uptimeSeconds/60)} min`:"Aguardando verificação"}].map(a=>`
          <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
              <h4 class="font-black text-slate-800">${a.title}</h4>
              <span class="rounded-full px-3 py-1 text-xs font-black ${a.ok===void 0?"bg-slate-100 text-slate-500":a.ok?"bg-emerald-100 text-emerald-700":"bg-rose-100 text-rose-700"}">${a.ok===void 0?"PENDENTE":a.ok?"OK":"FALHA"}</span>
            </div>
            <p class="mt-4 text-sm font-semibold text-slate-500">${a.detail}</p>
          </article>
        `).join("")}
      </div>
      ${e?`<p class="text-xs font-medium text-slate-400">Verificado em ${new Date(e.checkedAt).toLocaleString("pt-BR")}.</p>`:""}
    </div>
  `},Ye=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Diagnóstico</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Testes de leitura nas tabelas e verificações básicas de integridade.</p>
      </div>
      ${ee()}
    </header>
    ${te("diagnostics")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <h4 class="border-b border-slate-100 p-5 font-black text-slate-800">Conexão e latência por tabela</h4>
      ${T?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[560px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Tabela</th><th class="px-5 py-3">Status</th><th class="px-5 py-3">Registros</th><th class="px-5 py-3">Resposta</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${T.probes.map(e=>`
                <tr>
                  <td class="px-5 py-3 font-semibold text-slate-700">${z(e.table)}</td>
                  <td class="px-5 py-3 font-bold ${e.ok?"text-emerald-700":"text-rose-700"}">${e.ok?"OK":"Falha"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.records??"—"}</td>
                  <td class="px-5 py-3 text-slate-600">${e.latencyMs} ms</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Atualize para executar os testes.</p>'}
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Integridade básica</h4>
      <div class="mt-4 grid gap-3 md:grid-cols-2">
        ${((T==null?void 0:T.integrity)||[]).map(e=>`
          <div class="flex items-center justify-between gap-4 rounded-xl bg-slate-50 p-4">
            <span class="text-sm font-semibold text-slate-600">${z(e.name)}</span>
            <span class="text-sm font-black ${e.ok&&e.count===0?"text-emerald-700":"text-amber-700"}">${e.ok?e.count:"Erro na consulta"}</span>
          </div>
        `).join("")}
        ${T?"":'<p class="text-sm text-slate-500">Os resultados aparecerão após a verificação.</p>'}
      </div>
    </section>
  </div>
`,Xe=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Logs de erros</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimos 100 erros HTTP 5xx registrados pela API. O conteúdo dos pedidos não é armazenado.</p>
      </div>
      ${ee()}
    </header>
    ${te("logs")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${pe.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[620px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Método</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Código</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${pe.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-bold text-slate-700">${z(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.route)}</td><td class="px-5 py-3 font-black text-rose-700">${z(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhum erro registrado ou ainda não há logs disponíveis.</p>'}
    </section>
  </div>
`,et=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Auditoria</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Últimas 100 alterações concluídas, com usuário, rota e horário.</p>
      </div>
      ${ee()}
    </header>
    ${te("audit")}
    <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      ${ue.length?`
        <div class="overflow-x-auto">
          <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="bg-slate-50 text-xs uppercase text-slate-400"><tr><th class="px-5 py-3">Data</th><th class="px-5 py-3">Usuário</th><th class="px-5 py-3">Ação</th><th class="px-5 py-3">Rota</th><th class="px-5 py-3">Resultado</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
              ${ue.map(e=>`
                <tr><td class="px-5 py-3 text-slate-600">${new Date(e.created_at).toLocaleString("pt-BR")}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.actor_uid)} <span class="font-sans">(${z(e.actor_role)})</span></td><td class="px-5 py-3 font-bold text-slate-700">${z(e.method)}</td><td class="px-5 py-3 font-mono text-xs text-slate-600">${z(e.route)}</td><td class="px-5 py-3 font-semibold text-emerald-700">${z(e.status_code)}</td></tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `:'<p class="p-5 text-sm font-medium text-slate-500">Nenhuma alteração registrada ou ainda não há eventos disponíveis.</p>'}
    </section>
  </div>
`,tt=()=>`
  <div class="space-y-6">
    <header class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 class="text-2xl font-black text-slate-900">Dados e backups</h3>
        <p class="mt-1 text-sm font-medium text-slate-500">Consulte volumes e exporte dados selecionados da plataforma.</p>
      </div>
      ${ee()}
    </header>
    ${te("diagnostics")}
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Registros por tabela</h4>
      <div class="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        ${((T==null?void 0:T.probes)||[]).map(e=>`
          <div class="rounded-xl bg-slate-50 p-4">
            <p class="text-xs font-bold uppercase text-slate-400">${z(e.table)}</p>
            <p class="mt-2 text-2xl font-black text-slate-800">${e.ok?e.records:"Consulta falhou"}</p>
          </div>
        `).join("")}
        ${T?"":'<p class="text-sm text-slate-500">Atualize para consultar as tabelas.</p>'}
      </div>
    </section>
    <section class="rounded-2xl border border-amber-200 bg-amber-50 p-5">
      <h4 class="font-black text-amber-900">Exportação CSV</h4>
      <p class="mt-1 text-sm text-amber-800">Os arquivos podem conter dados pessoais. Escolha uma tabela e confirme antes de baixar; cada exportação tem limite de 5.000 registros.</p>
      <div class="mt-4 flex flex-col gap-3 sm:flex-row">
        <select id="dev-export-resource" class="rounded-xl border border-amber-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700">
          <option value="users">Usuários</option>
          <option value="schools">Escolas</option>
          <option value="schedules">Horários</option>
          <option value="lab_bookings">Reservas de laboratório</option>
          <option value="school_subjects">Matérias da escola</option>
          <option value="teacher_subjects">Vínculos de matérias</option>
        </select>
        <button onclick="actions.exportDeveloperData()" class="rounded-xl bg-amber-700 px-5 py-2.5 text-sm font-bold text-white hover:bg-amber-800">Exportar CSV</button>
      </div>
    </section>
    <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h4 class="font-black text-slate-800">Backup e restauração</h4>
      <p class="mt-2 text-sm leading-6 text-slate-600">Backups completos devem ser criados e restaurados pelo painel do Supabase, que controla a retenção e os snapshots do projeto. Antes de uma alteração estrutural, confira o backup mais recente e teste a restauração em um ambiente separado.</p>
      <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" class="mt-4 inline-flex items-center gap-2 font-bold text-blue-700 hover:text-blue-800">Abrir painel do Supabase <i data-lucide="external-link" class="h-4 w-4"></i></a>
    </section>
  </div>
`,st=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-white/10 text-white font-bold":"text-slate-400 hover:bg-white/5 hover:text-white"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,at=(e,t,s)=>`
  <button onclick="actions.switchTab('${e}')"
    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===e?"bg-blue-50 text-blue-700 font-bold border-l-2 border-blue-600":"text-slate-500 hover:bg-slate-50 hover:text-slate-800"}">
    <i data-lucide="${t}"></i> ${s}
  </button>
`,$e=({theme:e="light",sectionLabel:t,navItems:s,profile:a})=>{const o=e==="dark",r=o?st:at;return`
    <aside class="w-64 border-r ${o?"bg-slate-900 border-slate-800 text-slate-300":"bg-white border-slate-200 text-slate-500"} hidden md:flex flex-col p-6 print:hidden shrink-0">
      <div class="flex items-center mb-10 px-2 shrink-0">${le(170,46)}</div>
      <p class="text-[10px] font-bold ${o?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-4">${t}</p>
      <nav class="space-y-1 flex-1">
        ${s.map(l=>r(l.id,l.icon,l.label)).join("")}
      </nav>
      ${a?`
      <div class="mt-auto pt-6 border-t ${o?"border-slate-800":"border-slate-200"} mb-6 px-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-full ${o?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
            ${a.initials}
          </div>
          <div class="overflow-hidden">
            <p class="${o?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
            <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
          </div>
        </div>
      </div>
      `:""}
      <button onclick="actions.logout()" class="flex items-center gap-3 px-4 py-3 rounded-xl ${o?"hover:bg-slate-800 text-slate-300":"hover:bg-slate-50 text-slate-500 hover:text-slate-900"} transition-all font-semibold">
        <i data-lucide="log-out"></i> Sair
      </button>
    </aside>
  `},ke=({theme:e="light",sectionLabel:t,navItems:s,profile:a,drawerId:o})=>{if(!be)return"";const r=e==="dark";return`
    <div class="fixed inset-0 z-50 flex md:hidden" id="${o}">
      <div class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm shadow-sm" onclick="actions.toggleMobileMenu(false)"></div>
      <div class="relative flex flex-col w-72 max-w-[80vw] h-full ${r?"bg-slate-900 text-slate-300":"bg-white"} p-6 shadow-2xl transition-all duration-300 ease-in-out">
        <div class="flex items-center justify-between mb-8 px-2">
          <div class="flex items-center">${le(140,38)}</div>
          <button onclick="actions.toggleMobileMenu(false)" class="p-2 -mr-2 rounded-lg ${r?"text-slate-400 hover:text-white hover:bg-white/5":"text-slate-400 hover:text-slate-600 hover:bg-slate-50"}">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <p class="text-[10px] font-black ${r?"text-slate-500":"text-slate-400"} uppercase tracking-widest mb-4 px-2">${t}</p>
        <nav class="space-y-1.5 flex-1">
          ${s.map(l=>`
            <button onclick="actions.switchTabMobile('${l.id}')" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-semibold ${v===l.id?r?"bg-white/10 text-white font-bold":"bg-blue-50 text-blue-700 font-bold":r?"text-slate-400 hover:bg-white/5 hover:text-white":"text-slate-500 hover:bg-slate-50"}">
              <i data-lucide="${l.icon}"></i> ${l.label}
            </button>
          `).join("")}
        </nav>

        <div class="mt-auto pt-6 border-t ${r?"border-slate-800":"border-slate-200"} px-2 flex flex-col gap-4">
          ${a?`
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full ${r?"bg-white/10 text-white":"bg-slate-100 border border-slate-200 text-slate-600"} shadow-sm flex items-center justify-center font-bold uppercase shrink-0">
              ${a.initials}
            </div>
            <div class="overflow-hidden">
              <p class="${r?"text-white":"text-slate-800"} text-sm font-semibold truncate">${a.name}</p>
              <p class="text-[10px] text-slate-400 font-medium">${a.subtitle}</p>
            </div>
          </div>
          `:""}
          <button onclick="actions.logout()" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-rose-50 text-rose-600 transition-all font-semibold justify-center border border-rose-100 bg-rose-50/30">
            <i data-lucide="log-out"></i> Sair
          </button>
        </div>
      </div>
    </div>
  `},Ce=[{id:"overview",icon:"activity",label:"Visão geral"},{id:"dev_health",icon:"activity",label:"Saúde do sistema"},{id:"dev_diagnostics",icon:"search",label:"Diagnóstico"},{id:"dev_logs",icon:"file-text",label:"Logs de erros"},{id:"dev_audit",icon:"clipboard",label:"Auditoria"},{id:"dev_data",icon:"database",label:"Dados e backups"},{id:"escolas",icon:"building",label:"Escolas"},{id:"usuarios",icon:"users",label:"Usuários"}],je=[{id:"horarios",icon:"calendar",label:"Horários"},{id:"labs",icon:"test-tube",label:"Laboratórios"},{id:"usuarios",icon:"users",label:"Usuários"},{id:"relatorios",icon:"bar-chart",label:"Relatórios"}],ot=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${$e({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ce})}
    ${ke({theme:"dark",sectionLabel:"Desenvolvedor",navItems:Ce,drawerId:"dev-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-dev-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Área do desenvolvedor</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <span class="hidden md:inline-flex items-center gap-2 rounded-full bg-slate-900 text-white px-3 py-1.5 text-xs font-black uppercase tracking-[0.14em]"><i data-lucide="code-2" class="w-3.5 h-3.5"></i> Desenvolvedor</span>
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="overview"?Ze():""}
        ${v==="dev_health"?Ke():""}
        ${v==="dev_diagnostics"?Ye():""}
        ${v==="dev_logs"?Xe():""}
        ${v==="dev_audit"?et():""}
        ${v==="dev_data"?tt():""}
        ${v==="escolas"?it():""}
        ${v==="usuarios"?Be({viewerRole:"dev"}):""}
      </div>
    </main>

    ${Ae()}
    ${Pe()}
    ${ze()}
    ${Qe()}
    ${Re({viewerRole:"dev"})}
  </div>
`,rt=()=>`
  <div class="flex h-screen overflow-hidden print:overflow-visible flex-col md:flex-row">
    ${$e({theme:"light",sectionLabel:"Direção Pedagógica",navItems:je})}
    ${ke({theme:"light",sectionLabel:"Direção Pedagógica",navItems:je,drawerId:"diretor-mobile-sidebar-drawer"})}

    <main class="flex-1 flex flex-col bg-slate-50 overflow-hidden print:bg-white print:overflow-visible">
      <header class="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0 print:hidden">
        <div class="flex items-center gap-3">
          <button onclick="actions.toggleMobileMenu(true)" class="md:hidden p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-lg" id="btn-diretor-toggle-menu">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <div class="min-w-0">
            <p class="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 truncate">Direção Pedagógica</p>
            <h2 class="font-black text-base md:text-lg text-slate-900 truncate">Console Studia</h2>
          </div>
        </div>
        <div class="flex gap-2">
          ${v==="horarios"?`
            <button onclick="actions.showCreateModal()" class="bg-blue-600 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-blue-700 transition-all" id="btn-diretor-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Novo Horário</span>
            </button>
          `:""}
          ${v==="labs"?`
            <button onclick="actions.showLabModal()" class="bg-slate-900 text-white px-3 md:px-6 py-2 md:py-2.5 rounded-lg font-bold shadow-md flex items-center gap-1.5 md:gap-2 text-xs md:text-sm hover:bg-slate-800 transition-all" id="btn-diretor-lab-new">
              <i data-lucide="plus" class="w-4 h-4 md:w-5 md:h-5"></i> <span>Reservar Lab</span>
            </button>
          `:""}
        </div>
      </header>

      <div class="p-4 md:p-10 flex-1 overflow-y-auto space-y-6 md:space-y-8 print:p-0">
        ${v==="horarios"?nt():""}
        ${v==="labs"?_e():""}
        ${v==="usuarios"?Be({viewerRole:"diretor"}):""}
        ${v==="relatorios"?ct():""}
      </div>
    </main>

    ${Ae()}
    ${Pe()}
    ${ze()}
    ${Re({viewerRole:"diretor"})}
  </div>
`,V={dev:{badge:"bg-emerald-100 text-emerald-700",label:"Desenvolvedor"},diretor:{badge:"bg-amber-100 text-amber-700",label:"Diretor / Direção Pedagógica"},teacher:{badge:"bg-blue-100 text-blue-700",label:"Professor"}},lt=({viewerRole:e})=>{var o,r;const t=e==="dev",s=e==="diretor"?i==null?void 0:i.school_id:K||(i==null?void 0:i.school_id)||((o=B[0])==null?void 0:o.id)||"",a=H.filter(l=>l.school_id===s);return`
    <section class="space-y-5 rounded-3xl border border-slate-200 bg-white p-5 md:p-7 shadow-sm">
      <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h4 class="text-xl font-black text-slate-900">Matérias da escola</h4>
          <p class="mt-1 text-sm font-medium text-slate-500">Gerencie o catálogo de matérias desta escola.</p>
        </div>
        ${t?`
          <select onchange="actions.selectSubjectSchool(this.value)" class="w-full md:w-72 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-semibold text-slate-700" aria-label="Escola do catálogo de matérias">
            <option value="">Selecione uma escola</option>
            ${B.map(l=>`<option value="${l.id}" ${l.id===s?"selected":""}>${l.name}</option>`).join("")}
          </select>
        `:`<span class="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-black uppercase text-blue-700">${((r=B.find(l=>l.id===s))==null?void 0:r.name)||"Minha escola"}</span>`}
      </div>

      <form onsubmit="actions.createSchoolSubject(event)" class="flex flex-col gap-3 sm:flex-row">
        <input id="school-subject-name" type="text" maxlength="255" placeholder="Adicionar matéria ao checklist" class="min-w-0 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-800" required ${s?"":"disabled"}>
        <button type="submit" class="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50" ${s?"":"disabled"}>Adicionar matéria</button>
      </form>

      ${s?a.length===0?`
        <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-500">O checklist está vazio. Adicione as matérias usadas nesta escola.</p>
      `:`
        <div class="space-y-3">
          ${a.map(l=>`
            <div class="rounded-2xl border border-slate-200 p-4">
              <div class="flex items-center justify-between gap-3">
                <h5 class="font-black text-slate-800">${l.subject}</h5>
                <button type="button" onclick="actions.deleteSchoolSubject('${l.id}', '${l.subject.replace(/'/g,"\\'")}')" class="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="Excluir matéria ${l.subject}" title="Excluir matéria">
                  <i data-lucide="trash-2" class="h-4 w-4"></i>
                </button>
              </div>
            </div>
          `).join("")}
        </div>
      `:`
        <p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Cadastre uma escola para gerenciar o catálogo de matérias.</p>
      `}
    </section>
  `},Be=({viewerRole:e="diretor"}={})=>{const t=e==="dev",s=[...N].filter(n=>t||n.role!=="dev").sort((n,m)=>(n.displayName||"").localeCompare(m.displayName||"")),a=s.find(n=>n.uid===oe&&n.role==="teacher"),o=a?H.filter(n=>n.school_id===a.school_id):[],r=s.filter(n=>n.uid!==(i==null?void 0:i.uid)).map(n=>n.uid),l=r.filter(n=>G.has(n)).length,d=r.length>0&&l===r.length,c=t?["teacher","diretor","dev"]:["teacher","diretor"];return`
    <div class="space-y-6">
      <div class="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Gestão de usuários</h3>
          <p class="text-sm text-slate-500 font-medium">${t?"Todas as contas cadastradas no sistema.":"Direção pedagógica e professores cadastrados na sua escola."}</p>
        </div>
        <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          ${t||e==="diretor"?`
            <button onclick="actions.showCreateUserModal('${e}')" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
              <i data-lucide="plus" class="w-4 h-4"></i> Criar Usuário
            </button>
          `:""}
          <div class="inline-flex items-center gap-2 rounded-full bg-blue-50 text-blue-700 px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em]">
            <i data-lucide="users" class="w-3.5 h-3.5"></i> ${s.length} usuários
          </div>
        </div>
      </div>

      ${l>0?`
        <div class="flex flex-col gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p class="text-sm font-bold text-rose-800">${l} conta${l===1?"":"s"} selecionada${l===1?"":"s"} para exclusão.</p>
          <button type="button" onclick="actions.deleteSelectedUsers()" class="inline-flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-xs font-black text-white hover:bg-rose-700">
            <i data-lucide="trash-2" class="h-4 w-4"></i> Excluir selecionados
          </button>
        </div>
      `:""}

      ${["dev","diretor"].includes(e)?lt({viewerRole:e}):""}

      <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full min-w-[820px] text-left">
            <thead class="bg-slate-50 text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 border-b border-slate-200">
              <tr>
                <th class="w-12 px-4 py-4">
                  <input type="checkbox" aria-label="Selecionar todos os usuários" ${d?"checked":""} ${r.length?"":"disabled"} onchange="actions.toggleAllUsers(this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                </th>
                <th class="px-6 py-4">Nome</th>
                <th class="px-6 py-4">E-mail</th>
                <th class="px-6 py-4">Perfil</th>
                <th class="px-6 py-4">Matéria</th>
                <th class="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${s.length===0?`
                <tr>
                  <td colspan="6" class="px-6 py-10 text-center text-sm text-slate-500 font-medium">Nenhum usuário encontrado.</td>
                </tr>
              `:s.map(n=>`
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="px-4 py-6">
                    <input type="checkbox" aria-label="Selecionar ${n.email||n.displayName||"usuário"}" ${G.has(n.uid)?"checked":""} ${n.uid===(i==null?void 0:i.uid)?"disabled":""} onchange="actions.toggleUserSelection('${n.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500 disabled:opacity-40">
                  </td>
                  <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 rounded-full bg-slate-100 text-slate-700 font-black flex items-center justify-center uppercase">
                        ${(n.displayName||"U").slice(0,2)}
                      </div>
                      <div>
                        <div class="font-bold text-slate-900">${n.displayName||"Usuário sem nome"}</div>
                        <div class="text-[10px] uppercase tracking-[0.18em] text-slate-400">${n.uid===(i==null?void 0:i.uid)?"Você":"Conta ativa"}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">${n.email||"—"}</td>
                  <td class="px-6 py-4">
                    ${n.uid===(i==null?void 0:i.uid)?`
                      <span class="inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(V[n.role]||V.teacher).badge}">
                        ${(V[n.role]||V.teacher).label}
                      </span>
                    `:`
                      <select
                        onchange="actions.changeUserRole('${n.uid}', this.value)"
                        class="rounded-full border border-slate-200 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${(V[n.role]||V.teacher).badge} cursor-pointer"
                      >
                        ${c.map(m=>`<option value="${m}" ${n.role===m?"selected":""}>${V[m].label}</option>`).join("")}
                      </select>
                    `}
                  </td>
                  <td class="px-6 py-4 text-sm text-slate-600 font-medium">
                    ${n.role==="teacher"?`
                      <div class="flex min-w-40 flex-col items-start gap-2">
                        <span>${H.filter(m=>m.school_id===n.school_id&&(m.teacherIds||[]).includes(n.uid)).map(m=>m.subject).join(", ")||"—"}</span>
                        <button type="button" onclick="actions.toggleTeacherSubjectsEditor('${n.uid}')" class="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-2.5 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-50">
                          <i data-lucide="pencil" class="h-3.5 w-3.5"></i> Editar matérias
                        </button>
                      </div>
                    `:"—"}
                  </td>
                  <td class="px-6 py-4 text-right">
                    <button
                      onclick="actions.deleteUser('${n.uid}', '${(n.displayName||"Usuário").replace(/'/g,"\\'")}', '${n.email||"usuário"}')"
                      class="inline-flex items-center gap-2 rounded-xl border ${n.uid===(i==null?void 0:i.uid)?"border-slate-200 text-slate-400 cursor-not-allowed":"border-rose-200 text-rose-600 hover:bg-rose-50"} px-3 py-2 text-xs font-bold disabled:opacity-60"
                      ${n.uid===(i==null?void 0:i.uid)?"disabled":""}
                    >
                      <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                      ${n.uid===(i==null?void 0:i.uid)?"Você":"Excluir"}
                    </button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
      ${a?`
        <div class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 p-4" role="presentation">
          <section class="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl" role="dialog" aria-modal="true" aria-labelledby="teacher-subjects-title">
            <header class="flex items-start justify-between gap-4 border-b border-slate-200 p-5">
              <div>
                <h4 id="teacher-subjects-title" class="text-lg font-black text-slate-900">Matérias de ${a.displayName||a.email}</h4>
                <p class="mt-1 text-sm font-medium text-slate-500">Marque ou desmarque as matérias deste professor.</p>
              </div>
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Fechar edição de matérias">
                <i data-lucide="x" class="h-5 w-5"></i>
              </button>
            </header>
            <div class="max-h-[60vh] space-y-2 overflow-y-auto p-5">
              ${a.school_id?o.length?o.map(n=>`
                  <label class="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    <input type="checkbox" ${(n.teacherIds||[]).includes(a.uid)?"checked":""} onchange="actions.setTeacherSubject('${n.id}', '${a.uid}', this.checked)" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${n.subject}
                  </label>
                `).join(""):`
                <p class="rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-600">Não há matérias cadastradas para a escola deste professor.</p>
              `:`
                ${t?`
                  <div class="space-y-3 rounded-xl bg-amber-50 p-4">
                    <p class="text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Selecione a escola para continuar.</p>
                    <select id="teacher-school-${a.uid}" class="w-full rounded-lg border border-amber-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700">
                      <option value="">Selecione uma escola</option>
                      ${B.map(n=>`<option value="${n.id}">${n.name}</option>`).join("")}
                    </select>
                    <button type="button" onclick="actions.assignTeacherSchool('${a.uid}')" class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700">Associar escola</button>
                  </div>
                `:'<p class="rounded-xl bg-amber-50 p-4 text-sm font-semibold text-amber-800">Este professor ainda não está associado a uma escola. Peça à direção pedagógica para vinculá-lo.</p>'}
              `}
            </div>
            <footer class="flex justify-end border-t border-slate-200 p-4">
              <button type="button" onclick="actions.closeTeacherSubjectsEditor()" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-bold text-white hover:bg-slate-800">Concluir</button>
            </footer>
          </section>
        </div>
      `:""}
    </div>
  `},it=()=>`
  <div class="space-y-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Gerenciar Escolas</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Crie escolas e associe diretores</p>
      </div>
      <button onclick="actions.showCreateEscolaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Nova Escola
      </button>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="overflow-x-auto pr-2">
        <table class="w-full text-left min-w-[500px]">
          <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
            <tr>
              <th class="px-8 py-5">Nome da Escola</th>
              <th class="px-8 py-5">Criado por</th>
              <th class="px-8 py-5">Data</th>
              <th class="px-8 py-5">Ações</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-50">
            ${B&&B.length>0?B.map(e=>{var t;return`
              <tr class="hover:bg-slate-50 transition-all">
                <td class="px-8 py-5 font-bold">${e.name}</td>
                <td class="px-8 py-5 text-sm">
                  ${((t=N.find(s=>s.uid===e.createdBy))==null?void 0:t.displayName)||"—"}
                </td>
                <td class="px-8 py-5 text-sm text-slate-500">
                  ${new Date(e.createdAt).toLocaleDateString("pt-BR")}
                </td>
                <td class="px-8 py-5 text-right">
                  <button onclick="actions.deleteSchool('${e.id}')" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer" title="Deletar">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                  </button>
                </td>
              </tr>
            `}).join(""):'<tr><td colspan="4" class="px-8 py-8 text-center text-slate-400 text-sm">Nenhuma escola criada ainda</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </div>
`,nt=()=>`
  <h3 class="text-2xl font-black text-slate-900 print:mb-4">Grade de Horários</h3>
  <div class="bg-white rounded-3xl border overflow-hidden shadow-sm print:border-none print:shadow-none">
    <div class="overflow-x-auto pr-2">
      <table class="w-full text-left min-w-[700px]">
      <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase border-b">
        <tr>
          <th class="px-8 py-5">Matéria</th>
          <th class="px-8 py-5">Horário / Data</th>
          <th class="px-8 py-5">Professor</th>
          <th class="px-8 py-5 text-center">Status</th>
          <th class="px-8 py-5 print:hidden"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-50">
        ${k.map(e=>`
          <tr class="hover:bg-slate-50 transition-all">
            <td class="px-8 py-5 font-bold">${e.subject}</td>
            <td class="px-8 py-5">
              <div class="text-sm font-bold">${e.startTime}</div>
              <div class="text-[10px] text-slate-400 uppercase font-bold">${e.date}</div>
            </td>
            <td class="px-8 py-5 text-sm">
              <span class="font-bold text-slate-800">${e.teacherName}</span>
              ${e.classGroup?`<span class="block text-xs font-semibold text-blue-600 mt-0.5">${e.classGroup}</span>`:""}
            </td>
            <td class="px-8 py-5">
              <div class="flex justify-center">
                <span class="text-[10px] font-black uppercase px-3 py-1 rounded-full ${e.status==="confirmed"?"bg-blue-100 text-blue-700":e.status==="absent"?"bg-rose-100 text-rose-700":"bg-slate-100 text-slate-500"}">${e.status==="confirmed"?"Confirmado":e.status==="absent"?"Ausente":"Pendente"}</span>
              </div>
            </td>
            <td class="px-8 py-5 text-right print:hidden">
              <div class="flex items-center justify-end gap-3">
                <button onclick="actions.showEditModalById(${e.id})" class="text-slate-300 hover:text-blue-600 transition-all cursor-pointer" title="Editar">
                  <i data-lucide="pencil" class="w-4 h-4"></i>
                </button>
                <button onclick="actions.showDeleteModal(${e.id})" class="text-slate-300 hover:text-rose-500 transition-all cursor-pointer" title="Excluir">
                  <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
              </div>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
   </div>
  </div>
`,dt=()=>`
  <div class="space-y-8 animate-fade-in">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h3 class="text-xl md:text-2xl font-black text-slate-900">Minhas Matérias</h3>
        <p class="text-xs md:text-sm text-slate-500 font-bold">Gerencie as matérias que você leciona.</p>
      </div>
      <button onclick="actions.showAddMatériaModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
        <i data-lucide="plus" class="w-4 h-4"></i> Adicionar Matéria
      </button>
    </div>

    <div class="space-y-5">
      <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h4 class="text-sm font-black uppercase tracking-[0.18em] text-slate-400 mb-4">Editar minhas matérias</h4>
        ${(()=>{const e=(H||[]).filter(s=>s.school_id===(i==null?void 0:i.school_id)),t=new Set((window.teacherSubjects||[]).map(s=>s.subject));return e.length?`
            <div class="flex flex-wrap gap-2">
              ${e.map(s=>{const a=t.has(s.subject);return`
                  <label class="inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-bold ${a?"border-blue-200 bg-blue-50 text-blue-800":"border-slate-200 bg-slate-50 text-slate-600"}">
                    <input type="checkbox" ${a?"checked":""} onchange="actions.setTeacherSubject('${s.id}', '${i.uid}', this.checked)" class="rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                    ${s.subject}
                  </label>
                `}).join("")}
            </div>
          `:'<p class="text-sm font-medium text-slate-500">Ainda não há matérias cadastradas para a sua escola.</p>'})()}
      </div>

      <div class="grid gap-4">
        ${(()=>{const e=window.teacherSubjects||[];return e.length===0?`
              <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
                <i data-lucide="book" class="w-12 h-12 text-slate-300 mx-auto mb-4"></i>
                <p class="text-slate-400 font-bold">Você ainda não adicionou nenhuma matéria.</p>
              </div>
            `:e.map(t=>`
            <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center justify-between hover:shadow-md transition-all">
              <div class="flex items-center gap-4">
                <div class="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center">
                  <i data-lucide="book-open" class="w-6 h-6 text-blue-600"></i>
                </div>
                <div>
                  <h4 class="font-bold text-slate-900">${t.subject}</h4>
                  <p class="text-xs text-slate-400">Matéria</p>
                </div>
              </div>
              <button onclick="actions.deleteMatéria('${t.subject}')" class="text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition-all">
                <i data-lucide="trash-2" class="w-5 h-5"></i>
              </button>
            </div>
          `).join("")})()}
      </div>
    </div>
  </div>
`,_e=()=>{const e=[...q].sort((l,d)=>l.date.localeCompare(d.date)||l.startTime.localeCompare(d.startTime)),t=e.filter(l=>(!P.date||l.date===P.date)&&(P.labId==="all"||l.labId===P.labId)&&l.teacherName.toLocaleLowerCase().includes(P.teacher.toLocaleLowerCase())),s=new Date,a=`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}-${String(s.getDate()).padStart(2,"0")}`,o=l=>{const[d,c,n]=l.split("-");return`${n}/${c}/${d}`},r=e.filter(l=>l.date>=a);return`
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 class="text-xl md:text-2xl font-black text-slate-900">Agenda dos Laboratórios</h3>
          <p class="text-xs md:text-sm text-slate-500 font-medium">Consulte as reservas da escola, filtre a agenda e escolha um horário livre.</p>
        </div>
        <button onclick="actions.showLabModal()" class="bg-blue-600 hover:bg-blue-700 transition-all text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm shadow-md">
          <i data-lucide="plus" class="w-4 h-4"></i> Nova reserva
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        ${["info","chem"].map(l=>{const d=r.filter(c=>c.labId===l).slice(0,3);return`
            <section class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <h4 class="font-black text-slate-800 flex items-center gap-2">
                <i data-lucide="${l==="info"?"monitor":"beaker"}" class="w-5 h-5 text-blue-600"></i>
                ${l==="info"?"Informática":"Química"}
              </h4>
              <div class="mt-4 space-y-2">
                ${d.map(c=>`
                  <div class="flex justify-between gap-3 rounded-xl bg-slate-50 p-3">
                    <span class="min-w-0 truncate text-sm font-semibold text-slate-700">${c.teacherName}</span>
                    <span class="shrink-0 text-xs font-bold text-slate-500">${o(c.date)} · ${c.startTime.slice(0,5)}–${c.endTime.slice(0,5)}</span>
                  </div>
                `).join("")||'<p class="py-3 text-sm text-slate-400">Sem reservas futuras.</p>'}
              </div>
            </section>
          `}).join("")}
      </div>

      <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 p-5">
          <div class="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h4 class="font-black text-slate-900">Reservas da escola</h4>
              <p class="text-sm text-slate-500">${t.length} de ${q.length} reservas</p>
            </div>
            <div class="grid grid-cols-1 gap-3 pt-3 sm:grid-cols-3 sm:pt-0">
              <label class="text-xs font-bold text-slate-500">
                Data
                <input type="date" value="${P.date}" onchange="actions.setLabFilter('date', this.value)" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              </label>
              <label class="text-xs font-bold text-slate-500">
                Laboratório
                <select onchange="actions.setLabFilter('labId', this.value)" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
                  <option value="all" ${P.labId==="all"?"selected":""}>Todos</option>
                  <option value="info" ${P.labId==="info"?"selected":""}>Informática</option>
                  <option value="chem" ${P.labId==="chem"?"selected":""}>Química</option>
                </select>
              </label>
              <label class="text-xs font-bold text-slate-500">
                Professor
                <input type="search" value="${P.teacher}" onchange="actions.setLabFilter('teacher', this.value)" placeholder="Buscar nome" class="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              </label>
            </div>
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full min-w-[650px] text-left">
            <thead class="bg-slate-50 text-[10px] font-black uppercase text-slate-400">
              <tr>
                <th class="px-5 py-4">Data</th>
                <th class="px-5 py-4">Horário</th>
                <th class="px-5 py-4">Laboratório</th>
                <th class="px-5 py-4">Responsável</th>
                <th class="px-5 py-4 text-center">Ação</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${t.map(l=>`
                <tr class="hover:bg-slate-50">
                  <td class="px-5 py-4 font-semibold text-slate-700">${o(l.date)}</td>
                  <td class="px-5 py-4 font-mono text-sm text-slate-600">${l.startTime.slice(0,5)}–${l.endTime.slice(0,5)}</td>
                  <td class="px-5 py-4 text-sm font-semibold text-slate-700">${l.labId==="info"?"Informática":"Química"}</td>
                  <td class="px-5 py-4 text-sm font-semibold text-slate-700">${l.teacherName}</td>
                  <td class="px-5 py-4 text-center">
                    ${i.role==="diretor"||l.teacherId===i.uid?`
                      <button onclick="actions.deleteLabBooking(${l.id})" class="inline-flex items-center text-slate-400 hover:text-rose-600" title="Cancelar reserva" aria-label="Cancelar reserva">
                        <i data-lucide="trash-2" class="h-4 w-4"></i>
                      </button>
                    `:'<span class="text-slate-300">-</span>'}
                  </td>
                </tr>
              `).join("")||`
                <tr><td colspan="5" class="px-5 py-10 text-center text-sm font-medium text-slate-400">
                  ${q.length?"Nenhuma reserva corresponde aos filtros.":"Ainda não há reservas para esta escola."}
                </td></tr>
              `}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `},ct=()=>{console.log("[DEBUG RELATÓRIO]",{reportTurno:$,reportWeek:D,schedulesCount:k.length,teachersCount:R.length});const e=Ue(),t=ve();let s=[];$==="matutino"?s=["07:30","08:20","09:10","10:15","11:00","11:45"]:$==="vespertino"?s=["13:00","13:50","14:40","15:45","16:30","17:15"]:$==="noturno"?s=["18:45","19:30","20:30","21:15","22:00"]:s=t.length>0?t:["07:30","08:20","09:10","10:15","11:00","11:45"];let a=k;D!=="all"&&(a=k.filter(d=>{try{return ge(d.date)===D}catch{return!1}}));let o=R;if(W!=="all"&&(o=R.filter(d=>d.uid===W)),o.length===0&&a.length>0){const d=new Set,c=[];a.forEach(n=>{n.teacherId&&!d.has(n.teacherId)&&(d.add(n.teacherId),c.push({uid:n.teacherId,displayName:n.teacherName,subject:n.subject}))}),o=c}let r="grid grid-cols-1 sm:grid-cols-2 gap-3.5 print:grid-cols-2 print:gap-3 justify-center";w==="small"?r="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 print:grid-cols-5 print:gap-1 justify-center":w==="medium"?r="grid grid-cols-1 sm:grid-cols-2 gap-3.5 print:grid-cols-2 print:gap-3 justify-center":w==="large"?r="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-5 print:grid-cols-3 print:gap-3 justify-center":w==="esticado"?r="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4 justify-center":w==="super_esticado"&&(r="grid grid-cols-1 gap-8 print:grid-cols-1 print:gap-6 justify-center");const l=`
    <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-8 print:hidden overflow-x-auto scrollbar-none select-none shrink-0">
      <button onclick="actions.setRelatorioSubTab('urania')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${re==="urania"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="grid-3x3" class="w-4 h-4 text-slate-500"></i> Grade de Professores (Individual)
      </button>
      <button onclick="actions.setRelatorioSubTab('frequent')" class="px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${re==="frequent"?"bg-white text-blue-600 shadow-sm":"text-slate-500 hover:text-slate-800"}">
        <i data-lucide="bar-chart-3" class="w-4 h-4 text-slate-500"></i> Gráfico de Frequência
      </button>
    </div>
  `;return re==="frequent"?`
      <div class="space-y-4">
        <h3 class="text-2xl font-black text-slate-900 print:hidden">Relatório de Frequência</h3>
        ${l}
        <div class="bg-white p-10 rounded-[2.5rem] border shadow-sm flex flex-col items-center">
          <div class="flex items-end gap-6 h-64 mb-10">
            <div class="w-20 bg-blue-500 rounded-t-2xl" style="height: ${M.total>0?M.confirmed/M.total*100:0}%"></div>
            <div class="w-20 bg-rose-500 rounded-t-2xl" style="height: ${M.total>0?M.absent/M.total*100:0}%"></div>
            <div class="w-20 bg-amber-400 rounded-t-2xl" style="height: ${M.total>0?M.pending/M.total*100:0}%"></div>
          </div>
          <div class="grid grid-cols-3 gap-10 text-center uppercase font-black text-xs">
            <div class="text-blue-600">Presentes: ${M.confirmed}</div>
            <div class="text-rose-500">Ausentes: ${M.absent}</div>
            <div class="text-amber-500">Pendentes: ${M.pending}</div>
          </div>
        </div>
      </div>
    `:`
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 print:hidden">
        <div>
          <h3 class="text-2xl font-black text-slate-900">Grades Escolares</h3>
          <p class="text-xs text-slate-400 mt-1">Baixe a grade escolar em PDF ou visualize instantaneamente para impressão.</p>
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <!-- Button 1: Download Direct PDF with html2pdf -->
          <button id="btn-download-pdf" onclick="actions.downloadPDF()" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-bold shadow-md flex items-center gap-2 transition-all">
            <i data-lucide="download"></i> Baixar Arquivo PDF
          </button>
        </div>
      </div>

      ${l}

      <!-- Modelo Selector Tab -->
      <div class="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-fit mb-2 print:hidden overflow-x-auto scrollbar-none select-none shrink-0" id="report-model-tabs">
        <button onclick="actions.setReportModel('prof_turma')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${U==="prof_turma"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="user" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Turma)
        </button>
        <button onclick="actions.setReportModel('prof_subject')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${U==="prof_subject"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="book" class="w-3.5 h-3.5 text-slate-500"></i> Professor (por Matéria)
        </button>
        <button onclick="actions.setReportModel('turma_grid')" class="px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${U==="turma_grid"?"bg-white text-[#2E5077] shadow-sm":"text-slate-500 hover:text-slate-800"}">
          <i data-lucide="users" class="w-3.5 h-3.5 text-slate-500"></i> Todas as Turmas
        </button>
      </div>

      <!-- Control Box -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 print:hidden">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Nome do Colégio</label>
            <input type="text" value="${X}" oninput="actions.setSchoolName(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Selecione a Semana</label>
            <select onchange="actions.setReportWeek(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${D==="all"?"selected":""}>Todas as semanas (Geral Acumulada)</option>
              ${e.map(d=>`<option value="${d}" ${D===d?"selected":""}>${fe(d)}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Turno / Períodos</label>
            <select onchange="actions.setReportTurno(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="matutino" ${$==="matutino"?"selected":""}>Manhã (07:30 - 11:45)</option>
              <option value="vespertino" ${$==="vespertino"?"selected":""}>Tarde (13:00 - 17:15)</option>
              <option value="noturno" ${$==="noturno"?"selected":""}>Noite (18:45 - 22:45)</option>
              <option value="auto" ${$==="auto"?"selected":""}>Auto-detecção de horários</option>
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Filtro de Professor</label>
            <select onchange="actions.setReportTeacher(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="all" ${W==="all"?"selected":""}>Todos os professores (${o.length})</option>
              ${R.map(d=>`<option value="${d.uid}" ${W===d.uid?"selected":""}>${d.displayName}</option>`).join("")}
            </select>
          </div>

          <div class="space-y-2">
            <label class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Tamanho dos Cards</label>
            <select onchange="actions.setReportCardSize(this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 outline-none font-medium text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="small" ${w==="small"?"selected":""}>Pequeno (Compacto)</option>
              <option value="medium" ${w==="medium"?"selected":""}>Médio (Recomendado)</option>
              <option value="large" ${w==="large"?"selected":""}>Grande (Mais Legível)</option>
              <option value="esticado" ${w==="esticado"?"selected":""}>Esticado (Largo - 2 por linha)</option>
              <option value="super_esticado" ${w==="super_esticado"?"selected":""}>Super Esticado (Página Inteira - 1 por linha)</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Live Printable Preview (Mimicking A4 Sheet) -->
      <div class="w-full overflow-x-auto pb-4 scrollbar-none">
        <div class="printable-sheet bg-white border border-slate-200 rounded-[2rem] p-6 md:p-12 shadow-xl relative overflow-hidden min-w-[750px] md:min-w-0">
        <!-- Sheet Header -->
        <div class="flex flex-col md:flex-row justify-between items-center border-b border-blue-100 pb-6 mb-8 gap-4">
          <div class="flex items-center gap-4">
            <!-- Studia Logo matching user image with book and orbital swoosh -->
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <!-- Light Blue Ribbon/Swoosh flourishes around the text -->
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              
              <!-- Subtle glow on the outer swoosh -->
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>

              <!-- Open Book icon centered above "Stu" -->
              <g transform="translate(68, 2)">
                <!-- Left half -->
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <!-- Right half -->
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>

              <!-- Main Title: Studia -->
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <!-- Subtitle: GRADE ESCOLAR DIGITAL -->
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          
          <div class="text-center md:text-right">
            <h4 class="text-sm font-black text-slate-800 uppercase tracking-wide">${X}</h4>
            <p class="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest mt-1">
              ${U==="turma_grid"?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${D==="all"?"Grade Geral Acumulada":fe(D)}
            </p>
          </div>
        </div>

        ${U==="turma_grid"?`
          <!-- Turmas Cards Grid -->
          ${(()=>{const d=[...new Set(a.filter(n=>n.classGroup&&n.classGroup.trim()!=="").map(n=>n.classGroup))].sort();console.log("=== DEBUG RELATÓRIO TURMAS ==="),console.log("schedules total:",k.length),console.log("filteredSchedules:",a.length),console.log("reportWeek:",D),console.log("reportTurno:",$),a.length>0&&(console.log("Sample schedule:",a[0]),console.log("classGroup values:",a.map(n=>n.classGroup).filter(Boolean))),console.log("[DEBUG TURMAS GRID]",{filteredSchedulesCount:a.length,allTurmasCount:d.length,allTurmas:d,reportTurno:$,sampleSchedules:a.slice(0,2).map(n=>({classGroup:n.classGroup,startTime:n.startTime,status:n.status}))});const c=$!=="auto"?d.filter(n=>{const m=a.filter(b=>b.classGroup===n),f=m.some(b=>Ve(b.startTime,$));return console.log(`[DEBUG] Turma "${n}": ${m.length} schedules, matches=${f}`),f}):d;return c.length===0?`
                <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
                  <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300 col-span-full"></i>
                  <p>Nenhuma turma cadastrada ou detectada nos horários selecionados para o turno "${$==="matutino"?"Manhã":$==="vespertino"?"Tarde":"Noite"}". Certifique-se de preencher o campo 'Turma' ao criar novos horários.</p>
                </div>
              `:`
              <div class="${r}">
                ${c.map(n=>{const m=a.filter(f=>f.classGroup===n);return Le(n,m,s)}).join("")}
              </div>
            `})()}
        `:`
          <!-- Teachers Cards Grid -->
          ${o.length===0?`
            <div class="text-center py-20 text-slate-400 font-bold space-y-2 col-span-full">
              <i data-lucide="info" class="w-12 h-12 mx-auto text-slate-300"></i>
              <p>Nenhum horário cadastrado para exibição na grade individual</p>
            </div>
          `:`
            <div class="${r}">
              ${o.map(d=>{const c=a.filter(n=>n.teacherId===d.uid);return ye(d,c,s,U)}).join("")}
            </div>
          `}
        `}

        <div class="border-t border-slate-100 mt-12 pt-4 flex justify-end text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
        </div>
      </div>
    </div>
  `};let se=0;const ut=[{title:"Studia",subtitle:"Organização da rotina escolar",content:"Uma plataforma para consultar horários, organizar laboratórios e acompanhar informações da escola.",icon:"book-open"},{title:"Organização",subtitle:"Informações em um só lugar",content:"Horários difíceis de consultar e reservas de espaços sem uma agenda compartilhada.",icon:"alert-circle"},{title:"Acesso simples",subtitle:"Cada perfil com suas ferramentas",content:"Professores consultam seus horários e a direção organiza as informações da escola.",icon:"check-circle"},{title:"Funcionalidades",subtitle:"O que o Studia faz?",content:`• Grades por professor e turma
• Reservas de laboratórios
• Relatórios para consulta e impressão`,icon:"layers"},{title:"Tecnologia",subtitle:"Stack Robusta",content:"Backend robusto para persistência sólida e Frontend moderno com Tailwind CSS.",icon:"cpu"}],ae={dev:["overview","dev_health","dev_diagnostics","dev_logs","dev_audit","dev_data","escolas","usuarios"],diretor:["horarios","labs","usuarios","relatorios"],teacher:["horarios","labs","materias"]},Ne={toggleMobileMenu(e){be=e;const t=u("#mobile-drawer");t&&t.classList.toggle("hidden",!e)},switchTabMobile(e){var t;(t=ae[i==null?void 0:i.role])!=null&&t.includes(e)&&(v=e,be=!1,this.init())},renderCurrentView(){try{i&&!i.accessToken&&(localStorage.removeItem("user"),i=null),i?i.role==="dev"?F(ot()):i.role==="diretor"?F(rt()):F(ce()):F(he()),typeof lucide<"u"&&lucide.createIcons()}catch(e){console.error("Render error:",e)}},async init(){var e,t;try{if(I==="register"&&!window.publicSchools)try{window.publicSchools=await x.get("/api/schools/public")}catch(s){console.warn("Não foi possível carregar escolas disponíveis:",s),window.publicSchools=[]}i?((e=ae[i.role])!=null&&e.includes(v)||(v=((t=ae[i.role])==null?void 0:t[0])||"horarios"),await this.refreshData(),i.role==="dev"&&await this.loadDeveloperPanel(v),this.renderCurrentView()):F(he()),typeof lucide<"u"&&lucide.createIcons()}catch(s){console.error("Init error:",s)}},showLoginModal(e="login"){I=e,this.init()},hideLoginModal(){I="closed",this.init()},toggleAuthMode(e){I=e,this.init()},submitContact(e){var o,r,l;e.preventDefault();const t=(o=document.getElementById("landing-name"))==null?void 0:o.value,s=(r=document.getElementById("landing-contact"))==null?void 0:r.value,a=(l=document.getElementById("landing-message"))==null?void 0:l.value;t&&s&&a&&(p(`Obrigado ${t}! Recebemos sua mensagem. Entraremos em contato em breve!`),e.target.reset())},showCreateModal(){var t;const e=u("#create-modal");e&&(e.classList.remove("hidden"),this.updateScheduleSubjectOptions(((t=u("#form-teacher"))==null?void 0:t.value)||""),typeof lucide<"u"&&lucide.createIcons())},hideCreateModal(){const e=u("#create-modal");e&&e.classList.add("hidden")},showEditModalById(e){const t=k.find(a=>a.id===e);if(!t)return;const s=u("#edit-modal");s&&(u("#edit-form-id").value=t.id||"",u("#edit-form-subject").value=t.subject||"",u("#edit-form-class-group").value=t.classGroup||"",u("#edit-form-date").value=t.date||"",u("#edit-form-room").value=t.room||"",u("#edit-form-start").value=t.startTime||"18:45",u("#edit-form-end").value=t.endTime||"22:45",u("#edit-form-teacher").value=t.teacherId||"",u("#edit-form-status").value=t.status||"pending",this.updateScheduleSubjectOptions(t.teacherId||"",t.subject||"","edit-form"),s.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideEditModal(){const e=u("#edit-modal");e&&e.classList.add("hidden")},showDeleteModal(e){const t=u("#delete-modal");t&&(u("#delete-schedule-id").value=e,t.classList.remove("hidden"),typeof lucide<"u"&&lucide.createIcons())},hideDeleteModal(){const e=u("#delete-modal");e&&e.classList.add("hidden")},updateScheduleSubjectOptions(e,t="",s="form"){const a=u(`#${s}-subject`),o=u(`#${s}-subject-options`);if(!a||!o)return;const r=We(e);o.innerHTML=r.map(l=>`<option value="${l}"></option>`).join(""),a.value=t||""},async confirmDeleteSchedule(){const e=u("#delete-schedule-id").value;try{await x.delete(`/api/schedules/${e}`),this.hideDeleteModal(),this.init()}catch{p("Erro ao excluir.")}},showLabModal(){document.body.insertAdjacentHTML("beforeend",Je());const e=u("#lab-modal");if(e){e.classList.remove("hidden");const t=new Date,s=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`,a=u("#lab-date");a&&(a.min=s,a.value=s),typeof lucide<"u"&&lucide.createIcons()}},hideLabModal(){const e=u("#lab-modal");e&&e.remove()},switchTab(e){var t;(t=ae[i==null?void 0:i.role])!=null&&t.includes(e)&&(v=e,this.init())},async loadDeveloperPanel(e=v){try{["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?(T=await x.get("/api/dev/diagnostics"),delete J.diagnostics):e==="dev_logs"?(pe=await x.get("/api/dev/logs"),delete J.logs):e==="dev_audit"&&(ue=await x.get("/api/dev/audit"),delete J.audit)}catch(t){const s=["overview","dev_health","dev_diagnostics","dev_data"].includes(e)?"diagnostics":e==="dev_logs"?"logs":"audit";J[s]=t.message||"Não foi possível carregar os dados desta aba."}},async refreshDeveloperPanel(){(i==null?void 0:i.role)==="dev"&&(await this.loadDeveloperPanel(v),this.renderCurrentView())},async exportDeveloperData(){var s;if((i==null?void 0:i.role)!=="dev")return;const e=(s=document.getElementById("dev-export-resource"))==null?void 0:s.value;if(!e)return p("Selecione uma tabela para exportar.");if(await p("O CSV pode conter informações pessoais. Guarde o arquivo em local seguro e compartilhe apenas com pessoas autorizadas. Deseja continuar?",{confirm:!0,title:"Confirmar exportação"}))try{const a=await x.get(`/api/dev/export/${encodeURIComponent(e)}`),r={users:["uid","email","displayName","role","school_id","subject"],schools:["id","name","createdAt"],schedules:["id","date","startTime","endTime","subject","room","teacherId","teacherName","classGroup","status","school_id"],lab_bookings:["id","labId","teacherId","teacherName","date","startTime","endTime"],school_subjects:["id","school_id","subject"],teacher_subjects:["id","teacher_id","subject_id"]}[e],l=f=>{const b=f==null?"":typeof f=="object"?JSON.stringify(f):String(f);return`"${(/^[\s]*[=+\-@]/.test(b)?`'${b}`:b).replace(/"/g,'""')}"`},d=[r.map(l).join(","),...a.rows.map(f=>r.map(b=>l(f[b])).join(","))].join(`\r
`),c=new Blob(["\uFEFF",d],{type:"text/csv;charset=utf-8"}),n=URL.createObjectURL(c),m=document.createElement("a");m.href=n,m.download=`studia-${e}-${new Date().toISOString().slice(0,10)}.csv`,document.body.appendChild(m),m.click(),m.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3),p(`Exportação concluída: ${a.count} registros.`)}catch(a){p(a.message||"Não foi possível exportar os dados.")}},async login(){const e=u("#auth-email"),t=u("#auth-password");if(!e||!t)return;const s=e.value,a=t.value;if(!s||!a)return p("Por favor, preencha todos os campos.");try{i=await x.post("/api/auth/login",{email:s,password:a}),localStorage.setItem("user",JSON.stringify(i)),I="closed",this.init()}catch(o){p(o.message)}},async register(){const e=u("#auth-email"),t=u("#auth-password"),s=u("#auth-name"),a=u("#auth-subject"),o=u("#auth-school");if(!e||!t||!s)return;const r=e.value,l=t.value,d=s.value,c=a?a.value:null,n=o?o.value:null;if(!r||!l||!d)return p("Por favor, preencha todos os campos.");if(!c)return p("Por favor, informe sua matéria.");if(!n)return p("Selecione a escola para continuar.");try{i=await x.post("/api/auth/register",{email:r,password:l,displayName:d,subject:c,school_id:n}),localStorage.setItem("user",JSON.stringify(i)),I="closed",this.init()}catch(m){p(m.message)}},logout(){localStorage.removeItem("user"),i=null,v="horarios",I="closed",this.init()},showAddMatériaModal(){const e=prompt("Informe a matéria que você leciona:");e&&this.addMatéria(e)},async addMatéria(e){if(!(!i||!i.uid))try{const t=await x.post(`/api/teachers/${i.uid}/subjects`,{subject:e});window.teacherSubjects||(window.teacherSubjects=[]),window.teacherSubjects.push(t),F(ce()),lucide.createIcons()}catch(t){p(t.message)}},async deleteMatéria(e){if(!(!i||!i.uid)&&confirm(`Deseja remover a matéria "${e}"?`))try{await x.delete(`/api/teachers/${i.uid}/subjects/${encodeURIComponent(e)}`),window.teacherSubjects=(window.teacherSubjects||[]).filter(t=>t.subject!==e),F(ce()),lucide.createIcons()}catch(t){p(t.message)}},normalizeSchedules(e){return e.map(t=>{const s=t.classgroup||t.classGroup||"SEM_TURMA";return(!s||s.trim()==="")&&console.warn("[WARN] Schedule sem classGroup:",t),{id:t.id,date:t.date,startTime:t.starttime||t.startTime,endTime:t.endtime||t.endTime,subject:t.subject,room:t.room,teacherId:t.teacherid||t.teacherId,teacherName:t.teachername||t.teacherName,classGroup:s,status:t.status,school_id:t.school_id,createdAt:t.createdat||t.createdAt}})},async refreshData(){var e;if(!(!i||de)){de=!0;try{if(i.role==="dev"){const t=await Promise.allSettled([x.get(i.school_id?`/api/schedules?schoolId=${i.school_id}`:"/api/schedules"),x.get("/api/teachers"),x.get("/api/users"),x.get("/api/labs/bookings"),x.get("/api/schools"),x.get("/api/school-subjects")]),[s,a,o,r,l,d]=t.map((c,n)=>c.status==="fulfilled"?c.value:(console.error(`Data fetch #${n} failed:`,c.reason),[]));k=this.normalizeSchedules(s||[]),R=a||[],N=o||[],B=l||[],H=d||[],B.some(c=>c.id===K)||(K=i.school_id||((e=B[0])==null?void 0:e.id)||""),M={total:k.length,confirmed:k.filter(c=>c.status==="confirmed").length,absent:k.filter(c=>c.status==="absent").length,pending:k.filter(c=>c.status==="pending").length},q=r||[]}else if(i.role==="diretor"){const t=await Promise.allSettled([x.get(`/api/schedules?schoolId=${i.school_id}`),x.get("/api/teachers"),x.get(`/api/users?schoolId=${i.school_id}`),x.get("/api/labs/bookings"),x.get("/api/school-subjects")]),[s,a,o,r,l]=t.map((d,c)=>d.status==="fulfilled"?d.value:(console.error(`Data fetch #${c} failed:`,d.reason),[]));k=this.normalizeSchedules(s||[]),R=a||[],N=o||[],H=l||[],M={total:k.length,confirmed:k.filter(d=>d.status==="confirmed").length,absent:k.filter(d=>d.status==="absent").length,pending:k.filter(d=>d.status==="pending").length},q=r||[]}else{const t=await Promise.allSettled([x.get(`/api/schedules?teacherId=${i.uid}`),x.get("/api/labs/bookings"),x.get(`/api/teachers/${i.uid}/subjects`),x.get("/api/school-subjects")]),[s,a,o,r]=t.map((l,d)=>l.status==="fulfilled"?l.value:(console.error(`Data fetch #${d} failed:`,l.reason),[]));k=this.normalizeSchedules(s||[]),N=[],H=r||[],q=a||[],window.teacherSubjects=o||[]}}catch(t){console.error("Data refresh error:",t)}finally{de=!1}}},async refreshSchedules(){await this.refreshData(),this.init()},toggleUserSelection(e,t){!e||e===(i==null?void 0:i.uid)||!N.some(s=>s.uid===e)||(t?G.add(e):G.delete(e),this.renderCurrentView())},toggleAllUsers(e){const t=N.filter(s=>s.uid!==(i==null?void 0:i.uid));e?t.forEach(s=>G.add(s.uid)):t.forEach(s=>G.delete(s.uid)),this.renderCurrentView()},toggleTeacherSubjectsEditor(e){oe=oe===e?null:e,this.renderCurrentView()},async assignTeacherSchool(e){var s;const t=(s=document.getElementById(`teacher-school-${e}`))==null?void 0:s.value;if(!t)return p("Selecione uma escola para continuar.");try{await x.patch(`/api/users/${e}/school`,{schoolId:t}),await this.refreshData(),this.renderCurrentView()}catch(a){p(a.message||"Não foi possível associar o professor à escola.")}},closeTeacherSubjectsEditor(){oe=null,this.renderCurrentView()},async deleteUser(e,t,s){if(!(!e||!await p(`Deseja excluir ${t} (${s}) do sistema? Essa ação remove o acesso do usuário e sua conta de autenticação.`,{confirm:!0,title:"Excluir usuário"})))try{await x.delete(`/api/users/${e}`),G.delete(e),await this.refreshData(),this.init(),p("Usuário excluído com sucesso.")}catch(o){p(o.message||"Erro ao excluir usuário.")}},async deleteSelectedUsers(){const e=N.filter(o=>G.has(o.uid)&&o.uid!==(i==null?void 0:i.uid));if(e.length===0)return;const t=e.map(o=>o.email||o.displayName||o.uid).join(`
`);if(!await p(`Confirma excluir ${e.length} conta${e.length===1?"":"s"}? Esta ação não pode ser desfeita.

${t}`,{confirm:!0,title:"Excluir contas selecionadas"}))return;const a=[];for(const o of e)try{await x.delete(`/api/users/${o.uid}`),G.delete(o.uid)}catch(r){a.push(`${o.email||o.displayName||o.uid}: ${r.message||"falha ao excluir"}`)}await this.refreshData(),this.renderCurrentView(),a.length>0?p(`Não foi possível excluir todas as contas. As contas com erro continuam selecionadas para você tentar novamente:

${a.join(`
`)}`,{title:"Exclusão parcial"}):p(`${e.length} conta${e.length===1?"":"s"} excluída${e.length===1?"":"s"} com sucesso.`)},selectSubjectSchool(e){K=e,this.renderCurrentView()},async createSchoolSubject(e){var o;e.preventDefault();const t=u("#school-subject-name"),s=(i==null?void 0:i.role)==="diretor"?i.school_id:K||(i==null?void 0:i.school_id),a=(o=t==null?void 0:t.value)==null?void 0:o.trim();if(!s||!a)return p("Selecione uma escola e informe a matéria.");try{await x.post("/api/school-subjects",{schoolId:s,subject:a}),await this.refreshData(),this.renderCurrentView()}catch(r){p(r.message||"Erro ao adicionar matéria.")}},async deleteSchoolSubject(e,t){if(await p(`Excluir "${t}" do catálogo? Os horários antigos serão mantidos, mas os vínculos com professores serão removidos.`,{confirm:!0,title:"Excluir matéria"}))try{await x.delete(`/api/school-subjects/${e}`),await this.refreshData(),this.renderCurrentView()}catch(a){p(a.message||"Erro ao excluir matéria.")}},async setTeacherSubject(e,t,s){try{s?await x.post(`/api/school-subjects/${e}/teachers`,{teacherId:t}):await x.delete(`/api/school-subjects/${e}/teachers/${t}`),await this.refreshData(),this.renderCurrentView()}catch(a){await this.refreshData(),this.renderCurrentView(),p(a.message||"Erro ao atualizar vínculo da matéria.")}},async changeUserRole(e,t){if(!(!e||e===(i==null?void 0:i.uid)))try{await x.patch(`/api/users/${e}/role`,{role:t}),N=N.map(s=>s.uid===e?{...s,role:t}:s),this.init()}catch(s){p(s.message||"Erro ao atualizar perfil do usuário."),this.init()}},async updateStatus(e,t){try{await x.patch(`/api/schedules/${e}`,{status:t}),this.init()}catch{p("Erro ao atualizar status.")}},async createSchedule(e){var o;e.preventDefault();const t=u("#form-teacher"),s={subject:u("#form-subject").value,classGroup:u("#form-class-group").value,date:u("#form-date").value,room:u("#form-room").value,startTime:u("#form-start").value,endTime:u("#form-end").value,teacherId:t.value,teacherName:t.options[t.selectedIndex].text,school_id:i.school_id},a=[s];if((o=u("#form-double-lesson"))!=null&&o.checked){const r=this.timeToMinutes(s.startTime),l=this.timeToMinutes(s.endTime),d=l-r,c=l+d;if(d<=0||c>=1440)return p("Confira o horário da primeira aula. A segunda aula deve terminar antes da meia-noite.");a.push({...s,startTime:s.endTime,endTime:this.minutesToTime(c)})}try{for(let r=0;r<a.length;r+=1)try{await x.post("/api/schedules",a[r])}catch(l){if(r>0)return await this.init(),p(`A primeira aula foi criada, mas a segunda não pôde ser criada: ${l.message||"erro desconhecido"}`);throw l}this.hideCreateModal(),this.init()}catch(r){p(r.message||"Erro ao criar horário.")}},timeToMinutes(e){const[t,s]=(e||"").split(":").map(Number);return Number.isFinite(t)&&Number.isFinite(s)?t*60+s:NaN},minutesToTime(e){const t=String(Math.floor(e/60)).padStart(2,"0"),s=String(e%60).padStart(2,"0");return`${t}:${s}`},updateConsecutiveSchedulePreview(){var d,c;const e=u("#form-double-lesson"),t=u("#form-double-lesson-preview");if(!e||!t||(t.classList.toggle("hidden",!e.checked),!e.checked))return;const s=(d=u("#form-start"))==null?void 0:d.value,a=(c=u("#form-end"))==null?void 0:c.value,o=this.timeToMinutes(s),r=this.timeToMinutes(a),l=r-o;if(l<=0||r+l>=1440){t.textContent="Ajuste o primeiro horário para calcular a segunda aula.";return}t.textContent=`1ª: ${s}–${a} | 2ª: ${a}–${this.minutesToTime(r+l)}`},async updateSchedule(e){e.preventDefault();const t=u("#edit-form-id").value,s=u("#edit-form-teacher"),a={subject:u("#edit-form-subject").value,classGroup:u("#edit-form-class-group").value,date:u("#edit-form-date").value,room:u("#edit-form-room").value,startTime:u("#edit-form-start").value,endTime:u("#edit-form-end").value,teacherId:s.value,teacherName:s.options[s.selectedIndex].text,status:u("#edit-form-status").value};try{await x.patch(`/api/schedules/${t}`,a),this.hideEditModal(),this.init()}catch{p("Erro ao editar horário.")}},async deleteSchedule(e){if(await p("Deseja excluir este horário?",{confirm:!0,title:"Excluir horário"}))try{await x.delete(`/api/schedules/${e}`),this.init()}catch{p("Erro ao excluir.")}},async createLabBooking(e){e.preventDefault();const t={labId:u("#lab-type").value,date:u("#lab-date").value,startTime:u("#lab-start").value,endTime:u("#lab-end").value};if(t.startTime>=t.endTime){p("O horário de término precisa ser depois do horário de início.");return}if(q.some(a=>a.labId===t.labId&&a.date===t.date&&t.startTime<a.endTime.slice(0,5)&&t.endTime>a.startTime.slice(0,5))){p("Este laboratório já está reservado em parte ou em todo esse horário.");return}try{await x.post("/api/labs/bookings",t),this.hideLabModal(),this.init()}catch(a){p(a.message||"Não foi possível criar a reserva.")}},setLabFilter(e,t){P={...P,[e]:t},this.renderCurrentView()},async deleteLabBooking(e){if(await p("Deseja realmente cancelar esta reserva de laboratório?",{confirm:!0,title:"Cancelar reserva"}))try{await x.delete(`/api/labs/bookings/${e}`),await this.refreshData(),this.init()}catch{p("Erro ao excluir reserva.")}},nextSlide(){se<ut.length-1&&(se++,this.init())},prevSlide(){se>0&&(se--,this.init())},setReportWeek(e){D=e,this.renderCurrentView()},setReportTurno(e){$=e,this.renderCurrentView()},setReportTeacher(e){W=e,this.renderCurrentView()},setReportCardSize(e){w=e,localStorage.setItem("reportCardSize",e),this.renderCurrentView()},setSchoolName(e){X=e;const t=u(".printable-sheet h4");t&&(t.textContent=e)},setRelatorioSubTab(e){re=e,this.renderCurrentView()},setReportModel(e){U=e,this.renderCurrentView()},setTeacherSchedulesTab(e){e==="grid"&&(me="grid",this.renderCurrentView())},async downloadTeacherPDF(){const e=document.querySelector(".printable-sheet");if(!e)return;const t=document.querySelector("#btn-download-pdf-teacher"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);const a=e.cloneNode(!0);a.id="temp-pdf-teacher-container",a.className="printable-sheet bg-white",a.style.width="1020px",a.style.boxSizing="border-box",a.style.backgroundColor="#ffffff",a.style.padding="30px",document.body.appendChild(a),typeof lucide<"u"&&lucide.createIcons({node:a});const o={margin:[.3,.3,.3,.3],filename:`Grade_Professor_${i?i.displayName.replace(/\s+/g,"_"):"Individual"}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"}},r=Te(a);let l=()=>{};try{l=await Ee()}catch(d){console.warn("Could not clean stylesheets:",d)}html2pdf().set(o).from(a).save().then(()=>{r(),l(),document.body.removeChild(a),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(d=>{r(),l(),document.getElementById("temp-pdf-teacher-container")&&document.body.removeChild(a),console.error("Error generating PDF:",d),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),p("Houve um erro ao gerar o PDF.")})},async downloadPDF(){if(!document.querySelector(".printable-sheet"))return;const t=document.querySelector("#btn-download-pdf"),s=t?t.innerHTML:"";t&&(t.innerHTML='<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Gerando PDF...',t.disabled=!0);let a=k;D!=="all"&&(a=k.filter(g=>{try{return ge(g.date)===D}catch{return!1}}));let o=R;if(W!=="all"&&(o=R.filter(g=>g.uid===W)),o.length===0&&a.length>0){const g=new Set,S=[];a.forEach(j=>{j.teacherId&&!g.has(j.teacherId)&&(g.add(j.teacherId),S.push({uid:j.teacherId,displayName:j.teacherName,subject:j.subject}))}),o=S}let r=[];if($==="matutino")r=["07:30","08:20","09:10","10:15","11:00","11:45"];else if($==="vespertino")r=["13:00","13:50","14:40","15:45","16:30","17:15"];else if($==="noturno")r=["18:45","19:30","20:30","21:15","22:00"];else{const g=ve();r=g.length>0?g:["07:30","08:20","09:10","10:15","11:00","11:45"]}let l=[];const d=U==="turma_grid";d?l=Fe(a):l=o;const n={small:8,medium:4,large:3,esticado:2,super_esticado:1}[w]||4,m=[];for(let g=0;g<l.length;g+=n)m.push(l.slice(g,g+n));const f=document.createElement("div");f.id="temp-pdf-container",f.className="printable-sheet bg-white",f.style.width="1020px",f.style.padding="10px",f.style.boxSizing="border-box",f.style.backgroundColor="#ffffff";let b="grid grid-cols-2 gap-4 justify-center w-full";w==="small"?b="grid grid-cols-4 gap-2 justify-center w-full":w==="medium"?b="grid grid-cols-2 gap-4 justify-center w-full":w==="large"?b="grid grid-cols-3 gap-4 justify-center w-full":w==="esticado"?b="grid grid-cols-2 gap-4 justify-center w-full":w==="super_esticado"&&(b="grid grid-cols-1 gap-6 justify-center w-full");let E="";m.forEach((g,S)=>{const j=`
        <div class="flex justify-between items-center border-b border-blue-100 pb-4 mb-6 gap-4">
          <div class="flex items-center gap-4">
            <svg width="240" height="65" viewBox="0 0 240 65" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: block;">
              <path d="M10 24C45 6, 85 45, 128 35C155 28, 175 14, 235 22" stroke="#7ec2f2" stroke-width="2.8" stroke-linecap="round" fill="none" opacity="0.8"/>
              <path d="M124 35C136 43, 155 35, 150 24C145 15, 132 18, 126 27" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.9"/>
              <path d="M175 14C195 6, 215 16, 235 22" stroke="#7ec2f2" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity="0.3"/>
              <g transform="translate(68, 2)">
                <path d="M15 14C15 6, 25 3, 30 7.5L30 23C25 18, 15 19, 15 22Z" fill="#5B99C2" />
                <path d="M45 14C45 6, 35 3, 30 7.5L30 23C35 18, 45 19, 45 22Z" fill="#2E5077" />
                <path d="M18 16C18 13, 24 10, 27 12L27 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
                <path d="M42 16C42 13, 36 10, 33 12L33 21" stroke="white" stroke-width="0.8" opacity="0.4" fill="none"/>
              </g>
              <text x="18" y="47" font-family="'Inter', sans-serif" font-weight="800" font-size="34" fill="#2E5077" letter-spacing="-1.5">Studia</text>
              <text x="21" y="58" font-family="'Inter', sans-serif" font-weight="700" font-size="8.5" fill="#5B99C2" letter-spacing="1.2">GRADE ESCOLAR DIGITAL</text>
            </svg>
          </div>
          <div class="text-right">
            <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">${X}</h4>
            <p class="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest mt-0.5">
              ${d?"Relatório de Turmas (Individual)":"Relatório de Professores (Individual)"} - ${D==="all"?"Grade Geral Acumulada":fe(D)}
            </p>
          </div>
        </div>
      `,O=g.map(A=>{if(d){const Z=a.filter(ne=>ne.classGroup===A);return Le(A,Z,r)}else{const Z=a.filter(ne=>ne.teacherId===A.uid);return ye(A,Z,r,U)}}).join(""),_=`
        <div class="border-t border-slate-100 mt-6 pt-3 flex justify-between text-[8px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
          <span>Página ${S+1} de ${m.length}</span>
          <span>Data de emissão: ${new Date().toLocaleDateString("pt-BR")}</span>
        </div>
      `,Q=S===m.length-1?"":"page-break-after: always;";E+=`
        <div class="pdf-page bg-white" style="${Q} width: 100%; box-sizing: border-box; padding-bottom: 20px;">
          ${j}
          <div class="${b}">
            ${O}
          </div>
          ${_}
        </div>
      `}),f.innerHTML=E,document.body.appendChild(f),typeof lucide<"u"&&lucide.createIcons({node:f});const h={margin:[.2,.2,.2,.2],filename:`Grade_Escolar_${D}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"},jsPDF:{unit:"in",format:"a4",orientation:"landscape"},pagebreak:{mode:["avoid-all","css","legacy"]}},C=Te(f);let y=()=>{};try{y=await Ee()}catch(g){console.warn("Could not clean stylesheets:",g)}html2pdf().set(h).from(f).save().then(()=>{C(),y(),document.body.removeChild(f),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons())}).catch(g=>{C(),y(),document.getElementById("temp-pdf-container")&&document.body.removeChild(f),console.error("Error generating PDF:",g),t&&(t.innerHTML=s,t.disabled=!1,typeof lucide<"u"&&lucide.createIcons()),p("Houve um erro ao gerar o PDF.")})},showCreateEscolaModal(){const e=document.getElementById("create-escola-modal");e&&e.classList.remove("hidden")},hideCreateEscolaModal(){var t;const e=document.getElementById("create-escola-modal");e&&e.classList.add("hidden"),(t=document.getElementById("escola-name"))!=null&&t.value&&(document.getElementById("escola-name").value="")},async createSchool(e){var s;e&&e.preventDefault();const t=(s=document.getElementById("escola-name"))==null?void 0:s.value;if(!t)return p("Nome da escola é obrigatório.");try{await x.post("/api/schools",{name:t,createdBy:i.uid}),this.hideCreateEscolaModal(),await this.refreshData(),this.init(),p("Escola criada com sucesso!")}catch(a){p(a.message||"Erro ao criar escola.")}},async deleteSchool(e){if(!e)return;const t=B.find(a=>a.id===e);if(await p(`Deseja excluir a escola "${t==null?void 0:t.name}"? Esta ação não pode ser desfeita.`,{confirm:!0,title:"Excluir escola"}))try{await x.delete(`/api/schools/${e}`),await this.refreshData(),this.init(),p("Escola excluída com sucesso.")}catch(a){p(a.message||"Erro ao excluir escola.")}},showCreateUserModal(e="dev"){const t=document.getElementById("create-user-modal");t&&t.classList.remove("hidden")},hideCreateUserModal(){var t,s,a,o,r,l;const e=document.getElementById("create-user-modal");e&&e.classList.add("hidden"),(t=document.getElementById("user-displayname"))!=null&&t.value&&(document.getElementById("user-displayname").value=""),(s=document.getElementById("user-email"))!=null&&s.value&&(document.getElementById("user-email").value=""),(a=document.getElementById("user-password"))!=null&&a.value&&(document.getElementById("user-password").value=""),(o=document.getElementById("user-subject"))!=null&&o.value&&(document.getElementById("user-subject").value=""),(r=document.getElementById("user-school"))!=null&&r.value&&(document.getElementById("user-school").value=""),(l=document.getElementById("user-role"))!=null&&l.value&&(document.getElementById("user-role").value="")},async createUser(e){var c,n,m,f,b,E,h,C,y;e&&e.preventDefault();const t=(n=(c=document.getElementById("user-displayname"))==null?void 0:c.value)==null?void 0:n.trim(),s=(f=(m=document.getElementById("user-email"))==null?void 0:m.value)==null?void 0:f.trim(),a=(b=document.getElementById("user-password"))==null?void 0:b.value,o=(h=(E=document.getElementById("user-subject"))==null?void 0:E.value)==null?void 0:h.trim(),r=(C=document.getElementById("user-role"))==null?void 0:C.value,l=(y=document.getElementById("user-school"))==null?void 0:y.value;if(!t)return p("Nome é obrigatório.");if(!s)return p("E-mail é obrigatório.");if(!a)return p("Senha é obrigatória.");if(a.length<8)return p("Senha deve ter no mínimo 8 caracteres.");if(!r)return p("Cargo é obrigatório.");if((i==null?void 0:i.role)==="dev"&&!l)return p("Selecione a escola do usuário.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))return p("E-mail inválido.");try{const g={displayName:t,email:s,password:a,role:r,schoolId:l,userRole:i==null?void 0:i.role,userSchoolId:i==null?void 0:i.school_id};o&&(g.subject=o),await x.post("/api/users/create",g),this.hideCreateUserModal(),await this.refreshData(),this.init(),p("Usuário criado com sucesso!")}catch(g){const S=g.message||"Erro ao criar usuário.";p(S)}}};function Oe(e){try{const t=e.match(/oklch\(([^)]+)\)/i);if(!t)return"rgb(0, 0, 0)";const s=t[1].trim().split(/[\s,+/]+/);if(s.length<3)return"rgb(0, 0, 0)";let a=s[0].endsWith("%")?parseFloat(s[0])/100:parseFloat(s[0]),o=s[1].endsWith("%")?parseFloat(s[1])/100*.4:parseFloat(s[1]),r=0;s[2]!=="none"&&(s[2].endsWith("deg")?r=parseFloat(s[2]):s[2].endsWith("rad")?r=parseFloat(s[2])*180/Math.PI:s[2].endsWith("turn")?r=parseFloat(s[2])*360:r=parseFloat(s[2]));let l=1;s[3]!==void 0&&(l=s[3].endsWith("%")?parseFloat(s[3])/100:parseFloat(s[3]));const d=o*Math.cos(r*Math.PI/180),c=o*Math.sin(r*Math.PI/180),n=a+.3963377774*d+.2158037573*c,m=a-.1055613458*d-.0638541728*c,f=a-.0894841775*d-1.291485548*c,b=Math.pow(Math.max(0,n),3),E=Math.pow(Math.max(0,m),3),h=Math.pow(Math.max(0,f),3);let C=4.0767416621*b-3.3077115913*E+.2309699292*h,y=-1.2684380046*b+2.6097574011*E-.3413193965*h,g=-.0041960863*b-.7034186147*E+1.707614701*h;const S=C<=.0031308?12.92*C:1.055*Math.pow(C,1/2.4)-.055,j=y<=.0031308?12.92*y:1.055*Math.pow(y,1/2.4)-.055,O=g<=.0031308?12.92*g:1.055*Math.pow(g,1/2.4)-.055,_=Q=>Math.min(255,Math.max(0,Math.round(Q*255)));return l===1?`rgb(${_(S)}, ${_(j)}, ${_(O)})`:`rgba(${_(S)}, ${_(j)}, ${_(O)}, ${l})`}catch{return"rgb(0, 0, 0)"}}function xe(e){return!e||typeof e!="string"||!e.includes("oklch")?e:e.replace(/oklch\([^)]+\)/gi,t=>{let s=document.getElementById("temp-color-resolver");s||(s=document.createElement("div"),s.id="temp-color-resolver",s.style.position="absolute",s.style.visibility="hidden",s.style.width="0",s.style.height="0",document.body.appendChild(s));try{s.style.color=t;const a=window.getComputedStyle(s,null).getPropertyValue("color");if(a&&!a.includes("oklch"))return a}catch{}return Oe(t)})}async function Ee(){const e=[],t=Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'));let s="";for(const r of t)try{if(r.tagName==="STYLE")s+=`
`+r.innerHTML,e.push({node:r,originalDisabled:r.disabled,type:"style"});else if(r.tagName==="LINK"){let l="";try{if(r.sheet){const d=r.sheet.cssRules||r.sheet.rules;for(let c=0;c<d.length;c++)l+=d[c].cssText+`
`}}catch{}if(!l){const d=r.getAttribute("href");d&&(d.startsWith("/")||d.startsWith("./")||d.startsWith("src/")||d.startsWith(window.location.origin))&&(l=await(await fetch(d)).text())}l&&(s+=`
`+l,e.push({node:r,originalDisabled:r.disabled,type:"link"}))}}catch(l){console.warn("Could not backup or read stylesheet:",r,l)}const a=s.replace(/oklch\([^)]+\)/gi,r=>Oe(r)),o=document.createElement("style");o.id="temp-cleaned-stylesheets",o.innerHTML=a,document.head.appendChild(o);for(const r of e)r.node.disabled=!0;return function(){for(const l of e)l.node.disabled=l.originalDisabled;o.parentNode&&o.parentNode.removeChild(o)}}function Te(e){const t=pt(),s=[e,...e.querySelectorAll("*")],a=[];for(const o of s){if(!o||!o.style)continue;const r=o.getAttribute("style")||"";a.push({el:o,originalInlineStyle:r});try{const l=window.getComputedStyle(o),d=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"];for(const c of d){let n="";try{n=l.getPropertyValue(c.replace(/([A-Z])/g,"-$1").toLowerCase())}catch{n=l[c]}if(n&&typeof n=="string"&&n.includes("oklch")){const m=xe(n);o.style[c]=m}}}catch{}}return function(){t();for(const r of a)r.originalInlineStyle?r.el.setAttribute("style",r.originalInlineStyle):r.el.removeAttribute("style")}}function pt(){const e=CSSStyleDeclaration.prototype.getPropertyValue;CSSStyleDeclaration.prototype.getPropertyValue=function(a){const o=e.call(this,a);return o&&typeof o=="string"&&o.includes("oklch")?xe(o):o};const t=["color","backgroundColor","borderColor","borderTopColor","borderBottomColor","borderLeftColor","borderRightColor","stroke","fill"],s={};for(const a of t){const o=Object.getOwnPropertyDescriptor(CSSStyleDeclaration.prototype,a);o&&o.get&&(s[a]=o,Object.defineProperty(CSSStyleDeclaration.prototype,a,{configurable:!0,enumerable:!0,get(){const r=o.get.call(this);return r&&typeof r=="string"&&r.includes("oklch")?xe(r):r},set(r){o.set.call(this,r)}}))}return function(){CSSStyleDeclaration.prototype.getPropertyValue=e;for(const o in s)Object.defineProperty(CSSStyleDeclaration.prototype,o,s[o])}}window.actions=Ne;Ne.init();
